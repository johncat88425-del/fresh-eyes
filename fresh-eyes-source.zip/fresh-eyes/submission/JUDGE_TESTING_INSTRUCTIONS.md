<!-- For the Devpost "testing instructions" field and the public README. Before submitting, select
     the final fixed release tag, check the run IDs still exist in the published build,
     and update "What we do not claim" if the formal evaluation produced new results. B, 2026-10-21. -->
# Testing Fresh Eyes

The recorded viewer and local engineering tests in steps 1–2 are free and need no provider account or key. Optional live model repair in step 3 requires a separately activated, paid provider key.

## 1. See real recorded checks (2 minutes, nothing to install)

Open **https://johncat88425-del.github.io/fresh-eyes/**.

- Press **Start**, pick a project, then press **See the result**. Or press **See a real example first**.
- **Detailed view** (top right; at the bottom of the page on phones) shows the full evidence: every command, log, output check, patch, and each Nemotron call with its tokens and usage-based cost.
- Four runs worth opening:
  - md2html: the README as written fails. The `md2html` command is never installed. https://johncat88425-del.github.io/fresh-eyes/#/runs/10175eee750c464fa7ce86ad4c84f037
  - md2html: a one-line README fix (`pip install .`), written by a person, passed in two fresh environments. https://johncat88425-del.github.io/fresh-eyes/#/runs/563db9062b7b4e48a4490e41b6792ff6
  - md2html: Nemotron diagnosed the same failure over two repair rounds. Nano classified it and Ultra explained it, but no proposal could be applied safely, so the run stopped and asks a person. https://johncat88425-del.github.io/fresh-eyes/#/runs/e9a04f641acb4c71b7ff0932e58f87e8
  - mistletoe: the README already works. https://johncat88425-del.github.io/fresh-eyes/#/runs/a7bf8fc4969e44ec9436ea79cc7cee00

This site replays real runs recorded on 19–21 October 2026. It does not run anything new and calls no model: a recording is not a live run.

## 2. Run it yourself, no key needed (about 10 minutes)

Needs Python 3.12 and Node.js 18 or newer. No other packages.

```sh
git clone https://github.com/johncat88425-del/fresh-eyes.git fresh-eyes-release
cd fresh-eyes-release
# Preliminary candidate: main; choose a fixed final tag before submission.
# This candidate repository distributes its complete source tree as an archive.
# Verify release-files.json, then extract it (or use your system's ZIP tool).
python3.12 -m zipfile -e fresh-eyes-source.zip source
cd source/fresh-eyes
PYTHONPATH=src python3.12 -m unittest discover -s tests
python3.12 web/demo/build.py
node --test web/tests/*.test.mjs
```

The build rebuilds the same viewer into `dist/demo/` from the versioned recordings; the web tests then check it too. To open it, run `python3 -m http.server 3001 --directory dist/demo` and go to http://localhost:3001/.

To use the local app with its API (execution is off and no keys are read), use two terminals:

```sh
python3.12 scripts/fresh-eyes serve
python3.12 web/serve.py
```

Then open http://localhost:5173/.

## 3. Optional: run real README checks (advanced)

Running a third-party repository needs a container runtime. The project owner has tested this only on macOS, using the bundled VM setup (`python3.12 scripts/start-local-runtime.py`, then `python3.12 scripts/run-development.py --case mistletoe`); see the README. If you extracted with Python's ZIP module, first run `chmod +x scripts/docker-local` to restore the helper's executable permission. These runs follow the README only and call no model.

Model repair (NVIDIA Nemotron on Nebius Token Factory) needs your own Nebius API key, is billed to your account, and must be switched on explicitly (`api/MODEL_API.md`). The recorded model runs in step 1 include the saved calls; they do not demonstrate a new live repair. Free hosted live model access is not provided in this candidate.

## What we do not claim

- There is no hosted live service. The website shows recordings only.
- So far the only verified fix was written by a person. No Nemotron-generated patch has passed verification. The latest diagnosis exhausted its completion cap without returning complete JSON.
