# 10/20 提前至 10/22 的交接結果

任務狀態與每批紀錄只更新 [TEAM_TASKS.md](../PUBLIC_EXPORT.md)；本文件說明使用方式，避免另開一份進度表。

已整合 B 的 real-rounds、through-1022、ahead、publish-prep、rehearsal 及 B18–B19。保留 A 的後端和可獨立重建的錄製資料，沒有用 B 的舊 build 覆蓋它。圖庫、字幕、發布步驟也會進程式交接包。發布、錄影和外部聯絡都尚未進行。

B 提出的四個後端問題已各有入口：

- 人工結果覆核：`evaluation-export --review-template` 產生逐筆表，真人填完用 `--human-reviews` 合併。詳見 [runbook](../evaluation/RUNBOOK.md)。程式不會代填 accepted。
- 邊界案例：[獨立 baseline 入口](../cases/boundary/README.md)已完成；現有 plan/reviews 都是未執行、draft，不能當成模型知道何時停止的成績。
- 第二個開發故障：本版採 3 個已執行 repo（1 個已知故障、2 個健康），停止為了湊數找故障，也不碰保留集。沒有「兩個已驗證故障」的說法。
- 本次範圍：固定 Python CLI／鎖定驗收／限制修補／最多兩輪／逐輪證據／A–D 評估及唯讀展示為主。任意 repo、夜間排程、公開付費模型入口、Sandboxes 實際執行和 Tavily 不納入 v1 成果。Sandboxes 權限申請保留；有新證據才另開版本。

公開展示的準備方案採 GitHub Pages 加 MIT 原始碼與可下載 test build；目前僅完成本機建置，沒有建立公開 repo、push 或啟用 Pages。靜態頁會明示回放；評審可重新執行的 test build、必要的免費執行方式及維持至評審期結束仍是交件條件，不能用回放代替。

10/20 免費實跑新增 json2yaml 的 live PyPI 驗收（兩組均通過、模型 0），以及同一 immutable arm64 image 的實際出站／清理關卡。新增報告會出現在 OPEN_REPORTS.html；公開展示仍維持原來 6 筆精選回放，沒有把新報告悄悄計入正式評估。

修正後的模型計畫只做本機預覽：README 安裝段完整可見，原文精確出現一次；沒有讀 key 或再發模型請求。單次 US$0.03 授權已消耗，後續試跑仍待新授權。本次不以清單或餘額延長它。

四案 B/C/D 的容量計畫見 [budget-scenario](../evaluation/budget-scenario-20261020.json)：若每案每組上限 US$0.03，配置總上限至少 US$0.36，最多 40 次請求。歷史相同 token 量的合計約 US$0.168 是情境試算，不是報價、授權或實測 D 組。健康基準不會呼叫模型；實際 runner 費用未知。

B15～B19 已交付。A 保留原子建置與可版控快照，補強評估報告 capture，並對齊 B19 的 result_review 欄位。B 下一步直接做 B20 真人影片初剪、B21 新版程式包獨立解壓／手測；不必再等 A 的模型結果才開始。程式包解壓到新目錄，避免覆蓋正在修改的前端或共用任務入口。保留集／邊界由實際負責的人覆核，不能由 AI 代簽；正式結果到齊才更新成績。

## 可攜與介面驗證的界線

[Linux v2](../evidence/linux-portability-20261020-v2.json) 用乾淨、無網路、無主機掛載／key 的同機 Linux 容器通過 223 Python／24 web、預設 API／前端及 source-only demo 重建。這不是另一台電腦或第三方 repo 的真實 runner／模型驗收。首次 tmpfs 權限失敗保留在 v1，v2 完成後容器已移除。

[B18 的 A 瀏覽器複驗](../evidence/B18-browser-merge-20261020.json) 用免費工程資料確認兩輪、消耗後回到不修補及重載保留狀態；不讀金鑰、不碰正式資料庫。UI-14 真實模型 gate 仍未完成。B19 的合成 accepted／rejected／pending 證據與回歸測試只證明呈現正確，不能變成正式評估。

最新版同機 source-only 解壓驗收為 **226 Python／27 web 全過**，見 [release-prep 核對](../evidence/release-prep-verified-20261020.json)。Linux v3 在 Docker socket 消失時前置失敗，未建容器；已保存失敗證據，沒有把 v2 舊成功算到新版。正常本機 API／前端已重新啟動於 8765／5173；runner 與付費模型保持關閉，沿用三筆原有真人確認。

B 請使用 `dist/fresh-eyes-A-2026-10-20-release-prep.zip`，解壓到新目錄；這版接續整合 B18–B19，不必再疊舊的 A through-1022 包。B20 先錄現有真實回放，B21 用這版做真人手測。不要把包內任務快照覆蓋到共用主檔。
