# Nano／Ultra：目前已實作與啟用前的條件

> 最新 10/20：[兩輪真實結果](MODEL_TRIAL_RESULT_20261020.md)，4 次呼叫、usage US$0.01362438，needs_review，沒有模型 verified_fix。US$0.03 單次授權已消耗，付費關閉。以下保留先前接通過程；不是本次又未執行的說法。

診斷與最多兩輪候選修補已接到核心 engine；HTTP API 仍只接受 none／manual_candidate，沒有啟用模型。一般 CLI／Web 預設不會發送付費請求；evaluation-run 另有明確本機啟用旗號及凍結額度，見 [雙輪與四組評估](MULTI_ROUND.md)。本輪只做工程測試，沒有新增模型呼叫。先前 A 明確授權的一次真實 Nano→Ultra 結果仍是 needs_review，費用依 usage 計算 US$0.00660426。見 [本次紀錄](MODEL_PILOT.md)。

獨立開發入口已新增：[model-trial-plan／model-trial-run](MODEL_TRIAL.md)。先以已確認的開發案預覽，再在新授權下明確啟用，不需要載入或執行保留集。原始功能通過時不讀 key；本輪只完成預覽與合成工程測試。

## 現在可做：從既有證據產生計畫

在 fresh-eyes 目錄執行：

```sh
python3.12 scripts/fresh-eyes repair-plan cases/mistletoe.json \
  --evidence /你的路徑/report.json
```

全 Ultra 計畫使用相同命令，加 --route all_ultra；最多兩輪計畫再加 --max-patch-rounds 2。這個命令只讀 case 與 engine report，不讀 .env、不連網、不跑 repo、不建立帳本或修改報告。UI example 不能作為證據；完整 contract hash 和 acceptance hash 必須相符。

原始功能流程已確認失敗時，列出 classify 與 diagnose 階段；選兩輪則也列出有條件的 classify_r2／diagnose_r2。原本通過、缺少基準或 infrastructure_error 時沒有模型階段。輸出 executed=false、model_calls=0；它是計畫，不是已使用 Nano／Ultra 的證明。

## 核心流程

| 階段 | nano_ultra | all_ultra | 決定權 |
|---|---|---|---|
| 原始 README 試跑 | runner | 同左 | 固定功能驗收 |
| 分類 | 配置的 Nano ID | 配置的 Ultra ID | JSON 分類是線索；非文件／依賴類型轉人工釐清 |
| 診斷／候選 | 配置的 Ultra ID | 同左 | 每輪一次候選，沒有隱藏重試或模型 fallback |
| Patch 檢查 | 程式 | 同左 | 既有檔案、精確替換、TOML 結構與安裝步驟檢查 |
| 候選試跑＋獨立重跑 | 乾淨 runner | 同左 | 兩次功能驗收都通過才能 verified_fix |

兩條路由使用同一種 ModelSpec、帳本、prompt、輸出政策、runner 和驗收；沒有執行全 Ultra 就沒有費用或省錢結論。預設一輪，明確 max_patch_rounds=2 才允許第二輪；每輪從原始 commit 重新準備，保留上一輪候選及失敗摘要，兩輪共用額度。A／B／C／D 的凍結／執行／匯出程式已完成工程驗證，真實四組評估與查證工具尚未完成。

RepairPlanner 只能讀限量的 README／依賴檔、原始命令及執行／驗收摘要。預期輸出不放進 runner；模型也沒有改 fixture、validator 或產品程式的接口。來源文字與 log 當資料處理；已知控制端 key、Bearer 與常見 secret assignment 會遮蔽，但這不是任意私密內容的完整辨識保證。現在仍只適用已審閱的公開案例。

模型必須回傳本機嚴格驗證的 JSON。多餘欄位、重複鍵、截斷／refusal／tool call、來源碼修改、驗收修改或不支援命令都停止。即使模型說成功，結果仍由 host 的驗收與最後重跑決定。

## 費用帳本

ModelLedger 使用獨立 SQLite 檔、transaction 與 BEGIN IMMEDIATE。每次請求前先保留額度；不足就不 dispatch。每筆記錄 run、階段、請求／回應 model ID、provider ID、時間、usage、費率來源、prompt hash 及結果。原始 prompt、回應與 API key 不存進帳本。

- 同一帳本的 run ID／上限固定，重啟不能自動重設；未完成的保留額度不會自動釋放或重送。
- 每個 stage 只能保留一次；第二輪使用不同 stage，但不增加單案預算。正式評估另檢查本批最壞配置與整批額度；費用未知就停止整批。
- 先 reserve，再記錄 dispatch 開始；只有 reserve 而尚未 dispatch 的紀錄不算 model_calls。
- 預設依完整配置 context 與 completion 上限保留。本次另有核對過 tokenizer／template 的 UTF-8 byte 輸入上界，保留真實模型容量並限制請求；見 [方法與限制](PROMPT_BUDGET.md)。這是客戶端規則，不能代替平台帳戶／付款上限。
- calculated_usd 只用實際回應的 usage 與有來源的費率計算，標為 usage_calculated_pending_reconciliation；billed_usd 在沒有帳單依據時是 null。
- reasoning_tokens 已包含在 completion_tokens，不重複計算。cached tokens 有回應但沒有對應費率時，費用為未知。
- 缺 usage、逾時、HTTP 錯誤、模型 ID 與費率不符時保留未知費用；有未解費用的後續請求會停止。不把失敗當成免費，也不自動 retry。
- engineering_test 回應獨立標記，計入 engineering_test_calls，不算真實 model_calls；合成費率與結果不能拿去報產品成本或成功率。

單份帳本限制一個 run；evaluation-run 另限制指定輸出批次的配置總額。跨手動批次的全站／每日總額、帳單對帳與帳戶扣款限制尚未實作。公開服務啟用前還需要這些限制。

## 啟用真實推論前

1. 從帳號的可用 catalog 核對完整 Nano／Ultra ID、context 容量與 JSON mode 支援。
2. 核對當時輸入／輸出／cached 費率與日期，配置 ModelSpec；沒有預設模型或沿用舊標價。
3. 確認新的批次授權及上限。US$25 到帳不是支出授權；原 US$0.02 單輪試驗已結束，不能用剩餘額度啟動新試驗。
4. 確認 runner 與原始／人工候選路徑可用，先以開發案做已授權的受限試跑；不要拿保留集調參。
5. 正式 CLI 使用含公開模型／額度的 freeze、真人覆核、--enable-paid-models、指定 --env-file 與已審閱 --tokenizer-references；啟用前 catalog 必須與凍結匹配。見 [runbook](../evaluation/RUNBOOK.md)。目前不能透過前端開啟模型。

NebiusTransport 的 enabled 預設為 false，只有 Python 程式明確傳入 True 才能嘗試 POST；ModelCaller 另外先檢查配置、帳本與 deadline。一般 serve、run、repair-plan 不會建構已啟用的 transport；evaluation-run 必須明確付費啟用才會建構。本輪未使用該旗號。金鑰留在控制端，不傳給 runner。

## 官方依據

- [Chat completion API](https://docs.tokenfactory.nebius.com/api-reference/inference/create-chat-completion)：固定接口、usage、max_completion_tokens 與停止原因。
- [JSON output](https://docs.tokenfactory.nebius.com/ai-models-inference/json)：JSON mode 依模型支援；本版採 json_object 加本機嚴格驗證。
- [Observability](https://docs.tokenfactory.nebius.com/ai-models-inference/observability)：操作指標與帳單對帳分開。


## 2026-10-19 真實單輪已完成

初次檢查被 VM 停止及完整 context 保留方式擋下，未發送推論。Chris 恢復 VM 後，新增經核對的請求輸入上界並通過工程測試，再完成一次 Nano 分類與一次 Ultra 診斷。總 calculated_usd=0.00660426，小於本次 US$0.02；billed_usd=null。候選因唯一精確匹配失敗而被拒，結果 needs_review，沒有候選／最終驗收，也沒有重試。詳見 [原始紀錄與後續補強](MODEL_PILOT.md)。
