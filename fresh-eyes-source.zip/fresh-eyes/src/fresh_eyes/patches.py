"""Exact replacements, structural TOML checks, no generic shell or source edits."""

import copy
import difflib
from pathlib import Path
import re
import tomllib

from .contracts import InvalidCase, relative_path, validate_steps


class PatchMismatch(InvalidCase):
    """An admissible target did not match; a later authorized round may revise it."""


def _without_dependencies(data):
    d = copy.deepcopy(data)
    project = d.get("project", {})
    project.pop("dependencies", None)
    project.pop("optional-dependencies", None)
    return d


def apply_patch(root: Path, bundle: dict) -> str:
    edits = bundle.get("edits", [])
    if not edits or len(edits) > 8:
        raise InvalidCase("Patch requires 1–8 exact replacements")
    diffs = []
    pending = {}
    for edit in edits:
        name = relative_path(edit["path"])
        path = root / name
        if any(p.is_symlink() for p in [path, *path.parents]) or not path.is_file():
            raise InvalidCase("Patch targets must be existing regular files")
        if name != "README.md" and name != "pyproject.toml" and not re.fullmatch(r"requirements[^/]*\.txt", name):
            raise InvalidCase(f"Patch is outside prototype scope: {name}")
        old_file = pending.get(name, path.read_text(encoding="utf-8"))
        old, new = edit.get("old"), edit.get("new")
        if not isinstance(old, str) or not old or not isinstance(new, str):
            raise InvalidCase("Each replacement must match exactly once")
        matches = old_file.count(old)
        if matches != 1:
            raise PatchMismatch(f"Replacement in {name} matched {matches} times; expected exactly once")
        new_file = old_file.replace(old, new, 1)
        if len(new_file.encode()) > 262144:
            raise InvalidCase("Patched file is too large")
        if name == "pyproject.toml":
            try:
                before, after = tomllib.loads(old_file), tomllib.loads(new_file)
            except tomllib.TOMLDecodeError:
                raise InvalidCase("Candidate pyproject.toml must remain valid TOML") from None
            if _without_dependencies(before) != _without_dependencies(after):
                raise InvalidCase("Only project dependency fields may change")
        if name.startswith("requirements"):
            for line in new_file.splitlines():
                line = line.strip()
                if line and not line.startswith("#") and not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.\[\],<>=!~; '\"()-]*", line):
                    raise InvalidCase("Requirement URLs, local paths and pip options are unsupported")
        diffs.extend(difflib.unified_diff(old_file.splitlines(True), new_file.splitlines(True), fromfile="a/" + name, tofile="b/" + name))
        pending[name] = new_file
    if "setup" in bundle:
        validate_steps(bundle["setup"])
        readme = pending.get("README.md", (root / "README.md").read_text(encoding="utf-8"))
        import shlex
        for step in bundle["setup"]:
            # The updated recipe must be visibly delivered in the patched README.
            if shlex.join(step["argv"]) not in readme and " ".join(step["argv"]) not in readme:
                raise InvalidCase("Patched setup command is absent from delivered README")
    # Validate everything before mutating any target.
    for name, content in pending.items():
        (root / name).write_text(content, encoding="utf-8")
    return "".join(diffs)
