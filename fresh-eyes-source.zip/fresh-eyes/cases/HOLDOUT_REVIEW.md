# 保留集真人覆核單（4 案）

給 10/23 凍結時負責確認的人用。和 json2yaml 一樣，逐案對照 README 原文、輸入和預期輸出；Claude（B）只做了靜態審閱（讀 README 和原始碼，沒有執行任何保留集程式），不能代替這一步。

**不要做的事：** 不要為了「讓它通過」去改案例。保留集的用途是測系統，案例要照 README 寫的樣子判斷；看到不合理的地方就記下來、先不要確認，交給 A 和 B 討論後另開新版本。

## 怎麼確認（和開發案例不同）

保留集**不在網頁上確認**。流程是（見 [evaluation/RUNBOOK.md](../evaluation/RUNBOOK.md)）：

1. 現在先讀完本單，記下每案接受或不接受。
2. 10/23 由 A 跑 `evaluation-freeze`，產生 `evaluation/reviews-20261023.json`，裡面每案都是 `"status": "draft"`。
3. 你在那個檔案裡，只對接受的案例改三個欄位，其他欄位（雜湊、freeze_sha256）一律不動：

```json
"status": "approved",
"reviewed_by": "kevin",
"approved_at": "2026-10-23T14:05:00+01:00"
```

`approved_at` 要帶時區；10/23 是 BST，所以結尾是 `+01:00`。四案都必須確認，評估才會執行；有一案不接受，評估就停下來，這是正常的保護。

凍結清單目前核對結果（2026-10-20，B 唯讀）：四個檔案與 [holdout/freeze.json](holdout/freeze.json) 一致，全部 `draft`，沒有執行過。

## 四案共通

- **安裝的是 PyPI 版本，不是固定 commit 的原始碼。** README 依固定 commit 讀；正式 pypi_live 評估安裝當次 PyPI 解析的版本並保存證據，Git commit 不會固定套件版本。只有另列的 offline_snapshot 對照才使用凍結 wheelhouse；兩種模式不能混算。
- **三個 Markdown 案例用同一組輸入**，比對方式是 `html_elements`：輸出 HTML 裡必須有這些元素和文字，其他內容不管。

| 輸入 | 內容 | 輸出必須包含 |
|---|---|---|
| `intro.md` | `# Hello` / 空行 / `A **bold** start.` | `<h1>Hello</h1>`、`<strong>bold</strong>` |
| `second.md` | `# Second` / 空行 / `An *italic* finish.` | `<h1>Second</h1>`、`<em>italic</em>` |

- **四案多樣性低**：三個 Markdown→HTML、一個 HTML→Markdown。結果只代表這類工具，對外說明時要講清楚。

---

## 1. markdown2-cli

- **Repo：** [trentm/python-markdown2 @ e69bbdf](https://github.com/trentm/python-markdown2/blob/e69bbdfeca8957992ccc60e2a09d8e52ae2349ed/README.md)
- **驗收雜湊：** `405178ac1cc7c65d702b6cec247be2125f3fc3163116acc8c31a53ef50b04547`
- **案例：** 安裝 `pip install markdown2`（L35），執行 `markdown2 {input}`，結果印到 stdout（L72）

| 行 | README 原文 |
|---|---|
| L35 | `pip install markdown2` |
| L63 | `$ python markdown2.py foo.md > foo.html` |
| L67 | `$ python -m markdown2 foo.md > foo.html` |
| L70 | "I think pip-based installation will enable this as well:" |
| L72 | `$ markdown2 foo.md > foo.html` |

**要判斷：** README 給了三種命令列寫法，案例選 L72 的 `markdown2`，但 README 自己在 L70 說「我想 pip 安裝也會有這個命令」，語氣不確定。這是 README 真實的模糊處，案例照原樣保留。`> foo.html` 是把 stdout 存成檔，所以案例直接讀 stdout 是同一件事。接受用 L72 就確認。

## 2. commonmark-cmark

- **Repo：** [readthedocs/commonmark.py @ df7dcb7](https://github.com/readthedocs/commonmark.py/blob/df7dcb7eae8b092a83654e791244b9fcaf11a871/README.rst)
- **驗收雜湊：** `e69c2edd16f1865d80f7f8b913737ae0a5c52ec16da7853c795c0f6acfc526ed`
- **案例：** 安裝 `pip install commonmark`（L38），執行 `cmark {input} -o result.html`，讀 `result.html`（L69）

| 行 | README 原文 |
|---|---|
| L38 | `$ pip install commonmark` |
| L69 | `$ cmark README.md -o README.html` |
| L73 | `usage: cmark [-h] [-o [O]] [-a] [-aj] [infile]` |

**要判斷：** 最直接的一案，只把檔名換成輸入檔和 `result.html`。注意這個 repo 已封存（archived），結果真的未知，正適合當保留案例。

## 3. markdown-it-py-cli

- **Repo：** [executablebooks/markdown-it-py @ 6f58654](https://github.com/executablebooks/markdown-it-py/blob/6f586542653a56d2ee8549a0dccfaa6ba5ebe14a/README.md)
- **驗收雜湊：** `6447c05398c3f65e63688f3cbd38ac041aed34d8c63990985d3b901d72c24fd8`
- **案例：** 安裝 `pip install markdown-it-py[plugins]`（L38），執行 `markdown-it {input}`，結果印到 stdout

| 行 | README 原文 |
|---|---|
| L38 | `pip install markdown-it-py[plugins]` |
| L104 | `usage: markdown-it [-h] [-v] [--stdin] [--enable-tables] [filenames ...]` |
| L106 | "Parse one or more markdown files, convert each to HTML, and print to stdout" |
| L132 | `$ markdown-it README.md README.footer.md > index.html` |

**要判斷：** README 的範例一次轉兩個檔（L132），案例一次一個；L104 寫明檔名可以給一個或多個，L106 寫明輸出到 stdout。接受就確認。

## 4. html2text-cli

- **Repo：** [Alir3z4/html2text @ 5cf8551](https://github.com/Alir3z4/html2text/blob/5cf85510a2498546d5b48ad1bf7d75b146aac591/README.md)（GPLv3）
- **驗收雜湊：** `2fab77afbe25c49f10100274c62d93a1e4d0b673772c6722e04ae65b8abb61e5`
- **案例：** 安裝 `pip install html2text`（L66），執行 `html2text {input}`，結果印到 stdout（L11）

| 行 | README 原文 |
|---|---|
| L11 | `Usage: html2text [filename [encoding]]` |
| L30–L31 | `<strong>Zed's</strong> … <em>Zed's</em>` 轉成 `**Zed's** dead baby, _Zed's_ dead.` |
| L66 | `$ pip install html2text` |

這一案的比對方式是 `text`：去掉頭尾空白後**整段文字完全相同**，比另外三案嚴格。

| 輸入 | 內容 | 預期輸出（逐字） |
|---|---|---|
| `intro.html` | `<h1>Hello</h1><p>A <b>bold</b> start.</p>` | `# Hello` / 空行 / `A **bold** start.` |
| `second.html` | `<h2>Second</h2><p>An <em>italic</em> finish.</p>` | `## Second` / 空行 / `An _italic_ finish.` |

**B 的靜態查證**（讀固定 commit 的原始碼，沒有執行）：

- 粗體 `**`、強調 `_`：README L31 的範例就是這樣；`html2text/__init__.py` L76–L77 預設 `emphasis_mark = "_"`、`strong_mark = "**"`。
- 命令列只有加 `-e` / `--asterisk-emphasis` 才會改成 `*` / `__`（`html2text/cli.py` L143、L303–L305），案例沒加。
- `<b>` 和 `<strong>` 同樣處理（`__init__.py` L437 `tag in ["strong", "b"]`）。
- 標題輸出 `#` 乘以層級再加空格（`__init__.py` L362）：h1 → `# `，h2 → `## `。
- 預設 78 字元換行（`config.py` L16），這兩行都很短，不會被折行。

**要判斷：** 預期輸出是否就是你從 README 和上面依據推得的結果。這一案最可能因為細節（例如空行數）出現意外，但比對前會去掉頭尾空白，中間的空行數照上面的預期。接受就確認。

---

## 邊界案例（3）不需要確認

j2cli、yq、github-flavored-markdown-to-html 是預期會停下來的案例，不算進修復率，見 [CASE_NOTES.md](CASE_NOTES.md) 的 Boundary set。它們目前也還沒有正式評估入口（RUNBOOK 最後一節）。

## 覆核紀錄（確認後填）

| case_id | 接受？ | 確認者 | approved_at | 備註 |
|---|---|---|---|---|
| markdown2-cli | | | | |
| commonmark-cmark | | | | |
| markdown-it-py-cli | | | | |
| html2text-cli | | | | |
