# Read-only demo

Build from the project root with Python 3.12; no extra packages, API, credentials, VM or network are needed:

```sh
python3.12 web/demo/build.py --replace
python3.12 scripts/package-demo.py
python3.12 -m http.server 3001 --bind 127.0.0.1 --directory dist/demo
```

Open `http://127.0.0.1:3001/`. Use HTTP rather than opening index.html directly: browsers may refuse file-origin fetches. Hash routes and relative assets also work when the site is mounted under a subdirectory. The builder publishes nothing.

The normal frontend is copied with a static read-only client. Every write is refused. Nine recorded development runs, three registered cases, ten labelled state examples, and the labelled evaluation example are included. The latest Nano→Ultra run is unresolved because its output was incomplete; the only verified patch is manual. Development replays never count as evaluation scores.

For a single HTML export with embedded recordings and modules:

```sh
python3.12 web/demo/single_file.py --output dist/public-site/index.html
```

Choose a new output for each release. This validates the generated manifest first,
then embeds the same interface and recordings. Its module-local recording reader
has no network fallback or write API. The source archive remains a separate,
downloadable runnable test build. Browser verification is required before publishing.

## Rebuild inputs

[recordings/manifest.json](recordings/manifest.json) indexes curated, versionable public inputs with source and content SHA-256 hashes. Include this directory when committing the source repo or handing it to B. The default build reads these inputs, cases, the observed approval snapshot, and frontend assets; it never reads the ignored reports/ directory or a database. The source handoff includes the manual patch diff as well as the JSON files.

For an explicit owner refresh from saved local development reports:

```sh
python3.12 web/demo/build.py --refresh-recordings --replace
```

This exports existing evidence only. Alongside the selected original runs, it discovers completed `reports/model-trial-*` directories and validates their development binding, report identity/hash, ledger and any patch. Incomplete planned output directories are ignored. A model fix highlight additionally requires recorded real calls and both successful clean attempts. Normal builds never scan reports. Review any dataset changes before making them public; refresh does not publish, run repositories or call a model. Earlier API job IDs can differ from their engine execution IDs; both are preserved in the input manifest. Hashes detect changed bytes, and are not proof of reviewer or provider identity.

## Capture formal evaluation reports

After a real evidence-bound evaluation export exists, explicitly capture every matching record root:

```sh
python3.12 web/demo/build.py --replace \
  --evaluation-records reports/evaluation-20261024-A \
  --evaluation-records reports/evaluation-20261024-BCD
```

Use only roots that actually exist; a single combined root needs one flag. The capture reuses the formal exporter to validate freeze, contracts, protocols, reports and model ledgers, and checks any existing attributed result reviews. It saves versionable inputs under `web/demo/evaluation-recordings/`, including the original report bytes, patches and results. Include that directory in the source handoff when real results are available. A later clone can rebuild report links and metrics without ignored reports/, a database or credentials. A changed results.json requires a new matching capture; results without openable reports are rejected before replacing the previous site.

Report records expose the metrics' `human_review` as `result_review` for the report UI. Engine outcomes remain unchanged; accepted, rejected and pending reviews are shown separately. Formal scores come only from the captured evaluation.json, never by counting replay records. Synthetic test fixtures do not enter the production snapshot. No real formal evaluation snapshot exists yet.

## Checks

Input hashes, real-call origins, recorded patch hashes and current approval hashes are checked. All output text is scanned for local user paths and credential-like strings before replacing an earlier marked build. The one permitted /home/ path is a charset_normalizer documentation example already present in pip logs. Engineering two-round examples stay out of the public site. The exact configured API key is never needed by the builder.

`data/manifest.json` lists hashes for generated assets. `data/recording-provenance.json` records development inputs; `data/evaluation-provenance.json` accompanies a captured formal evaluation. No placeholder evaluation.json or invented scores are generated.

The deployable directory is dist/demo/. Its ZIP is dist/fresh-eyes-read-only-demo.zip. It contains no backend; publishing it does not make arbitrary-repo execution or paid Web model runs available. A public URL has not been created.
