<!-- For the Devpost feedback section ("Most Valuable Feedback": completeness, viability, impact). B, 2026-10-22.
     Built from FEEDBACK.md and the recorded ledgers (10 real calls, 19–21 Oct 2026). Every claim is first-hand unless marked.
     Update the numbers if more real calls happen before submission. -->
# Feedback: Nebius Token Factory and NVIDIA Nemotron

We built Fresh Eyes, an agent that follows a project's README in a clean container and only reports a fix as working after it passes two independent clean re-runs. Nemotron 3 Nano classifies failures and Nemotron 3 Ultra diagnoses them and proposes a constrained patch, all through Token Factory's OpenAI-compatible API. Everything below comes from our own calls: **10 real calls (6 Nano, 4 Ultra) over 5 runs, 19–21 Oct 2026, US$0.0277 worked out from usage.** Each call is in a ledger with the returned model ID, tokens and latency.

## The three changes that would help builders most

**1. Document, and expose, reasoning control per request.** *(highest impact for agents)*
- **What happened:** Ultra spent its entire 1,536-token completion limit on reasoning (`reasoning_tokens: 1536` of `completion_tokens: 1536`) and returned no answer. Our agent had to stop with "incomplete output".
- **Why it matters:** our budget guard must reserve the worst case before every call, so every 1,000 output tokens we leave for thinking costs reservation headroom on every Ultra call. The Nemotron 3 family supports turning reasoning off and budgeting it (`enable_thinking`, reasoning budget), but we couldn't find how to set either through Token Factory.
- **Ask:** document the request parameter (for example `chat_template_kwargs` or `reasoning_effort`) per model, and say whether a reasoning budget is honoured.

**2. Report reasoning tokens for every model, not just some.**
- **What happened:** Ultra's `usage` always included `reasoning_tokens` (637–1,536). Nano's never did, in 6 of 6 development-run calls, and `completion_tokens_details` was `null`. In a separate startup probe, outside the 10 development-run calls above, a one-line answer ("Reply with exactly: hello from nemotron") reported 66 completion tokens. Our Nano classifications are under 240 characters, yet they reported 186–695 completion tokens. These are API usage figures, not reconciled billing transactions.
- **Repro:** one chat completion to `nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B` with a one-line prompt; compare the visible output with `usage.completion_tokens`.
- **Ask:** populate `completion_tokens_details.reasoning_tokens` for every reasoning-capable model, so cost and truncation can be planned per model.

**3. Make onboarding failures visible at the step where they happen.**
- **What happened:** the hackathon promo form (opened from Devpost Resources, event code pre-filled) said "Form submitted". The follow-up email then said the code couldn't be issued because "the event in your request was incorrect", and pointed to Discord support. In our onboarding flow, we were also asked for a card before creating an API key; we have not established whether this applies to every account or region.
- **Ask:**
  - validate the event code on the form itself;
  - say before sign-up that a card is needed and why;
  - for hackathons, consider a capped, card-free trial key. Students drop out at exactly this step.

## What worked very well

- **OpenAI compatibility was exact for us.** `/v1/models` and `/v1/chat/completions` with a Bearer key worked unchanged on the first try.
- **`GET /v1/models?verbose=true` is excellent.** It gives per-model prices, context length, rate limits, region and `supported_features`. We price every call from it, with the time it was read, instead of copying a web page.
- **Structured output was reliable when an answer completed.** Every complete response parsed as strict JSON, with no refusals. The one failure was the reasoning truncation above.
- **Ultra's diagnoses were consistently right:** "the README installs only the requirements, not the package that defines the command", in all three of its complete answers (two runs). In one round it declined to guess when it couldn't see enough, which is exactly what a repair agent should do.

## Smaller issues, each with a concrete fix

| Issue | Evidence | Suggested fix |
|---|---|---|
| Model ID casing is inconsistent | `nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B`, `nvidia/Nemotron-3-Ultra-550b-a55b`, `nvidia/nemotron-3-super-120b-a12b`, `nvidia/Nemotron-3_5-Lightning` | Case-insensitive IDs or short aliases (`nemotron-3-nano`) |
| Nano's category label wasn't stable for the same failure | `documentation` (19 Oct), `dependency` (20 Oct), `infrastructure` (21 Oct); the reasons all described the same missing install. Our prompt also changed between runs, so part of this is on us; with explicit category definitions it then answered `documentation` twice | Publish recommended sampling settings for classification (temperature, reasoning on or off) |
| Regions differ within one pipeline | Nano in `eu-north1`, Ultra in a US region (from the verbose catalogue) | Show the region on the model page; note cross-region latency for chained calls |
| Latency guidance | Nano 1.2–6.7 s, Ultra 3.5–7.0 s for prompts of about 2,000–3,400 tokens (10 calls; too few to generalise) | Publish typical latency per model to help set timeouts |
| Sandboxes (Beta) access status is ambiguous | After applying, a read-only check returned `whoami` but `permission_missing` for spawn, list, import and cancel | Separate messages for "Beta not enabled" and "key lacks a role"; add a per-sandbox egress allowlist (for example PyPI only) for running untrusted code |

## Reported by other participants (not verified by us)

From the Devpost discussion, 18 Oct:
- no spending cap or balance alert (requests fail with HTTP 402 at zero);
- Builder Program credit said to expire about 90 days after issue, close to the judging window;
- API-key creation unavailable in some billing countries.

We list these only because they came up repeatedly.
