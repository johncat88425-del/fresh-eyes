# Demo video script v3: the AI-written fix is the centre (B, 2026-10-24)

Replaces v2 now that a Nemotron-written patch has passed clean verification (run `5ac51103…`, validating the unchanged
proposal from trial `1a5f5135…`). Same rules as v2: under 3 minutes, English, only our own app on screen, no music,
every scene labelled RECORDED with its date (or LIVE), nothing staged.

**Made:** `submission/video/out/fresh-eyes-demo.mp4`, 2:38, 1920×1080, Mac voice (Samantha) + burned-in captions,
plus `fresh-eyes-demo.srt`. Built by `node submission/video/make_video.mjs` from the read-only demo (17 recordings).

## Scenes (next render: revised 24 Oct by A)

| # | Label | Screen | Narration |
|---|---|---|---|
| 1 | RECORDED · 19 Oct 2026 | `#/runs/10175eee…` | This project's README says: install the requirements, then run md2html. We followed it exactly, on a clean machine. The install worked, and the command didn't exist. Newcomers hit this all the time. Maintainers rarely see it. |
| 2 | RECORDED SITE | `#/` | Fresh Eyes reads a README like a newcomer. It follows the instructions in a clean test environment, checks the real output, and says in plain words whether they work. |
| 3 | RECORDED SITE | `#/start` | First, a person approves what success means: the README lines, two inputs, and the exact expected output. Then it's locked by a hash, so the agent can never move the goalposts. |
| 4 | RECORDED · 19 Oct 2026 | `#/answer/10175eee…` | Here is that check as it ran: a fresh container, the README commands exactly as written. Exit code zero never counts as success. The answer: the instructions don't work as written. |
| 5 | RECORDED · 24 Oct 2026 | `#/runs/5ac51103…` | Then NVIDIA Nemotron, on Nebius Token Factory, takes over. Nemotron 3 Nano classifies the failure, and Tavily looks up the project's own docs. Nemotron 3 Ultra finds the cause: the README installs the dependencies, but never the package that provides the command. It proposes one small README patch, anchored to exact lines. |
| 6 | RECORDED · 24 Oct 2026 | `#/runs/5ac51103…` | A patch only counts once it is proven. With it, the README passes the locked check in a fresh container, and again in an independent clean re-run. One honest detail: the first trial was interrupted by an error in our own runner, so we re-checked the exact same patch, unchanged, with no new model call. |
| 7 | RECORDED · 24 Oct 2026 | `#/runs/1a5f5135…` | Every call records its model, tokens and estimated cost. This proposal used under two cents; billing is not reconciled. Edits that cannot be applied are rejected. Here, on the twentieth, Ultra declined to guess. |
| 8 | RECORDED SITE | `#/examples` | These are recordings of real checks, including failures. State examples are labelled separately. The recorded demo and the full source are linked below. |

Scene 4 becomes LIVE (`LIVE_URL=…`) if A runs the local app with the runner on during recording; its narration then says
"Now a live check" and the time is shown.

## Honesty checks (each one is in the narration or on screen)

- The 19 Oct fix of the same README was written by a person; v3 doesn't show it, so it can't be confused with the AI one.
- The AI patch is called verified only because the original README failed and the unchanged patch passed in a fresh
  container and again in an independent clean re-run (`5ac51103…`).
- Scene 6 says the first trial was interrupted by an error in our own runner and the same patch was re-checked with no
  new model call. On screen: the run's notice "validates an unchanged saved AI proposal".
- "Under two cents": the original trial's ledger shows Nano $0.0002 + Ultra $0.0139 calculated from usage
  (billing not reconciled). If the submitted text gives another figure, change this line.
- No claim about formal evaluation, success rates or other repositories.

## Still to do before upload

- Re-render scenes 7–8 with the revised narration below; the existing MP4 and `video/out/fresh-eyes-demo-v3-original.srt` remain the original cut. New text has not been applied to its burned-in captions or audio.
- Use the new 20-record replay bundle. Scene 8 is the real-checks beginner page, not the synthetic state gallery.
- Show the later failed attempts in the linked viewer; do not imply uninterrupted end-to-end repair or formal evaluation success.

- End card without links: regenerate `gallery/endcard.png` with `REPO=… DEMO=…` once the public repo and Pages URL are final.
- If WIN-4 produces an uninterrupted end-to-end AI fix, or the maintainer note / formal evaluation run for real, update
  scenes 6–8 first, then rebuild.
- Chris watches it once and uploads it to YouTube from their own account.
