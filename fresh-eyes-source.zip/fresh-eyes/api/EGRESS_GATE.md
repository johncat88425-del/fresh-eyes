# 真實 PyPI 出站驗證工具

> 2026-10-19：第三次真實 gate 已通過 full／timeout／interrupt，19 個下載／拒絕／路由 probe 通過且資源清除完成。共 116 個工程測試通過。見 [完整試跑與建置證據](LIVE_PILOT.md)。

在已準備 Docker 的專案目錄執行：

```sh
python3.12 scripts/fresh-eyes verify-egress \
  --docker scripts/docker-local \
  --output reports/egress-gate.json
```

工具不讀 `.env`、不載入案例、不執行第三方 repo、不建立真人 approval，沒有模型或 Sandboxes 呼叫。它會下載一份 PyPI metadata 與 packaging wheel 作為正向控制；wheel 僅核對 hash，不安裝或匯入。

## 通過條件

1. 在正式 runner 的非 root、唯讀、資源上限及隔離網路設定下，經代理取得 pypi.org 的 TLS metadata、files.pythonhosted.org 的 wheel，內容符合官方 SHA-256。
2. 代理對其他網域、metadata、私有 IP、loopback、錯誤連接埠等八種 CONNECT 目標實際回 403。代理本身連不上不能算拒絕成功。
3. worker 沒有 IPv4／IPv6 對外預設路由；對當次獨立解析的 PyPI 公開 IPv4、metadata 與一個 VM 私有目的地的直接 TCP 嘗試失敗。
4. 真實逾時及「worker 啟動後注入 KeyboardInterrupt」各完成一次清除。每次查詢 Docker，核對本工具建立的 worker、proxy、staging、network 和暫存 image 已不存在；Docker 查不到不能算清除成功。

full／timeout／interrupt 三階段及清除都通過，才寫 status: passed。範圍是列出的目的地及 TCP／CONNECT，不是全協定封鎖證明或公開任意程式碼服務的安全認證。中斷測試不代表已有 Web API 取消端點。

報告包含 base image、Docker 版本／engine ID、實際 probe、資源清除、工具 source hash 與 UTC 時間，來源為 platform_check，不進 repo 歷史或修復率。isolated 模式搭配 internal bridge，不回退成 unrestricted bridge；參考 [Docker gateway modes](https://docs.docker.com/engine/network/port-publishing/#gateway-modes)。

## 實際執行紀錄

Chris 已手動啟動既有 VM。第三次報告 reports/egress-gate-20261019-attempt3.json 為 passed，Docker 29.9.1、Linux arm64。正向控制下載 packaging 26.3，hash 與 PyPI 一致；八種 CONNECT 目標回 403，六個直接 TCP 目的地均回 network unreachable，沒有對外預設路由。

第一次因 Docker socket 不存在而停止。第二次因 trusted bundle 目錄不可由非 root worker 讀取而失敗；已修正目錄權限並加回歸測試。兩份失敗報告保留，第三次另存，不覆寫歷史。各階段的資源清除查詢皆通過。

## 第三案套件準備

已從 PyPI 下載 json2yaml 1.2.0、docopt 0.6.2 的 sdist，核對官方 JSON 的 SHA-256，僅當資料讀取。靜態 setup 顯示依賴還包含 **pyaml 和 PyYAML**，不能只補 docopt。

work/json2yaml-preparation/sources.json 保存來源與 hash；A 的 work/prepare-json2yaml-wheels.py 要求一份通過且 code／image／engine 相符的 gate 報告，才在隔離 runner 內執行 pip wheel。已驗證失敗 gate 會在建置前被拒絕。工作區資料不放進 B 原始碼包。已建置四個 wheels 並核對匯出 hash；見 reports/json2yaml-wheel-preparation.json。這不等於 yaml2json 功能通過，案例仍是 draft，驗收／hash 未改。建置 hooks 只在 disposable worker 執行，參考 [pip wheel](https://pip.pypa.io/en/stable/cli/pip_wheel/)。

## 啟用界線

通過工具不會自動啟用 API live 模式，也不更改 health 的 live_pypi_platform_verified 或任務的 runtime_egress_verified；兩者尚未接上可核對的 gate 記錄，維持 false。owner 仍需明確選擇 --enable-live-pypi。每晚排程、依賴漂移與正式保留評估仍是後續工作。
