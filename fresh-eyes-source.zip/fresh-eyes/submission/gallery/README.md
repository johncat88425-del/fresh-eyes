# Devpost 圖庫

B 準備（2026-10-20）。截圖都來自唯讀展示頁的真實紀錄（英文介面），用 headless Chrome 產生；封面和片尾字卡來自 `card.html`。

| 檔案 | 用途 | 英文說明（可直接貼到 Devpost） |
|---|---|---|
| `cover.png`（1500×1000） | Devpost 縮圖 | — |
| `1-overview.png` | 圖庫 | Read-only demo: every link is a real run in a clean Linux container. |
| `2-readme-fails.png` | 圖庫 | md2html run exactly as its README says: the install succeeds, but the md2html command never exists, so both inputs fail. |
| `3-verified-fix.png` | 圖庫 | A one-line README fix passes in a fresh container and again in an independent clean re-run. This fix was written by hand, not by a model. |
| `4-two-rounds-stop.png` | 圖庫 | Nemotron on the same failure: round 1's edit doesn't match the README and is refused; in round 2 Ultra declines to guess. Nothing is applied. |
| `5-locked-check.png` | 圖庫 | The acceptance check: README lines, two inputs and expected outputs, approved once by a person and locked by hash. |
| `endcard.png`（1920×1080） | 影片片尾字卡 | — |

說明照實寫：第 3 張是人工修正，第 4 張是沒有修好、選擇停下。等有模型 verified_fix 或真實評估結果，再補新的截圖。

## 重新產生

先在一個分頁啟動展示頁（子路徑和 GitHub Pages 一樣）：

```bash
cd ~/Desktop/fresh-eyes && python3.12 web/demo/build.py --replace && mkdir -p /tmp/fe-pages && rm -rf /tmp/fe-pages/fresh-eyes && cp -R dist/demo /tmp/fe-pages/fresh-eyes && python3 -m http.server 3003 --bind 127.0.0.1 --directory /tmp/fe-pages
```

再開另一個分頁產生圖片（用暫時的 Chrome 設定檔，不會碰到你的 Chrome）：

```bash
cd ~/Desktop/fresh-eyes && bash submission/gallery/shoot.sh
```

有公開網址之後，片尾字卡可以把連結加上去：

```bash
cd ~/Desktop/fresh-eyes && REPO=https://github.com/帳號/repo DEMO=https://帳號.github.io/repo/ bash submission/gallery/shoot.sh
```
