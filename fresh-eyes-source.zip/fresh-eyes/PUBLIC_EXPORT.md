# Public source candidate

This exporter prepares files locally and does not publish them. Check any separate publication receipt for public availability. Original execution evidence remains unchanged in the owner workspace. Internal collaboration/account-support drafts and JSON support metadata containing host paths are omitted, not rewritten into a new execution record. Documentation redactions and redirected links are listed with original/exported hashes in public-source-manifest.json. Raw retained report JSON, run records, ledgers and patch bytes are unchanged. An omitted plan cannot be used to activate an old owner run; prepare a new local plan.

The demo rebuild uses versioned public recordings, not private reports or a database. Normal API startup disables repository execution and paid models. This export is not an AI repair, formal evaluation, public URL or another-machine verification.
