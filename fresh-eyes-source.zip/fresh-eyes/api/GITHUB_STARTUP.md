# Bounded GitHub README checks — development candidate, 2026-10-22

This adds a new Level 1 path. It does not change the registered functional cases,
approve an acceptance contract, repair code or call a model. The published B24
viewer still replays recordings; it does not expose this execution API.

## Inspect without running repository code

```sh
python3.12 scripts/fresh-eyes repo-inspect https://github.com/Textualize/rich-cli --output inspection-rich-cli
```

The output is a new directory containing `source/`, `inspection.json` and an
escaped HTML/JSON report in `report/`. Existing output is never overwritten.
The optional `--ref` accepts a full lowercase commit SHA. Without it, GitHub's
default branch is resolved once, then the download uses that SHA. No API key,
Git credential, environment proxy, model call, redirect or automatic retry is used.

Limits: compressed source 8 MiB; decoded tar including metadata 36 MiB; regular
file contents 32 MiB; one file 2 MiB; at most 2,000 archive members. The complete
archive is validated before writing. Symlinks, hard links, submodules, special
files, duplicate/traversing paths and embedded VCS directories are rejected.
Private or renamed URLs requiring authentication/redirects stop explicitly.

## Loopback API for B

Read-only inspection service:

```sh
python3.12 scripts/fresh-eyes serve --port 8879 --data-dir .fresh-eyes/github-dev --enable-github-import
```

`POST /api/repo-inspections` with
`{"repo_url":"https://github.com/Textualize/rich-cli"}` returns HTTP 202 and the
usual job record. Poll `GET /api/runs/{run_id}`. A ready plan ends `needs_input`
because no command was executed. `evidence.source` contains the pinned SHA and
source hashes; `evidence.plan` contains documented commands, exact README line
references and any ambiguity. This API does not add a registered case.

To enable real startup checks, the owner must explicitly enable all four flags:

```sh
python3.12 scripts/fresh-eyes serve --port 8879 --data-dir .fresh-eyes/github-dev --enable-github-import --enable-runner --enable-live-pypi --enable-startup-checks --docker scripts/docker-local
```

This requires the existing local VM/Docker runtime and its PyPI-only platform
gate. Ordinary `serve` keeps all of these capabilities off. Health exposes
`github_import`, `startup_checks` and `startup_scope`; it does not enable models.

Then `POST /api/runs`:

```json
{"repo_url":"https://github.com/Textualize/rich-cli","verification_level":"startup","dependency_mode":"pypi_live","repair_mode":"none"}
```

The single worker/4-job queue also applies to imports/startup checks. Imports
and their results survive API restart; an interrupted active job becomes failed
and is not silently retried. Startup requests cannot use model/manual repair or
an assumed offline wheelhouse.

## Results and restrictions

- `startup_only`: README installation and one documented help/version command
  exited successfully with bounded output. **No functional output was verified.**
- `unresolved`: installation/startup failed; commands and logs are retained.
- `needs_input`: no single explicit installation/startup pair could be extracted.
  Alternate install commands, shell pipelines and invented `--help` are not run.
- `unsupported`: non-Python root project, unsafe archive or source beyond limits.
- `infrastructure_error`: source download or the controlled runtime failed.

Only one documented pip install and one explicitly documented CLI help/version
command are currently supported. Multiple alternatives stop for review. A README
that installs a PyPI release does not prove that the downloaded checkout itself
works; that limitation is retained in the report.

Startup jobs have `case_id=null`, `case_available=false`, `acceptance_sha256=null`,
`review.status=draft`, `evaluation_eligible=false`, `patch_available=false` and
zero model usage. B must not show them as locked functional cases or verified fixes.
Inspect-only records have `data_origin=inspection`; they are not real executions.
The existing dashboard quick check now selects `pypi_live` only when startup
capability is enabled. The beginner registered-case flow remains unchanged.

## Actual verification so far

- Archive/parser/runner and HTTP queue paths have synthetic engineering tests.
- Real public `Textualize/rich-cli` resolved to
  `46f4d2469097be395558768714a5f07ebccf1412` (34 regular files). Its README produced
  a ready plan. Only source acquisition/inspection occurred.
- Real `joke2k/faker` resolved to
  `df289bfde6b6c739bbac696ef432d69c9ec33ac1` (863 files). Its command syntax does
  not provide a single concrete help invocation; inspection asks for input.
- The old `jazzband/pip-tools` address returned HTTP 301 and stopped; no redirect
  was followed.
- The VM Docker socket was absent during these checks. **Real container startup
  on an unregistered repository has not passed yet.** These are not holdout results.
