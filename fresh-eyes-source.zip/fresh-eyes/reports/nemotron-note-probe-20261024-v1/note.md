# Fix install instruction to use pip install .

A beginner trying to follow the README runs into an error because they need to install the tool first. They execute the command shown in the installation section, but the script looks for a binary that isn’t present, leading to a "No such file or directory" error. The project's own setup script (verified in the test run) uses `pip install .` to install the package locally. By changing the README to recommend this command instead, new contributors can set up the environment correctly without needing extra steps or troubleshooting. This small edit clarifies the expected workflow and prevents the initial confusion.

Checked with Fresh Eyes: following the README as written failed in a clean Linux container. With the change below, the documented commands produced the expected output in a fresh container and again in an independent clean re-run (run 213f4a62854b49c99a8b6274b9ab154f). The change was written by a person.

```diff
--- a/README.md
+++ b/README.md
@@ -36,7 +36,7 @@
 ### Installation
 
 ```bash
-pip install -r requirements.txt
+pip install .
 # or for editable development install
 pip install -e ".[dev]"
 ```
```

_Draft written by nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B from run 213f4a62854b49c99a8b6274b9ab154f. Read it before sending; nothing was posted._
