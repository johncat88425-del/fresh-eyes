# Dependency modes: snapshots and live PyPI checks

An unchanged wheelhouse cannot observe a new upstream package release. Offline results therefore cannot support claims about nightly dependency drift. This backend now has two explicit modes; the selected mode is saved in each new run and report.

| Mode | Package source | Appropriate use |
|---|---|---|
| `offline_snapshot` | Supplied wheels, no index, no network | Local development, regression checks and replay of an available snapshot |
| `pypi_live` | Current PyPI through a restricted proxy; no offline links or pip cache | Intended formal evaluation and nightly fresh-install checks, after the actual platform gate passes |

Nightly scheduling and formal A/B/C/D evaluation are still pending. The code supporting live access is not evidence that those experiments have run.

## Controlled egress implementation

Each live attempt creates a separate Docker internal bridge with gateway mode `isolated` and IPv6 disabled. The repository worker attaches only to that network, uses local-only upstream DNS, and has no published ports or host mounts. A separate trusted proxy attaches to the internal network and the external bridge. Docker documents that `isolated` requires `--internal` and removes the bridge's host-facing address. If this configuration cannot be created and confirmed, the run fails without falling back to unrestricted networking. [Docker gateway modes](https://docs.docker.com/engine/network/port-publishing/#gateway-modes)

The proxy accepts CONNECT only to `pypi.org:443` and `files.pythonhosted.org:443`, rejects other destinations and non-public resolved addresses, and connects to the already checked IP without a second DNS lookup. It limits concurrent connections, bytes and time. It forwards TLS, rather than terminating or inspecting package content. This controls destinations; it is not a package-trust or malware guarantee.

The worker checks proxy readiness before repository setup, creates a fresh venv, sets the PyPI index explicitly and disables cache. It does not inject stale wheels into live mode. Installation remains inside the disposable worker, including build hooks; third-party source is not built or executed on the host.

Available `pip install` reports and `pip freeze` output are retained, including partial environments after installation failure. Pip documents the installation-report format; such reports record resolved artifacts but do not independently prove functional correctness or complete build-environment reproducibility. [pip installation reports](https://pip.pypa.io/en/stable/reference/installation-report/)

## CLI

On a prepared machine with a working Docker engine:

```sh
python3.12 scripts/fresh-eyes run cases/md2html.json \
  --source ../../work/candidates/md2html \
  --output reports/md2html-live \
  --docker scripts/docker-local --development \
  --dependency-mode pypi_live
```

The live mode does not require a wheelhouse. Offline mode does require one. Default execution is still offline development unless live mode is explicitly selected.

## HTTP API

The owner explicitly enables live requests:

```sh
python3.12 scripts/fresh-eyes serve \
  --enable-runner --enable-live-pypi --development \
  --source-root ../../work/candidates --docker scripts/docker-local
```

Then a registered functional request may include:

```json
{
  "case_id": "md2html-markdown",
  "verification_level": "functional",
  "repair_mode": "manual_candidate",
  "dependency_mode": "pypi_live"
}
```

Without `--enable-live-pypi`, this returns 403 `live_pypi_disabled`. The switch permits attempting the mode; it does not certify that Docker isolation or actual PyPI access has passed testing. `/api/health` reports `live_pypi_platform_verified: false`. Per-attempt `network_policy.configuration_verified` describes the inspected Docker configuration, while `runtime_egress_verified` remains false because automatic linkage of separate gate evidence is not implemented.

## Evidence and limits

Formal comparisons must use the same dependency mode and base environment, record actual resolved versions, and disclose differences between paired runs. Live package resolution can change between attempts; a fresh successful repair alone does not prove which dependency caused the original failure. Exact replay also requires the corresponding artifacts, hashes and build conditions; merely having some offline wheels is insufficient.

The real verify-egress gate has passed on the current Docker 29.9.1 / Linux arm64 environment, including live PyPI positive controls, sampled destination denials and timeout/injected-interrupt cleanup. Two development repositories were then run through actual live resolution, with an independently verified manual md2html patch. See [evidence and limits](LIVE_PILOT.md). Earlier failed attempts are preserved. This does not establish observed dependency drift, public arbitrary-code hardening, formal holdout results or AI repair. Engineering doubles remain separate from this actual platform evidence.
