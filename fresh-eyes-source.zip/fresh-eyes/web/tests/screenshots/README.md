# Engineering screenshots

The `b19-*` screenshots are B's synthetic accepted/rejected/pending review display checks. Some reuse the layout and evidence of a development replay while changing identifiers and review fields in a temporary copy. Labels inside that temporary screenshot do not establish a real evaluated run or an actual human rejection. These files are QA material, not submission gallery images or evaluation evidence. Production demo recordings are built separately from validated saved inputs.
