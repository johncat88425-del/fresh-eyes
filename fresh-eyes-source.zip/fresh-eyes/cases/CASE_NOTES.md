# Case notes (B)

Updated 2026-10-19 (UK). Static review only: READMEs and source were read at pinned commits through GitHub and PyPI metadata. **No repository code was downloaded into a runner or executed by B.** Every "likely" below is a hypothesis until A runs it in a clean runner.

## Human approval record (to fill in by the person who actually reviews)

Approvals in the UI live only in that API's local SQLite. Record them here so A can see them. B (Claude) does not fill this in.

| case_id | acceptance_sha256 | Reviewed by | Reviewed at (UK) | Concerns |
|---|---|---|---|---|
| mistletoe-markdown | `78fae5502f1a52adda40364527172c9cf9fe3b031b80c933e9b04b35fb20b817` | kevin | 2026-10-19 23:18:09 BST | None. Approved in the UI against the API in the main project (`python3.12 scripts/fresh-eyes serve`, default data dir); locked hash equals the current acceptance hash. |
| md2html-markdown | `476312080ff301755f0efdc94177eb3bffb1228b258089ab9790fc3449bb749a` | kevin | 2026-10-19 23:58:24 BST | **Name correction:** first approved at 2026-10-19 23:23:47 BST under the name "john"; the same reviewer re-approved the same hash as "kevin" at 23:58:24 BST so both cases carry one name. That happened on the old API, which replaced the earlier record without an event (`api/B_INTEGRATION_ISSUES.md` #10, since fixed); A's pre-change SQLite backup still holds the "john" record. The new approval history starts from the current record as a `legacy_snapshot` and doesn't rebuild the earlier one. Read-only rechecked by A. Approved in the UI against the API in the main project (default data dir); locked hash equals the current acceptance hash. The reviewer accepted `-o result.html` (README L151) as part of the first workflow. |
| json2yaml-yaml2json | `59cb51e6e9377c61233719531b9bb980ace65fe0b3aa587b74fe1022f553aff5` | kevin | 2026-10-20 00:43:16 BST | Reviewed with [JSON2YAML_REVIEW.md](JSON2YAML_REVIEW.md) against the README at the pinned commit (L11, L16, L35, L41–L42 checked on GitHub). The reviewer accepted stdout output (L42, `<json_file>` optional per L35) instead of L16's `output.json`, and both expected outputs. Approved in the UI against the API in the main project (default data dir); B read-only check: locked hash equals the current acceptance hash. |

### Review checklist (about 5 minutes per case)

For each case, open the README at the pinned commit and check:

1. The cited README lines really say this install command and this CLI command (`readme_source`).
2. The goal describes what the README promises, not an easier target.
3. Both inputs are realistic and different from each other.
4. Each expected output is what a correct tool must produce for that input. For `html_elements`, the listed tags and text must appear; for `json`, the parsed object must match; for `text`, the trimmed output must match exactly.
5. Nothing in the fixture was chosen to make a known-broken tool pass.

If any item fails, write it under Concerns and don't approve. Changing a fixture creates a new acceptance hash and needs a new review.

## Development set (3)

| case_id | Pinned commit | README promise | Static expectation | Needs from A |
|---|---|---|---|---|
| mistletoe-markdown | `ebf9ae4e9279f3d8c79b7cf2710f7e73ea6438a7` | README.md:L73-L77 clone + `pip3 install -e .`; L147-L152 `mistletoe foo.md` → HTML on stdout | **Likely healthy.** setup.py:L19 defines the `mistletoe` console script; lists Python 3.12. The earlier "CLI not found" was most likely runner PATH/venv | Baseline run once the runtime is back |
| md2html-markdown | `e0175df5d2144f671435ff32b5d5e9a7d9f8bc86` | README.md:L38-L39 `pip install -r requirements.txt` ("everyday use", L44); L148 `md2html README.md` | **Likely failure.** The `md2html` command is defined in pyproject.toml:L50-L51 `[project.scripts]`; a requirements-only install never creates it. Candidate fix: README install line → `pip install .` | Confirm the failure in a clean runner |
| json2yaml-yaml2json | `b06ea713f6c817dc0af0f259da5c5afe7352174f` | README.md:L11 `pip install json2yaml`; L16 `yaml2json input.yaml output.json`; L32-L42 output defaults to stdout (the stdout sentence is L42) | **Likely healthy, with a caveat.** Dependencies `pyyaml`, `pyaml`, `docopt` are unpinned. bin/json2yaml:L49 calls `pyaml.dump(..., safe=True)`; current pyaml (26.7.0) still accepts `safe` but warns. Uses `yaml2json` so output is JSON and checked structurally | Offline wheelhouse must be able to build two sdist-only packages: `json2yaml` 1.2.0 and `docopt` 0.6.2 |

The dev target was 1 healthy + 2 in-scope failures. Statically this set is **2 likely healthy + 1 likely failure**. I didn't find a second in-scope failure I could justify without running anything; the candidates that fail on 3.12 fail for reasons that need source changes (see boundary set). This should be re-checked after A's first baseline runs rather than padded with a guess.

Considered and not chosen for the third slot:

- python-markdown2 source install (`python setup.py install`, README.md:L39): the contract only accepts `pip install` setup steps. Its PyPI path is used in the holdout set instead.
- j2cli: fails on Python 3.12, but because of removed stdlib modules (Python-version incompatibility), which the plan classes as unsupported, not a README fault.

## Holdout set (4) — frozen 2026-10-19 before any runtime result

**Inclusion rule (fixed before selection results were known):** public Python CLI; OSI licence; README at the pinned commit contains an install command and a CLI example; output is deterministic on stdout or a file and checkable with the existing `text` / `json` / `html_elements` validators; no network, API key, GPU or system package at runtime; installable with `pip install` only; the workflow takes a file argument (the runner has no stdin mode yet); not the same repo or a close fork of any dev case.

Contracts are in `cases/holdout/` so the API doesn't load them and they can't be used to tune the system. Status `draft`: they still need the same human review before the evaluation run.

| case_id | Repo @ commit | README source | Workflow | Validator | acceptance_sha256 |
|---|---|---|---|---|---|
| markdown2-cli | trentm/python-markdown2 @ `e69bbdfeca8957992ccc60e2a09d8e52ae2349ed` | README.md:L35;L72 | `markdown2 {input}` → stdout | html_elements | `405178ac1cc7c65d702b6cec247be2125f3fc3163116acc8c31a53ef50b04547` |
| commonmark-cmark | readthedocs/commonmark.py @ `df7dcb7eae8b092a83654e791244b9fcaf11a871` | README.rst:L38;L69 | `cmark {input} -o result.html` | html_elements | `e69c2edd16f1865d80f7f8b913737ae0a5c52ec16da7853c795c0f6acfc526ed` |
| markdown-it-py-cli | executablebooks/markdown-it-py @ `6f586542653a56d2ee8549a0dccfaa6ba5ebe14a` | README.md:L38;L98-L132 | `markdown-it {input}` → stdout | html_elements | `6447c05398c3f65e63688f3cbd38ac041aed34d8c63990985d3b901d72c24fd8` |
| html2text-cli | Alir3z4/html2text @ `5cf85510a2498546d5b48ad1bf7d75b146aac591` | README.md:L11;L66 | `html2text {input}` → stdout | text | `2fab77afbe25c49f10100274c62d93a1e4d0b673772c6722e04ae65b8abb61e5` |

Gaps, stated plainly:

- **Low diversity.** Three of four are Markdown→HTML converters and the fourth is HTML→Markdown. They were chosen because structural HTML checks let expected outputs be written without running the tools. Results from this set say little about other kinds of CLI.
- **commonmark.py is archived** (GitHub reports it archived; last push 2026-05-29). Its outcome is genuinely unknown, which is what a holdout case should be.
- **html2text expected text is the least certain fixture.** It assumes the default heading style (`#`), `**` for bold and `_` for emphasis, with no line wrapping at this length. The reviewer should check these against html2text's documented defaults before approving.
- **markdown2 README hedges** at L70 ("I think pip-based installation will enable this as well") about the `markdown2` command used at L72. That's a real ambiguity in the README, kept as-is.

Excluded from the holdout set and why:

| Candidate | Reason |
|---|---|
| jc | Workflow needs stdin (`cat table.txt \| jc --asciitable`); runner has no stdin mode |
| csvkit, Python-Markdown | README at HEAD has no CLI example (usage is only in external docs) |
| json-to-csv | No install step; README says "Written in Python 2.7"; CSV exact match is brittle without a csv validator |
| mistune | README has no CLI example |
| python-markdown2 as dev case | Kept for holdout so dev and holdout don't share a repo |

## Boundary set (3) — expected to stop, never counted in fix rate

Machine-readable contracts and expected end states: [`cases/boundary/`](boundary/README.md) (added 2026-10-20, static review only). Two findings from writing them: j2cli might be fixable with dependencies only (`zombie-imp` + `setuptools`, unverified), and yq stays a clear boundary (pip's `jq` package is Python bindings, not the `jq` command).

| Candidate @ commit | Expected state | Reason (with source) |
|---|---|---|
| kolypto/j2cli @ `2c26075c25e8c4fef9086e3bb5e6a4946f548231` (archived, 746 stars) | `unsupported` | j2cli/cli.py:L8 `import imp` (removed in Python 3.12) and j2cli/__init__.py:L4 `import pkg_resources` (needs setuptools, absent from a 3.12 venv). Installing setuptools would fix only the second; the first needs a source change. Good test that the agent stops instead of editing `.py` files |
| kislyuk/yq @ `a98d746b96d3e6e60d3cc6e9e38a57e5005482c6` | `unsupported` | README.rst:L10-L11 requires the system program `jq`, which pip can't install |
| phseiff/github-flavored-markdown-to-html @ `2eb59c26001e55dbfe6a4f3c42b61a8abeb934ea` | `needs_input` / `unsupported` | README.md:L317 converts "using the GitHub API" by default (network service); the offline mode needs extra dependencies (L233) |

Alternate: aaronsw/html2text @ `8ddc844b03042faf4875d465580ad122f9292978` (Python 2 code). Not used in the main set because it's the ancestor of the html2text holdout case.

## Runner/contract gaps found while screening (for A)

1. `python setup.py install` is rejected by `validate_steps`. Many older READMEs still use it.
2. No stdin input mode, so workflows like `jc --asciitable < input` can't be expressed.
3. A `csv` validator (parsed rows, column-order-insensitive) would make CSV tools usable.
4. Offline snapshot needs to build sdist-only packages (json2yaml, docopt) or the dev case fails as an infrastructure problem, not a README problem.
