# json2yaml：離線功能驗證已通過

本機真實執行結果為 already_passes。run_id：9a4e3a87ecfc4051a6c355d1c86b7b16。這是第三個已執行的開發 repo，不是 AI 修補，也不是保留集成績。

- [HTML 報告](../reports/offline-pilot-json2yaml-dc16deb4/run/report.html)
- [完整 JSON](../reports/offline-pilot-json2yaml-dc16deb4/run/report.json)
- [結果核對](../reports/offline-pilot-json2yaml-dc16deb4/outcome-audit.json)
- [真人確認來源](../reports/offline-pilot-json2yaml-dc16deb4/approval-evidence.json)
- [wheel 與 README 核對](../PUBLIC_EXPORT.md)

## sdist-only 是否支援離線

支援這次已準備的 snapshot。先前在受控 pypi_live 隔離環境把 json2yaml 1.2.0、docopt 0.6.2 的 sdist 建成 wheel，並下載 pyaml／PyYAML wheels。這次從乾淨 runner 使用這四個固定 hash 的 wheel，network=none；pip 安裝來源全部是 file:///bootstrap/wheels/。沒有連 PyPI，沒有現場從 sdist 建置，也沒有在主機執行第三方程式。

| 套件 | 版本 |
|---|---|
| json2yaml | 1.2.0 |
| docopt | 0.6.2 |
| pyaml | 26.7.0 |
| PyYAML | 6.0.3 |

這是已準備 wheel 的離線執行路徑，不是通用的離線 sdist 建置服務。新增套件仍需另外在隔離環境準備 artifact；離線 snapshot 不能觀察未來上游更新。

## 驗收與環境

固定 repo commit 為 b06ea713f6c817dc0af0f259da5c5afe7352174f。從該 commit 唯讀核對 README L11、L16、L35、L41–L42；stdout 說明確在 L42。案例 setup／workflow／兩組預期值都沒有改。

從正式 API GET 讀取 kevin 於 2026-10-19T23:43:16.141877+00:00 的現行確認，runtime 套到原 case 上；驗收 hash 仍為 59cb51e6e9377c61233719531b9bb980ace65fe0b3aa587b74fe1022f553aff5。沒有代人建立確認。案例檔保留靜態 draft，真人確認由 API 資料庫持有。

Linux arm64、Python 3.12、固定 image ID sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1。原始安裝後，person.yaml 與 settings.yaml 都通過 JSON 結構比對，兩個 CLI exit code 均為 0。執行與 staging 容器已清除。

本次透過本機 engine 執行，沒有向正式 API 提交任務，因此不出現在 /api/runs；保存的 record 明列 owner_local_engine、api_persisted=false，可作標示清楚的回放。報告已加入可攜入口及交接 ZIP。

新增模型呼叫 0；本機 runner 費用未計量，不把未知總成本記為 0。沒有修補或獨立修補重跑，沒有新增 verified_fix，沒有執行 holdout。json2yaml 的 pypi_live 功能試跑仍未執行；先前 live 紀錄只代表套件建置。
