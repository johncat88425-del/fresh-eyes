# 發布唯讀展示頁

B 準備（2026-10-20）。**這份只是步驟，還沒有發布。** 發布是對外公開，要 Chris 和 A 決定位置並明確同意後才做（TEAM_TASKS 的 DEPLOY-09）。

展示頁是純靜態檔案：沒有後端、沒有金鑰、不會執行任何東西。放在子路徑（例如 GitHub Pages 的 `https://帳號.github.io/fresh-eyes/`）也能用，B 已實測過。

## 發布前（每次都要做）

1. 用最新紀錄重建，並跑自動檢查：
   ```bash
   python3.12 web/demo/build.py --replace
   node --test web/tests/*.test.mjs
   ```
   build 會掃描本機路徑和像金鑰的字串，有就直接失敗；測試要全部通過。
2. 照 [TESTING.md](../../TESTING.md) 第 1 節在本機看一遍。
3. 確認 `dist/demo/` 裡只有這些：`index.html`、`app.js`、`client.js`、`i18n.js`、`evaluation.js`、`examples/`、`data/`、`.nojekyll`、`.fresh-eyes-demo`。

## 方法一：GitHub Pages（建議，repo 公開時一起做）

前提：公開 repo 已建立（DEPLOY-07）。

1. 把建好的展示頁複製到 repo 的 `docs/` 資料夾，然後 commit、push：
   ```bash
   python3.12 -c 'import shutil; shutil.copytree("dist/demo", "docs")'
   ```
   在新版專案根目錄操作；命令遇到既有 `docs/` 會停止，先保留舊版再手動更換，不刪掉其他文件。核對差異後才選擇性 commit／push，避免把目前暫存的其他變更一起提交。`reports/` 被忽略沒關係，展示使用已版本化的 recordings。
2. GitHub 上 repo 的 **Settings → Pages**：Source 選「Deploy from a branch」，Branch 選 `main`、資料夾選 `/docs`，按 Save。
3. 一兩分鐘後網址會出現在同一頁，通常是 `https://帳號.github.io/repo名稱/`。
4. 用這個網址重做 TESTING.md 第 1 節，另外用手機測一次（3.1）。
5. 把網址填進：
   - `submission/DEVPOST.md` 的「Try it」
   - `submission/README_PUBLIC_DRAFT.md`
   - 影片片尾字卡
   - TEAM_TASKS 的 DEPLOY-09

**之後更新：** 重建後重做步驟 1。GitHub Pages 有快取，最多約 10 分鐘才會看到新版。

## 方法二：不想放在 repo 裡

任何能放靜態檔案的服務都可以，例如 Netlify Drop（把 `dist/demo` 資料夾拖進網頁）。這需要另外開帳號，帳號是 Chris 的事，B 不代辦。

## 不要放上去的東西

- `reports/` 原始資料夾（裡面有 summary／session 檔案含本機路徑；展示頁只用 build 挑過、掃描過的部分）
- 任何 `.sqlite3`、`.env`、`work/` 下的檔案
- 雙輪工程範例（diff 裡有 `NEBIUS_API_KEY=synthetic-control-secret` 這種測試字串，放在公開頁面容易被誤會成外洩）
