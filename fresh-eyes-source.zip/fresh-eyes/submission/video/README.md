# 演示影片（只錄畫面，英文）

B，2026-10-24。依 `submission/DEMO_VIDEO_SCRIPT_V3.md` 自動產生（第 3 版：以 10/24 驗證通過的 Nemotron 修補為主角）。**目前是初稿**，畫面全部來自唯讀展示頁的真實紀錄。

## 產出（`out/`）

- `fresh-eyes-demo.mp4`：1920×1080，2:38，8 段，Mac 內建英文語音（Samantha），英文字幕直接畫在畫面上。
- `fresh-eyes-demo.srt`：同一份字幕，上傳 YouTube 用。
- `scene-1.jpg`～`scene-8.jpg`：每段中間的一張畫面，方便檢查。

## 和稿子不一樣的地方（初稿）

- **第 4 段不是 LIVE。** 現在沒有開 runner，所以改用 10/19 那次的真實紀錄，左下角標 `RECORDED · 19 Oct 2026`，旁白也改成「Here is that check, as it ran」，不說 live。A 開好 runner 後，用 `LIVE_URL=http://127.0.0.1:<port>` 重做這段，會真的按「Try the instructions」並顯示時間。
- **片尾字卡還沒有連結。** 等公開 repo 和展示網址確定後，用 `REPO=… DEMO=… bash submission/gallery/shoot.sh` 重拍 `endcard.png`，再重做影片。
- **第 6 段照實說：** 第一次試跑被我們自己的執行環境錯誤中斷，所以用同一個、沒改過的修補重新驗證，沒有再呼叫模型。
- **第 7 段的「under two cents」** 來自原試跑帳本（Nano $0.0002＋Ultra $0.0139，依 usage 計算，帳單未對帳）。
- 若之後有不中斷的完整 AI 修好、維護者說明或正式評估真的跑出來，先改稿再重做第 6–8 段。

## 重新產生

先照 `submission/gallery/README.md` 在 3003 啟動唯讀展示頁，再：

```bash
cd ~/Desktop/fresh-eyes && node submission/video/make_video.mjs
```

- 只做某幾段：`SCENES=1,2 node submission/video/make_video.mjs`
- 換聲音或語速：`VOICE=Daniel RATE=160 …`
- 用暫時的 Chrome 設定檔在背景錄，不會錄到你螢幕上其他東西。沒有模型呼叫，費用 $0。

## A 審閱（10/24）

MP4 原件 158.488 秒，1920×1080，H.264／AAC。已抽查第 7、8 段與片尾。第 8 段實際是「真實檢查」頁，並非合成狀態頁。原片保持不變；本包只附原版字幕 `out/fresh-eyes-demo-v3-original.srt`。`make_video.mjs` 和 v3 稿已修正下一版第 7–8 段的費用／拒絕原因說法，仍待 B 重製影片與新字幕，不能把新稿當作已同步到原片。片尾需顯示 repo 和展示網址；正式評估仍未執行。
