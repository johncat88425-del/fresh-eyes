# json2yaml 真人覆核單

> **已完成：** kevin 於 2026-10-20 00:43:16 BST 確認，鎖定雜湊等於目前驗收雜湊（B 以 `GET /api/cases` 唯讀核對）。

給實際確認驗收的人用。看完下面四項再到 UI 按確認；Claude（B）只做了靜態審閱，沒有執行過，也不能代替這一步。

- **案例：** `json2yaml-yaml2json`（[cases/json2yaml.json](json2yaml.json)）
- **Repo：** [drbild/json2yaml @ b06ea71](https://github.com/drbild/json2yaml/blob/b06ea713f6c817dc0af0f259da5c5afe7352174f/README.md)
- **要鎖定的驗收雜湊：** `59cb51e6e9377c61233719531b9bb980ace65fe0b3aa587b74fe1022f553aff5`
- **UI：** <http://localhost:5173/#/cases/json2yaml-yaml2json>

## README 原文（固定 commit）

| 行 | 內容 |
|---|---|
| L11 | `pip install json2yaml` |
| L14 | `json2yaml input.json output.yaml` |
| L16 | `yaml2json input.yaml output.json` |
| L35 | `yaml2json [-i <indent>] [<yaml_file>] [<json_file>]` |
| L38 | `-i, --indent=INDENT  Number of spaces to indent [default: 4]` |
| L41–L42 | `<json_file>` … "If not specified, writes to stdout." |

## 要判斷的四件事

1. **安裝步驟和 README 一樣嗎？** 案例的 setup 是 `pip install json2yaml`，來自 L11。
2. **用 stdout 可以嗎？** README 的範例（L16）把結果寫進 `output.json`，案例改成 `yaml2json {input}`，讓結果印在 stdout。依據是 L41–L42：不給輸出檔就寫到 stdout。這屬於 README 寫明的用法，但不是 L16 那一行的原樣。可以接受就繼續；不接受就先別確認，回報 B 改成輸出檔。
3. **選 yaml2json 而不是 json2yaml 可以嗎？** README 先列的是 json2yaml（L14）。案例選 yaml2json，因為輸出是 JSON，可以按結構比對；YAML 輸出只能逐字比對，容易因為格式細節誤判。
4. **兩組輸入的預期輸出對嗎？** 比對方式是 `json`：把輸出解析成 JSON 後比較內容，不比較空白和縮排。

| 輸入 | 內容 | 預期 JSON |
|---|---|---|
| `person.yaml` | `name: Ada` / `langs: [en, fr]`（區塊列表） | `{"name": "Ada", "langs": ["en", "fr"]}` |
| `settings.yaml` | `count: 3` / `enabled: true` / `nested: {key: value}` | `{"count": 3, "enabled": true, "nested": {"key": "value"}}` |

注意 `3` 是數字、`true` 是布林值，不是字串；這是 YAML 標準解析的結果。

另外，goal 寫的是「README: yaml2json input.yaml; output defaults to stdout」，是 L16 加 L41–L42 的摘要，不是逐字引用。goal 算在雜湊裡，如果想改寫，要在確認**之前**改（雜湊會跟著變）。

## 已知、不影響這次判斷

- `pyyaml`、`pyaml`、`docopt` 都沒有鎖版本；bin/json2yaml:L49 的 `pyaml.dump(..., safe=True)` 在目前版本會出警告，但只影響 json2yaml 方向，不影響本案例。
- `json2yaml` 1.2.0 和 `docopt` 0.6.2 在 PyPI 只有原始碼包。這是執行環境要處理的事（A 已準備，見 `reports/json2yaml-wheel-preparation.json`），不屬於驗收內容。

## 確認之後

1. 在 UI 看到「已鎖定」，鎖定的雜湊等於上面那串。
2. 在 [CASE_NOTES.md](CASE_NOTES.md) 的確認表填上姓名和時間（UK 時間，BST）。
3. 跟 B 說一聲；B 會用 `GET /api/cases` 唯讀核對姓名、時間和雜湊。
