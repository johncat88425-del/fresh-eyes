# 雙輪修補與四組評估：程式已接通，真實成果未增加

雙輪程式開發階段只用自有合成 repo、scripted runner、模型／catalog 假回應驗證。**新增真實模型呼叫 0、真實保留集執行 0。** 後續第三開發案的真實離線結果另見 [json2yaml 紀錄](JSON2YAML_OFFLINE.md)。 先前 md2html 的真實模型單輪仍是 needs_review；人工 verified_fix 仍是唯一已通過的修補來源。

## 執行規則

| 組別 | max_patch_rounds | 路由 | 每案最多模型請求 |
|---|---:|---|---:|
| A | 0 | 原始 README，不修補 | 0 |
| B | 1 | Nano 分類、Ultra 診斷 | 2 |
| C | 2 | 每輪 Nano 分類、Ultra 診斷 | 4 |
| D | 2 | 每輪分類與診斷都用 Ultra | 4 |

原始功能通過就停止，不硬產生 patch。每輪都還原成原始 pinned commit 的文件；第二輪看到第一輪候選與失敗證據摘要，回傳完整替代候選，不在上一輪半成品上疊加。原始來源 checkout、fixture、expected、validator 不改。

候選功能試跑成功後，還必須通過另一個乾淨 runner 的獨立重跑。第一輪成功不進第二輪；第一輪功能／獨立重跑失敗，或合法目標的精確字串比對不符，才可能進入已選定的第二輪。禁止的檔案／結構變更、非法 JSON、HTTP 錯誤、未知費用、額度或時間不足都停止。每個推論階段只送一次，沒有 HTTP retry 或隱藏 fallback。

一般 engine 預設仍是一輪，沒有偷偷擴大先前單輪授權。run_case 的 max_patch_rounds 要明確設成 2；手動 patch 只能一輪，不能拿它冒充 B／C／D。

## 預算與時間

同一案兩輪共用原持久帳本：classify／diagnose／classify_r2／diagnose_r2。相同 stage 已有保留紀錄就拒絕重送；不重建帳本補額度。所有選定模型組別採相同 per-case 金額及時間上限，整批啟動前按最壞配置保留檢查 batch 上限。任何已發送請求有未知費用，整批停止並保存 batch-stop.json，不開始下一個組別。

控制端在每個階段前檢查 deadline，推論 HTTP timeout 不超過剩餘時間；清理與部分 runtime 準備仍可能讓總牆鐘時間超出目標，所以沒有宣稱平台硬性終止保證。這些是本批客戶端限制，不是 Nebius 帳戶層限額；跨不同 output-root 的另一次手動啟動仍是另一批，不能當成自動續跑或沿用先前授權。

原 US$0.02 的單輪試驗已結束。新批次必須有自己的明確金額與範圍；本輪沒有開啟付費開關。

## 給 B 的新增資料欄位

- evidence.repair_rounds[]：每輪的 round、status、完整 diagnosis、完整 candidate_patch、拒絕理由及該輪 diff。
- evidence.candidate_patch／diagnosis／patch：保留最新一輪的相容入口；完整歷程請看 repair_rounds。
- attempts[].round：候選／獨立重跑對應輪次；原始 README 為 null。phase 仍用 candidate_patch／fresh_verification，可重複出現。
- diagnosis.classification_model／diagnostic_model：成功回覆的實際模型 ID。**D 組分類也是 Ultra，不能把標題寫死為 Nano。** 完整呼叫明細仍以 ledger 為準。
- 最新候選若不存在，不沿用上一輪的 patch；每輪原始提案仍保留在 repair_rounds。

兩份 UI 工程範例：

- [第二輪成功範例](../web/examples/two-round-success.json)
- [第二輪預算停止範例](../web/examples/two-round-budget-stop.json)

兩者頂層 data_origin=example、executed=false，內部是 engineering_test，不是新增真實 verified_fix。模型 ID／費率都是測試常數，不能拿來報費用。它們只放在 web/examples，沒有加入 /api/runs 或正式 results。

## 評估與本機明確啟用

evaluation-freeze 已升級為 v2，固定模型 ID／context／費率來源、B/C/D 輪數／路由、共同單案上限與整批上限。執行可按案例交錯 A→B→C→D。匯出會核對組別、輪數、路由、ledger 來源與逐筆費用計算，拒絕人工候選改標模型、單輪改標 C 或工程假資料混入成績；可合併同一 freeze 的不同批，但重複 case+group 直接拒絕。

evaluation-run 預設不讀 key、不連模型。只有明確加 --enable-paid-models、--env-file、--tokenizer-references，且真人覆核、凍結配置和額度全部符合，才進入付費啟用；先唯讀查當時官方 catalog，比對模型、context、輸入／輸出／cached 費率及 request fee。價格變動就停止，不沿用舊價格發送。

本輪只測試 mock catalog 與 mock 回應，沒有實際使用上述付費旗號。Web API 仍固定 paid_calls_enabled=false。完整操作見 [評估 runbook](../evaluation/RUNBOOK.md)。
