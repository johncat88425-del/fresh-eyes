#!/usr/bin/env python3
"""Build a new public-source ZIP candidate; never publish or alter private evidence."""
import argparse
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
sys.path.insert(0, str(ROOT / 'packaging'))
from public_source import build

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--handoff', type=Path, default=ROOT / 'dist/fresh-eyes-teammate.zip')
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
print(json.dumps(build(args.handoff, args.output), indent=2))
