# Demo video script v3: the AI-written fix is the centre (B, 2026-10-24; revised: says what Fresh Eyes is first)

Scenes 5–7 now show the first uninterrupted AI fix (run `5c225204…`, 24 Oct): the failing README, Nemotron 3 Nano's
classification, Nemotron 3 Ultra's line-anchored patch, then a pass in a fresh container and again in an independent
clean run, with no human edits. Same rules as v2: under 3 minutes, English, only our own app on screen, no music,
every scene labelled RECORDED with its date (or LIVE), nothing staged.

**Made:** `submission/video/out/fresh-eyes-demo.mp4`, 2:52 (pauses between and inside sentences), 1920×1080, Apple voice Zoe (Premium) at 165 words a minute + burned-in captions,
plus `fresh-eyes-demo.srt`. Built by `node submission/video/make_video.mjs` from the read-only demo (17 recordings).

## Scenes (398 words of narration)

| # | Label | Screen | Narration |
|---|---|---|---|
| 1 | RECORDED SITE | `#/` | This is Fresh Eyes. It checks whether a project's README actually works for someone seeing it for the first time. It follows the instructions in a clean environment and checks the real output. When something is broken, it uses NVIDIA Nemotron to find a fix, and then proves it. |
| 2 | RECORDED · 19 Oct 2026 | `#/runs/10175eee…` | Here's a real example. The md2html project tells you to install the requirements, then run md2html. We followed it exactly, on a clean machine. The install worked, but the md2html command didn't exist. New users hit problems like this all the time, and maintainers rarely see them. |
| 3 | RECORDED SITE | `#/start` | Before any check runs, a person decides what success means: which README lines, two sample inputs, and the exact expected output. That decision is locked with a hash, so the AI can't quietly change the test to make itself pass. And the expected answers never go inside the test environment. |
| 4 | RECORDED · 19 Oct 2026 | `#/answer/10175eee…` | Then Fresh Eyes runs the README exactly as written, in a fresh container. A clean exit isn't enough. Only the right output counts. For md2html, the answer is no: the instructions don't work as written. |
| 5 | RECORDED · 24 Oct 2026 | `#/runs/5c225204…` | This is where Nemotron, running on Nebius Token Factory, comes in. Nemotron 3 Nano sorts the failure as a documentation problem. Nemotron 3 Ultra finds the cause: the README installs the dependencies, but never the package that provides the command. So it suggests a small change to the README, tied to exact line numbers. It can only edit the README or dependency files, never the source code. |
| 6 | RECORDED · 24 Oct 2026 | `#/runs/5c225204…` | A suggested fix doesn't count until it's proven. With the change, the README passes the locked check in a fresh container, and passes again in a second, independent clean run. Start to finish, it took about twenty-four seconds, with no human edits along the way. |
| 7 | RECORDED · 24 Oct 2026 | `#/runs/5c225204…` | Every model call is logged, with the model name, the tokens used, and the estimated cost. This fix took two calls and about half a cent, calculated from usage; the final bill has not been reconciled yet. The worst-case cost is set aside before each call, so a run never starts a call it can't afford. Not every attempt succeeds. When a suggested edit doesn't fit, it's rejected, and the run stops instead of guessing. |
| 8 | RECORDED SITE | `#/examples` | Everything you've seen comes from real runs, including the failures. Fresh Eyes. A newcomer's first five minutes, checked and proven. Links to the demo and the source code are below. |

Scene 4 becomes LIVE (`LIVE_URL=…`) if A runs the local app with the runner on during recording; its narration then says
"Now a live check" and the time is shown.

## Honesty checks (each one is in the narration or on screen)

- The fix shown is run `5c225204…`: original README failed, real Nano classification (documentation), real Ultra
  proposal (`pip install .`, README lines 38–42), candidate run passed, independent clean re-run passed, no human
  edits and no saved proposal reused (api/MODEL_SUCCESS_END_TO_END_20261024.md).
- "About twenty-four seconds": the report records about 23.5 s for the whole run, including installs and both checks.
- "Two calls and about half a cent, calculated from usage; the final bill has not been reconciled": Nano $0.00016674 +
  Ultra $0.00530200 = $0.00546874. No Tavily call in this run, so the narration doesn't mention Tavily.
- "Not every attempt succeeds": the same batch also had two failed attempts (`2978ec94…`, `0c0141f2…`); the video shows
  the 20 Oct refusal (`e9a04f64…`, labelled RECORDED · 20 Oct) as the example. No success rate is claimed.
- Still only one repository (md2html) has an AI fix, and there are no formal evaluation results; the video says neither.

## Still to do before upload

- End card now shows the repo and Pages URLs (regenerated 24 Oct). Recheck them if either moves before submission.
- If WIN-4 produces an uninterrupted end-to-end AI fix, or the maintainer note / formal evaluation run for real, update
  scenes 6–8 first, then rebuild.
- Chris watches it once and uploads it to YouTube from their own account.
