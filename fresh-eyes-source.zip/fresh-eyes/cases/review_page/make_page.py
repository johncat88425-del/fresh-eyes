"""Embed data.json and guidance.json into template.html -> kevin-review.html (B, 2026-10-22)."""
import json
import hashlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
safe = lambda obj: json.dumps(obj, ensure_ascii=False).replace("</", "<\\/")  # keep README text from closing the <script>
data = json.loads((HERE / "data.json").read_text())
for case in data['cases']:
    subject = {key:case[key] for key in ('goal','repo','readme_source','setup','workflow','fixtures','acceptance_sha256')}
    case['review_subject_sha256'] = hashlib.sha256(json.dumps(subject,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
page = (HERE / "template.html").read_text()
state = (HERE / 'review_state.js').read_text().replace('export function ', 'function ')
page = page.replace("__DATA__", safe(data)).replace("__GUIDE__", safe(json.loads((HERE / "guidance.json").read_text()))).replace('__REVIEW_STATE__', state)
head, body = page.split('</style>', 1)
page = '<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'+head+'</style></head><body>'+body+'</body></html>'
(HERE / "kevin-review.html").write_text(page)
print(len(page), "bytes")
