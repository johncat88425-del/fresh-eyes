# 即時 PyPI 真實試跑與套件準備

> 2026-10-19。Linux arm64、pypi_live、開發審閱；模型／付費呼叫 0，沒有建立真人 approval。

## 本輪結果

| API run ID | 案例／方式 | 結果 |
|---|---|---|
| a7bf8fc4969e44ec9436ea79cc7cee00 | mistletoe 原始 README | already_passes，兩組功能驗收通過 |
| 10175eee750c464fa7ce86ad4c84f037 | md2html 原始 README | unresolved；requirements 安裝成功，但 CLI 不存在 |
| 563db9062b7b4e48a4490e41b6792ff6 | md2html 人工候選 | verified_fix；候選與最終獨立乾淨重跑各通過兩組驗收 |

- [mistletoe HTML](../reports/live-pilot-20261019-88770a71/state/reports/a7bf8fc4969e44ec9436ea79cc7cee00/report.html)
- [md2html 原始 HTML](../reports/live-pilot-20261019-88770a71/state/reports/10175eee750c464fa7ce86ad4c84f037/report.html)
- [md2html 人工修補 HTML](../reports/live-pilot-20261019-88770a71/state/reports/563db9062b7b4e48a4490e41b6792ff6/report.html)
- [實際 diff](../reports/live-pilot-20261019-88770a71/md2html-manual-candidate.diff)、[一致性檢查](../reports/live-pilot-20261019-88770a71/evidence-audit.json)、[套件版本與來源／hash 摘要](../reports/live-pilot-20261019-88770a71/dependency-resolution.json)。

md2html 的修補仍只有 README 安裝行 pip install -r requirements.txt → pip install .。不是模型產生的 patch，也沒有改產品原始碼或驗收內容。

五次 attempt 使用不同的新容器，同一 Python base image：
sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1。
每次離線 wheelhouse 清單均為空，實際經 PyPI-only proxy 解析及安裝，禁用 pip cache。報告保留 install report／freeze。這些不是五個 repo；本輪仍只有兩個開發 repo、三筆 API 任務。

已核對 contract／acceptance hash、獨立容器、兩組輸出、人工作者、實際 patch 端點及模型呼叫數；任務結束後沒有留下 fresh-eyes 容器。原始與人工修補結果和先前離線試跑相同，但不能據此宣稱觀察到了版本漂移。

## 出站關卡

[第三次 gate 報告](../reports/egress-gate-20261019-attempt3.json)通過 full／timeout／interrupt 三階段：
19 個實際下載／拒絕／路由檢查通過，下載的 packaging wheel hash 符合 PyPI；逾時及注入中斷後，worker／proxy／staging／network／暫存 image 都已清除。範圍與限制見 [EGRESS_GATE](EGRESS_GATE.md)。

第一次 gate 因 VM 未運行，在 preflight 停止；第二次揭露 trusted bundle 目錄權限問題，非 root worker 讀不到腳本。已修正為僅供程式與資料讀取的 0755 bundle 並加回歸測試。兩份失敗報告保留，沒有覆寫成通過。

API health 的 live_pypi_platform_verified 及單次 network_policy.runtime_egress_verified 仍是 false：尚未把獨立 gate 報告接成 API 自動認證。這輪由 owner 明確啟用 live，附上實際 gate 證據；不把欄位值改成沒有逐次證據支援的 true。

## 第三案的套件缺口已補齊

[隔離建置報告](../PUBLIC_EXPORT.md)記錄四個 wheels：
json2yaml 1.2.0、docopt 0.6.2、pyaml 26.7.0、PyYAML 6.0.3。
前兩個 sdist 的原始 hash 已與 PyPI metadata 比對；pip wheel 與 build hooks 在隔離 Linux worker 中執行，主機只讀取／校驗封包。下載及建置結果的 wheel hash 已保存，既有同名檔案沒有被不同內容覆寫。

這是 prepared_not_functionally_tested。沒有執行 yaml2json 案例；contract 仍為 draft，需 B 真人覆核後才排功能驗證。

## 交給 B

[本輪真實資料包](../OPEN_REPORTS.html)包含 API snapshots、HTML／JSON、實際 diff、出站證據、套件建置報告和 hash manifest，不含 SQLite、key、第三方 checkout、wheels 或 VM。不是 API 匯入資料庫；回放時標明「真實紀錄回放」，不能當成新的執行。

目前本機 [前端](http://127.0.0.1:50628/?api=http://127.0.0.1:50629)／[health](http://127.0.0.1:50629/api/health) 只在 Chris 這台且程序運行時可用；另一台電腦用資料包。新增畫面的瀏覽器預覽回應緩慢，本輪依據是實際 API／Docker 報告；B 還需做新資料的真人畫面 QA。

116 個工程測試通過。後續仍需真人覆核、approval 跨機交接、保留集正式入口、真實模型整合、夜間排程與漂移實驗。這不是 AI 修復、正式保留集評估或普遍修復率。
