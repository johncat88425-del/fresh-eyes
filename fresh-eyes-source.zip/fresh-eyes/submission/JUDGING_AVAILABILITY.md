# Judging access and maintenance plan

<!-- A drafted this 2026-10-20; B revised it 2026-10-21 (B25). Review notes: api/B25_JUDGING_REVIEW.md -->

The public service is a free, read-only recording viewer on GitHub Pages. It
does not submit repositories, execute code or call a model. Opening or refreshing
it incurs no Nebius inference or sandbox usage. The MIT source archive includes
the local runnable prototype, tests and versioned recordings. These are separate
from the recorded viewer; a recording is not a live agent execution.
Judges' step-by-step instructions: [JUDGE_TESTING_INSTRUCTIONS.md](JUDGE_TESTING_INSTRUCTIONS.md).

## Dates

From the current rules (https://nebiusglobalaihackathon.devpost.com/rules, read
2026-10-21). Recheck them at submission.

| Period | Pacific time | UK time |
|---|---|---|
| Submission deadline | 30 Oct 2026 10:00 | 30 Oct 2026 17:00 (GMT) |
| Judging | 1 Dec 2026 09:00 – 15 Dec 2026 12:00 | 1 Dec 17:00 – 15 Dec 20:00 (GMT) |
| Winners announced | around 11 Jan 2027 12:00 | around 11 Jan 2027 20:00 (GMT) |

The owner keeps the public repository, the release, its hashes and the Pages
site available through **15 December 2026**, and on through **31 January 2027**
to cover the announcement.

## The submitted links cannot change

After the deadline the rules allow no changes to the submission. So:

- Submit only addresses that will not move: the repository URL, the release tag
  and the Pages URL served from that repository.
- Tag the release at submission. The Pages site shows exactly that build.
  Results or features added after 30 October stay out of the judged copy (use a
  branch).
- During judging, only restore identical content at the same addresses. Never
  rename the GitHub account or repository, make it private, or delete the
  release: each of these breaks a submitted link.

## Free access

- Judges can inspect all recorded reports, usage ledgers and the manual patch
  without an account, payment, API key, backend or owner computer being awake.
- The source/test build can rebuild the same viewer and run the engineering tests
  locally without a provider account. Python 3.12 and Node are prerequisites.
- Running a new third-party repository requires a container runtime (tested by
  the owner only on macOS with the bundled VM setup). Real model repair also
  requires explicit local activation and a separately activated provider key and
  budget. This release does not offer a hosted free live repair service.
- This version provides recordings and a local test build. Free live AI repair
  is not supplied; whether this meets the full testing requirement remains a
  submission readiness gap. If hosted live repair is added, build and test it
  before submission under a separate explicit budget. Never expose an
  unrestricted paid API to the public.

## Availability checks

Manual checks, about 10 minutes each, no model cost:

| When | Who |
|---|---|
| 29 Oct, before submitting | A, then B independently |
| 30 Nov or 1 Dec | Project owner |
| 8 Dec | Project owner |
| 15 Dec, UK morning | Project owner |

Each check:

1. Open the Pages URL in a private window, in English and Chinese. Press Start
   and go through to an answer.
2. Open **Detailed view**. Deep-link to the latest unresolved model report and to
   the manual verified patch, then reload both.
3. Download the release archive and compare its SHA-256 with the recorded value.
4. Write the date and result in TEAM_TASKS.

## Responsibilities and recovery

| Responsibility | Owner | Concrete action |
|---|---|---|
| Source and Pages availability | A / project owner | Keep the account, repository and release; run the checks above |
| Report wording and usability | B | Check links, English, mobile views and recorded outcome labels |
| Rebuild/recovery | A | Restore the release archive, verify the manifest, rebuild with `web/demo/build.py` (or export `web/demo/single_file.py`) and redeploy **the same tagged build to the same Pages URL**. Keep the old release |
| Spending | Project owner | Paid execution is off by default and nothing public can turn it on. Any further paid run needs the owner's explicit approval and budget |
| Billing | A + project owner | Keep usage and provider observations separate; unknown billed amounts stay null until reconciled |

No recurring model calls, nightly paid jobs, storage purchases, subscriptions or
automatic monitoring have been enabled. Hosting costs $0: GitHub Pages on a
public repository.

If GitHub Pages itself is down, the submitted repository still holds the source,
the single-file viewer export and the test build, so judges can open or rebuild
the viewer locally. The Devpost URL cannot be replaced after the deadline.

## Publication gate

Before marking the public deployment complete:

- verify the actual public URL in an anonymous browser;
- open the latest unresolved model report and the manual verified patch;
- reload a deep link;
- download and check the source archive;
- record the commit and SHA-256 in TEAM_TASKS.

Another physical machine and genuine human holdout/boundary reviews remain
separate gates.
