"""Build the data for kevin's acceptance-review page (B, 2026-10-22).

For each case: the contract as written, its acceptance hash recomputed by the engine and compared with the review
file, and the README lines it cites, fetched from GitHub at the pinned commit. Mechanical checks only; no judgment.
Run from the project root:  PYTHONPATH=src python3.12 cases/review_page/build_review_data.py > cases/review_page/data.json
"""
import json
from pathlib import Path
import re
import sys
import urllib.request

from fresh_eyes.contracts import Contract

ROOT = Path(__file__).resolve().parents[2]
CASES = [  # (group, file, review file listing it)
    ("holdout", "cases/holdout/markdown2.json", "evaluation/reviews-20261020-v4.json"),
    ("holdout", "cases/holdout/commonmark.json", "evaluation/reviews-20261020-v4.json"),
    ("holdout", "cases/holdout/markdown-it-py.json", "evaluation/reviews-20261020-v4.json"),
    ("holdout", "cases/holdout/html2text.json", "evaluation/reviews-20261020-v4.json"),
    ("boundary", "cases/boundary/j2cli.json", "evaluation/boundary-reviews-20261020-v4.json"),
    ("boundary", "cases/boundary/yq.json", "evaluation/boundary-reviews-20261020-v4.json"),
    ("boundary", "cases/boundary/gfm-to-html.json", "evaluation/boundary-reviews-20261020-v4.json"),
]


def cited(source):
    """'README.md:L35;L63-L72;pyproject.toml:L2' -> {'README.md': [(35, 35), (63, 72)], 'pyproject.toml': [(2, 2)]}"""
    out, current = {}, None
    for part in source.split(";"):
        m = re.fullmatch(r"(?:([^:]+):)?L(\d+)(?:-L(\d+))?", part.strip())
        if not m:
            continue
        current = m.group(1) or current
        a, b = int(m.group(2)), int(m.group(3) or m.group(2))
        out.setdefault(current, []).append((a, b))
    return out


def fetch(repo, commit, path):
    owner_repo = repo.rstrip("/").split("github.com/")[1]
    url = f"https://raw.githubusercontent.com/{owner_repo}/{commit}/{path}"
    with urllib.request.urlopen(url, timeout=30) as r:
        return r.read().decode("utf-8", "replace").splitlines()


# Lines the review checklists (cases/HOLDOUT_REVIEW.md, cases/boundary/REVIEW.md) ask the reviewer to read beside the
# cited ones; shown as context, never as part of the case.
CONTEXT = {
    "markdown2-cli": {"README.md": [(63, 63), (67, 67), (70, 70)]},
    "commonmark-cmark": {"README.rst": [(73, 73)]},
    "markdown-it-py-cli": {"README.md": [(104, 106), (132, 132)]},
    "html2text-cli": {"README.md": [(30, 31)]},
    "j2cli-render": {"README.md": [(4, 7)]},
    "yq-query": {"README.rst": [(10, 11)]},
    "gfm-to-html-convert": {"README.md": [(155, 155), (191, 191), (194, 194), (201, 203), (216, 216), (221, 221), (233, 233), (317, 317)]},
}

# A case rewritten after a human rejected it: the review file still lists the version it replaces until A re-freezes.
# Only an exact match with the replaced hash is treated as a new version; any other mismatch still blocks the page.
NEW_VERSIONS = {
    "html2text-cli": {"replaces": "2fab77afbe25c49f10100274c62d93a1e4d0b673772c6722e04ae65b8abb61e5",
                      "change": "比對方式由 text 改為 text_lines（kevin 10/24 的意見）；預期內容不變"},
}

expected_boundary = {c["case_id"]: c for c in json.loads((ROOT / "cases/boundary/expected.json").read_text())["cases"]}
cases = []
for group, rel, review_file in CASES:
    data = json.loads((ROOT / rel).read_text())
    contract = Contract.from_dict(data)
    listed = None
    if review_file:
        listed = next((a for a in json.loads((ROOT / review_file).read_text())["approvals"] if a["case_id"] == data["case_id"]), None)
    sources = dict(cited(data["readme_source"]))
    for step in data["setup"]:
        for f, ranges in cited(step["source"]).items():
            sources.setdefault(f, []).extend(ranges)
    excerpts = []
    context = CONTEXT.get(data["case_id"], {})
    for path in list(sources) + [f for f in context if f not in sources]:
        lines = fetch(data["repo"]["url"], data["repo"]["commit"], path)
        cited_n = {n for a, b in sources.get(path, []) for n in range(a, b + 1)}
        context_n = {n for a, b in context.get(path, []) for n in range(a, b + 1)} - cited_n
        excerpts.append({"file": path, "total_lines": len(lines),
                         "lines": [[n, lines[n - 1] if n <= len(lines) else None, "cited" if n in cited_n else "context"]
                                   for n in sorted(cited_n | context_n)]})
    cases.append({
        "group": group, "file": rel, "case_id": data["case_id"], "goal": data["goal"],
        "repo": data["repo"], "readme_source": data["readme_source"],
        "setup": data["setup"], "workflow": data["workflow"], "fixtures": data["fixtures"],
        "acceptance_sha256": contract.acceptance_sha256,
        "review_file": review_file,
        "hash_matches_review_file": None if listed is None or (data["case_id"] in NEW_VERSIONS and listed["acceptance_sha256"] == NEW_VERSIONS[data["case_id"]]["replaces"])
                                    else listed["acceptance_sha256"] == contract.acceptance_sha256,
        "new_version": ({"replaces_acceptance_sha256": NEW_VERSIONS[data["case_id"]]["replaces"], "change": NEW_VERSIONS[data["case_id"]]["change"]}
                        if listed and data["case_id"] in NEW_VERSIONS and listed["acceptance_sha256"] == NEW_VERSIONS[data["case_id"]]["replaces"] else None),
        "review_status_in_file": None if listed is None else listed["status"],
        "expected_result_status": expected_boundary.get(data["case_id"], {}).get("expected_result_status"),
        "excerpts": excerpts,
    })
json.dump({"generated_by": "cases/review_page/build_review_data.py", "cases": cases}, sys.stdout, ensure_ascii=False, indent=1)
