# Token Factory check, 2026-10-18 (UK)

Made by B (Claude, an AI tool) from Chris's Mac, using the API key Chris saved in a local `.env` file. The key never appeared in the commands' output and is not in this file. Purpose: confirm the key works, list the NVIDIA models and their prices, and make one minimal Nano call.

**What this file contains:** the commands (key replaced by `$NEBIUS_API_KEY`) and the output exactly as our scripts printed it at the time. The full raw JSON responses were not saved, so this is the printed output, not a raw capture. Cost of the one completion call is estimated below from the usage and list prices; it was not reconciled against a bill.

## 1. Model list

```sh
curl -s https://api.tokenfactory.nebius.com/v1/models -H "Authorization: Bearer $NEBIUS_API_KEY"
```

Printed output (filtered to ids containing "nemotron" or "nvidia"):

```
HTTP 200
total models: 28
nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B
nvidia/Nemotron-3_5-Lightning
nvidia/Nemotron-3-Ultra-550b-a55b
nvidia/nemotron-3-super-120b-a12b
nvidia/Nemotron-3.5-Super-VL
--- sample keys: ['id', 'created', 'object', 'owned_by']
```

## 2. Model metadata

```sh
curl -s "https://api.tokenfactory.nebius.com/v1/models?verbose=true" -H "Authorization: Bearer $NEBIUS_API_KEY"
```

Printed fields for the NVIDIA models (prices are USD per token; limits as returned):

| Model id | Context | Prompt / completion price | Rate limits | Region | Features |
|---|---|---|---|---|---|
| `nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B` | 262,144 | 0.00000006 / 0.00000024 | 800,000 tokens/min, 100 req/min | FI `eu-north1` | tools, reasoning |
| `nvidia/Nemotron-3_5-Lightning` | 1,048,576 | 0.00000006 / 0.00000024 | 400,000 tokens/min, 600 req/min | FI `eu-north1` | tools, reasoning |
| `nvidia/Nemotron-3-Ultra-550b-a55b` | 1,048,576 | 0.000001 / 0.000003 | 200,000 tokens/min, 300 req/min | US `us-central1` | tools, reasoning |
| `nvidia/nemotron-3-super-120b-a12b` | 262,144 | 0.0000003 / 0.0000009 | 200,000 tokens/min, 300 req/min | US `us-central1` | tools, reasoning |
| `nvidia/Nemotron-3.5-Super-VL` | 1,048,576 | 0.0000003 / 0.0000009 | 2,000,000 tokens/min, 300 req/min | US `us-north1` | tools, reasoning |

## 3. One Nano completion

```sh
curl -s https://api.tokenfactory.nebius.com/v1/chat/completions \
  -H "Authorization: Bearer $NEBIUS_API_KEY" -H "Content-Type: application/json" \
  -d '{"model":"nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B","max_tokens":200,
       "messages":[{"role":"user","content":"Reply with exactly: hello from nemotron"}]}'
```

Printed output:

```
content: '\nhello from nemotron'
reasoning field present: False
usage: {'completion_tokens': 66, 'prompt_tokens': 24, 'total_tokens': 90, 'completion_tokens_details': None, 'prompt_tokens_details': None}
```

Estimated cost at the listed Nano prices: 24 × 0.00000006 + 66 × 0.00000024 = US$0.00001728. Not reconciled.

## Not covered here

- The promo-code email and the card requirement are from Chris's own account (screenshot shared on 2026-10-18), not from these calls.
- Sandboxes findings come from A's read-only check in `api/SANDBOX_ACCESS.md`.
- No other model calls were made by B. The 2026-10-19 local pilot made zero model calls (`api/LOCAL_PILOT.md`).
