"""WIN-5 static scan v4: README says `pip install -r requirements.txt`, and requirements.txt pins an old release that
has no CPython 3.12 wheel (or can no longer build from source), so the documented install fails on a fresh 3.12
environment; raising the pin in requirements.txt is the fix. Then the README runs a script or command on an input
file. Reads public files only; never downloads archives, installs or executes anything."""
import json, re, sys, time, urllib.error, urllib.parse, urllib.request

API = "https://api.github.com"
H = {"Accept": "application/vnd.github+json", "User-Agent": "fresh-eyes-win5-static-scan"}
# First release with CPython 3.12 wheels (PyPI); older pins must build from source, which a slim image can't, or
# (PyYAML 5.x/3.x) fails with Cython 3 under build isolation.
FIRST_312 = {"pyyaml": (6, 0, 1), "lxml": (4, 9, 3), "numpy": (1, 26, 0), "pandas": (2, 1, 1), "scipy": (1, 11, 2),
             "pillow": (10, 0, 1), "matplotlib": (3, 8, 0), "psutil": (5, 9, 6), "ujson": (5, 8, 0), "regex": (2023, 8, 8),
             "pycryptodome": (3, 19, 0), "cffi": (1, 16, 0), "markupsafe": (2, 1, 4), "simplejson": (3, 19, 2), "pyzmq": (25, 1, 1)}


def search(q):
    for _ in range(4):
        try:
            url = f"{API}/search/repositories?q={urllib.parse.quote(q)}&sort=stars&order=desc&per_page=50"
            with urllib.request.urlopen(urllib.request.Request(url, headers=H), timeout=20) as r:
                return json.loads(r.read()).get("items", [])
        except urllib.error.HTTPError as e:
            if e.code in (403, 429):
                time.sleep(40); continue
            raise
    print(f"search gave up: {q}", file=sys.stderr)
    return []


def raw(repo, path):
    try:
        with urllib.request.urlopen(urllib.request.Request(f"https://raw.githubusercontent.com/{repo}/HEAD/{path}", headers=H), timeout=20) as r:
            return r.read(400000).decode("utf-8", "replace")
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError):
        return None


def version(text):
    nums = re.findall(r"\d+", text)[:3]
    return tuple(int(n) for n in nums) + (0,) * (3 - len(nums)) if nums else None


seen, hits = set(), []
for q in sys.argv[1:]:
    items = search(q)
    time.sleep(8)
    for item in items:
        repo = item["full_name"]
        if repo in seen or item.get("archived") or item.get("fork"):
            continue
        seen.add(repo)
        req = raw(repo, "requirements.txt")
        if not req:
            continue
        stale = []
        for n, line in enumerate(req.splitlines(), 1):
            m = re.match(r"\s*([A-Za-z0-9_.-]+)\s*==\s*([0-9][0-9A-Za-z.]*)", line)
            if m and m.group(1).lower() in FIRST_312 and version(m.group(2)) and version(m.group(2)) < FIRST_312[m.group(1).lower()]:
                stale.append({"line": n, "pin": line.strip(), "first_312": ".".join(map(str, FIRST_312[m.group(1).lower()]))})
        if not stale:
            continue
        readme_name = next((n for n in ("README.md", "README.rst", "readme.md") if raw(repo, n)), None)
        readme = raw(repo, readme_name) if readme_name else ""
        lines = readme.splitlines()
        installs = [i + 1 for i, l in enumerate(lines) if re.search(r"pip3? install -r requirements", l)]
        usage = [f"L{i + 1}: {l.strip()[:120]}" for i, l in enumerate(lines)
                 if re.match(r"\s*(\$\s*)?(python3? [\w./-]+\.py|[a-z][\w-]+) [^\n]*\.(ya?ml|json|csv|md|markdown|html?|xml|txt|tsv|ini|toml)\b", l)]
        if installs and usage:
            hit = {"repo": repo, "stars": item.get("stargazers_count"), "pushed": (item.get("pushed_at") or "")[:10],
                   "description": (item.get("description") or "")[:100], "readme": readme_name,
                   "install_lines": installs[:3], "usage": usage[:4], "stale_pins": stale[:4]}
            hits.append(hit)
            print(json.dumps(hit), flush=True)
print(f"scanned {len(seen)}; {len(hits)} candidates", file=sys.stderr)
