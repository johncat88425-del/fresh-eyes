"""WIN-5 static scan v2: CLIs whose entry module imports pkg_resources without declaring setuptools.

On Python 3.12, new venvs no longer ship setuptools, and setuptools 82 removed pkg_resources, so these fail as soon as the
documented command runs; adding a dependency (setuptools<82) is inside Fresh Eyes's fix scope. Reads public files only
(GitHub search API + raw.githubusercontent.com); never downloads archives, installs or executes anything."""
import json, re, sys, time, tomllib, urllib.error, urllib.parse, urllib.request

API = "https://api.github.com"
H = {"Accept": "application/vnd.github+json", "User-Agent": "fresh-eyes-win5-static-scan"}


def search(q):
    for _ in range(3):
        try:
            url = f"{API}/search/repositories?q={urllib.parse.quote(q)}&sort=stars&order=desc&per_page=40"
            with urllib.request.urlopen(urllib.request.Request(url, headers=H), timeout=20) as r:
                return json.loads(r.read()).get("items", [])
        except urllib.error.HTTPError as e:
            if e.code == 403:
                time.sleep(30); continue
            raise
    return []


def raw(repo, path):
    try:
        with urllib.request.urlopen(urllib.request.Request(f"https://raw.githubusercontent.com/{repo}/HEAD/{path}", headers=H), timeout=20) as r:
            return r.read(400000).decode("utf-8", "replace")
    except urllib.error.HTTPError:
        return None


def entry_points(repo):
    eps, deps = {}, ""
    py = raw(repo, "pyproject.toml")
    if py:
        try:
            d = tomllib.loads(py)
            eps.update(d.get("project", {}).get("scripts", {}))
            deps += json.dumps(d.get("project", {}).get("dependencies", [])) + json.dumps(d.get("tool", {}).get("poetry", {}).get("dependencies", {}))
        except tomllib.TOMLDecodeError:
            pass
    st = raw(repo, "setup.py") or ""
    for m in re.finditer(r"['\"]([A-Za-z0-9_.-]+)\s*=\s*([A-Za-z0-9_.]+):([A-Za-z0-9_]+)['\"]", st):
        eps[m.group(1)] = f"{m.group(2)}:{m.group(3)}"
    m = re.search(r"install_requires\s*=\s*\[(.*?)\]", st, re.S)
    deps += m.group(1) if m else ""
    deps += raw(repo, "requirements.txt") or ""
    return eps, deps, bool(py), bool(st)


def module_text(repo, module):
    parts = module.split(".")
    for base in ("", "src/"):
        for path in (f"{base}{'/'.join(parts)}.py", f"{base}{'/'.join(parts)}/__init__.py"):
            t = raw(repo, path)
            if t is not None:
                return path, t
    return None, None


seen, hits = set(), []
for q in sys.argv[1:]:
    items = search(q)
    time.sleep(7)
    for item in items:
        repo = item["full_name"]
        if repo in seen or item.get("archived") or item.get("fork"):
            continue
        seen.add(repo)
        eps, deps, has_pyproject, has_setup = entry_points(repo)
        if not eps:
            continue
        found = []
        for cmd, target in list(eps.items())[:4]:
            module = target.split(":")[0]
            path, text = module_text(repo, module)
            if text and re.search(r"^\s*(import pkg_resources|from pkg_resources import)", text, re.M):
                blockers = re.findall(r"^\s*(?:import imp\b|from imp import|import distutils|from distutils)", text, re.M)
                found.append({"command": cmd, "module": path, "blockers": blockers})
        if found and not re.search(r"setuptools", deps, re.I):
            hit = {"repo": repo, "stars": item.get("stargazers_count"), "pushed": (item.get("pushed_at") or "")[:10],
                   "description": (item.get("description") or "")[:100], "pyproject": has_pyproject, "setup_py": has_setup,
                   "commands": found}
            hits.append(hit)
            print(json.dumps(hit), flush=True)
print(f"scanned {len(seen)}; {len(hits)} candidates", file=sys.stderr)
