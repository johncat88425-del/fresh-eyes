# 單輪模型預算：按請求保留額度

完整模型 context 容量仍取自當時官方 catalog，沒有把 Ultra 的 1,048,576 改成小數字來降低保留額度。未提供經核對的請求上界時，ModelCaller 仍採完整 context 的保守保留方式。

本次單輪上限是 Chris 明確批准的 US$0.02，最多一次 Nano 分類與一次 Ultra 診斷，沒有自動重試。所有階段共用同一持久帳本；原始推論失敗、逾時或費用未知，不會建立新帳本重送。

## 本次使用的輸入上界

NemotronPromptBound 僅適用兩個固定模型 ID，以及恰好一則 system、一則 user 的純文字訊息。沒有工具、歷史、圖片或額外訊息欄位。

先核對 NVIDIA 官方 tokenizer 與 chat template 的固定 SHA-256。Tokenizer 沒有 normalizer；Split 不增加字元，ByteLevel 按 UTF-8 bytes 建立符號，BPE 合併只會減少數量。兩則訊息的模板分支只插入少量 framing；另外保留 **2,048 tokens** 的 framing 額度。因此使用「兩則文字的 UTF-8 byte 數＋2,048」作為保守的輸入 token 上界，再加上請求明確限制的 completion 上限，按官方費率保留額度。

參考檔只當資料讀取，不執行 tokenizer Python code 或 Jinja。雜湊不符、訊息形狀不同、超出 context 或帳本餘額不足，都在推論之前停止。原始參考檔只留在 A 的工作區，不要求 B 下載 34 MB 參考檔來做前端。

模型只收到限量 README／依賴片段及執行證據。README 片段截斷會明示；環境 probe 保留狀態，完整原始 log 仍在報告。實際 workflow 的巢狀 process.stderr 會包含在診斷，避免漏掉「找不到 CLI」的主要錯誤。

## 限制與對帳

這是**客戶端保留規則**，依賴服務端採用相容的 NVIDIA tokenizer／chat template 及核對過的費率，不能代替 Nebius 帳戶層的扣款限制。回應中的實際 prompt_tokens 必須在保留上界以內；超出會記為未知費用並阻止下一階段，不能事後撤回已送出的請求。

calculated_usd 使用實際 usage 計算；billed_usd 未取得帳單依據時保持 null。即使回應成功，仍不能把計算值說成已核對的帳戶扣款。cached usage 沒有相應費率時也不猜測。

## 來源

- [Nebius Chat completion API](https://docs.tokenfactory.nebius.com/api-reference/inference/create-chat-completion)
- [Nano tokenizer](https://huggingface.co/nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B-BF16/tree/main)
- [Ultra tokenizer 與 chat template](https://huggingface.co/nvidia/NVIDIA-Nemotron-3-Ultra-550B-A55B-NVFP4/tree/main)

精確參考雜湊固定於 src/fresh_eyes/prompt_budget.py；當次模型、費率、上界及檢查時間保存於 model-pilot 的 preflight.json 和 model-ledger.json。一般 Web API 的付費開關仍關閉。
