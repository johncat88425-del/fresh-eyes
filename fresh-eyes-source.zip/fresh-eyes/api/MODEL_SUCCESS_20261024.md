# 10/24：第一份 AI 候選修補通過驗證

**Ultra 產生的原封不動提案，已通過候選與獨立乾淨重跑；不是一次不中斷的端到端成功，不計正式評估。**

- 原模型試跑：[完整報告](../reports/model-trial-md2html-research-20261024-v3/report.html)，run `1a5f5135c92f4d15a5ff6dabe0a78b64`。Nano 分類 dependency → Tavily basic 查到一份 repo README → Ultra 產生兩處行號 README 修改，setup 改 `pip install -e .`。文字／行號檢查通過後，在容器 bootstrap 複製目錄遇到 `.github 2` 的權限錯誤。原狀態保留 infrastructure_error。
- 保存候選驗證：[完整報告](../reports/saved-model-candidate-md2html-20261024-v1/report.html)，run `5ac511039adb4977b32ef129e86ee006`。在系統暫存目錄執行，原始 README failed → 同一候選 passed → 獨立乾淨重跑 passed。沒有改提案、驗收、來源 commit 或 human approval。候選 JSON 和 patch SHA-256 都與原模型試跑一致；不是把人工 patch 改標籤。
- 新工具 `scripts/validate-saved-model-candidate.py` 先核對原 report／binding／ledger／real calls／契約與原確認，再啟動容器；不讀 key，不呼叫模型，另存新紀錄，原失敗不改。執行暫存改系統目錄以避開報告樹被桌面同步工具監看；`.github 2` 不在固定 commit 的 Git tree，不能將其權限失敗算 repo 故障。
- 本次有費用的只有原試跑 2 次呼叫：Nano .00019740，Ultra .01387400，usage 合計 **US$0.01407140**，實際 billed 未知；Tavily 1 basic credit。獨立驗證新增模型／Tavily 呼叫都是 0，費用不重複計。前置還有一筆 0 推論失敗（Ultra 新增快取價格欄位，舊快照擋下），原件留存。
- 舊的四呼叫授權沒有被重開。這次 .03 的新授權實際派送 2 calls 後關閉；之後 Chris 另授權的 1.70 是新的分項用途，記錄在共用任務表。

展示已收進 20 筆真實回放，保存候選頁連回原模型診斷／Tavily／費用；startup 和 boundary 也各自標示範圍。只有同一 md2html 專案的一個 AI 候選通過，不能把重驗次數當作不同 repo。正式四案沒有執行，html2text v2 仍待 kevin。

證據：[來源與驗證對照](../evidence/first-model-candidate-verified-20261024.json)。
