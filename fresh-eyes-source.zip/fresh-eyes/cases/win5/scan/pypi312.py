"""For pins like PyYAML==5.4.1: does PyPI have a wheel CPython 3.12 on linux/arm64 can install, and which is the first
release that has one? Reads PyPI's JSON API only."""
import json, re, sys, urllib.request


def releases(name):
    with urllib.request.urlopen(f"https://pypi.org/pypi/{name}/json", timeout=20) as r:
        return json.loads(r.read())["releases"]


def usable(files):
    """A wheel pip would pick on CPython 3.12, Linux aarch64: pure-Python, abi3 (cp3x <= 312), or cp312 itself."""
    for f in files:
        n = f["filename"]
        if not n.endswith(".whl") or f.get("yanked"):
            continue
        tags = n[:-4].split("-")[-3:]
        py, abi, plat = tags
        if plat == "any" and re.search(r"py3|py2\.py3", py):
            return n
        if ("linux" in plat and ("aarch64" in plat)) and (py == "cp312" or (abi == "abi3" and int(py[3:] or 0) <= 312)):
            return n
    return None


def key(v):
    return tuple(int(x) if x.isdigit() else 0 for x in re.findall(r"\d+|[a-z]+", v.lower()))


for spec in sys.argv[1:]:
    name, pin = spec.split("==")
    rel = releases(name)
    stable = sorted((v for v in rel if re.fullmatch(r"[\d.]+", v)), key=key)
    first = next((v for v in stable if usable(rel[v])), None)
    print(f"{spec}: wheel for cp312/aarch64 = {usable(rel.get(pin, [])) or 'NONE (must build from source)'}; "
          f"sdist = {any(f['packagetype'] == 'sdist' for f in rel.get(pin, []))}; first release with one = {first}")
