#!/usr/bin/env python3
"""Export source, interfaces and selected recorded reports without private state."""

import hashlib
import json
from pathlib import Path
import posixpath
import re
import sys
import zipfile

project = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(project / "src"))
from fresh_eyes.handoff import report_files, validate_links
paths = [project / name for name in ("AGENTS.md", "TESTING.md", "README.md", "HANDOFF.md", "TEAM_TASKS.md", "B_HANDOFF.md", "FEEDBACK.md", "RUNTIME_RECOVERY.md", "DECISIONS.md", "WIN_PLAN_1022.md", "LICENSE", "pyproject.toml", ".gitignore", ".env.example")]
for directory in ("src", "tests", "scripts", "cases", "api", "web", "evaluation", "evidence", "submission", "packaging", "design/beginner"):
    for path in (project / directory).rglob("*"):
        if path.is_file() and not path.is_symlink() and "__pycache__" not in path.parts:
            public_diff = path.suffix == ".diff" and any(path.is_relative_to(project / base) for base in ("web/demo/recordings", "web/demo/evaluation-recordings"))
            if not path.name.startswith(".") and (public_diff or path.suffix in {".py", ".md", ".json", ".js", ".mjs", ".html", ".css", ".srt", ".png", ".sh", ".Dockerfile", ".patch"} or path.name in {"fresh-eyes", "docker-local"}):
                paths.append(path)
files = {path.relative_to(project).as_posix(): path.read_bytes() for path in sorted(set(paths))}
files.update(report_files(project))
# Include the new owner-verified reports without rewriting their evidence bytes.
# The intake's private account identifier remains under .fresh-eyes and is never selected.
progress = project / 'evidence/real-progress-20261024.json'
if progress.is_file():
    proof = json.loads(progress.read_text())
    for name, expected in proof['report_hashes'].items():
        if hashlib.sha256((project / name).read_bytes()).hexdigest() != expected:
            raise ValueError('Current execution report changed after verification: ' + name)
    current_links = []
    for folder in ('github-rich-cli-startup-20261024-v1', 'boundary-baseline-20261024-v1', 'md2html-manual-recheck-20261024-v1', 'saved-model-candidate-md2html-20261024-v1', 'nemotron-note-probe-20261024-v1'):
        directory = project / 'reports' / folder
        for path in sorted(directory.rglob('*')):
            if path.is_symlink():
                raise ValueError('A current report cannot contain a symlink')
            if path.is_file() and path.suffix in {'.json', '.html', '.diff', '.md'}:
                name = path.relative_to(project).as_posix()
                files[name] = path.read_bytes()
                if path.name == 'report.html':
                    current_links.append("<li><a href='" + name + "'>" + path.parent.name + "</a></li>")
    index = files['OPEN_REPORTS.html'].decode()
    index += "<section><h2>10/24 真實重驗</h2><p>Startup、邊界 baseline、人工修補、保存的 AI 提案獨立驗證與未發送說明草稿；各報告標明作者／呼叫，均不計正式評估。</p><ul>" + ''.join(current_links) + '</ul></section>'
    files['OPEN_REPORTS.html'] = index.encode()
for name in ("PROJECT3.md", "TEAM_WORK_PLAN.md", "PROJECT2.md", "START_HERE.md"):
    plan = project / name
    if not plan.exists():
        plan = project.parent / name
    if plan.is_file():
        files[name] = plan.read_bytes()
for name, raw in list(files.items()):
    if name.endswith(".md"):
        text = raw.decode()
        if name == "TEAM_TASKS.md":
            text = "> 交接快照：工作期間請從 Chris 主工作區或 Desktop 的共用入口開啟即時 TEAM_TASKS.md；不要把本解壓副本當作第二份即時總表。\n\n" + text
            text = re.sub(r'\bu_[A-Za-z0-9]{8,}\b', '<private-account-id>', text)
        text = text.replace("../PROJECT3.md", "PROJECT3.md" if name == "README.md" else "../PROJECT3.md")
        text = text.replace("../dist/fresh-eyes-live-pilot-2026-10-19.zip", "../OPEN_REPORTS.html")
        text = text.replace("../dist/fresh-eyes-real-pilot-2026-10-19.zip", "../OPEN_REPORTS.html")
        if name in {"START_HERE.md", "TEAM_WORK_PLAN.md"}:
            text = text.replace("(fresh-eyes/", "(")
            text = text.replace("[交接程式 ZIP](dist/fresh-eyes-teammate.zip)", "[程式啟動說明](HANDOFF.md)")
            text = re.sub(r"\]\(dist/fresh-eyes-[^)]+\.zip\)", "](OPEN_REPORTS.html)", text)
        files[name] = text.encode()
files["READ_ME_FIRST.txt"] = ("先解壓整個資料夾，雙擊 OPEN_REPORTS.html 閱讀報告，不需要啟動 API。\n程式包請解壓到新目錄，不要覆蓋朋友正在修改的前端或共用任務入口。\n包內 TEAM_TASKS.md 是交接快照；仍使用主工作區的即時共用總表記錄工作。\n需要啟動產品時，在此目錄分別執行 python3.12 scripts/fresh-eyes serve 與 python3.12 web/serve.py。\n").encode()
validate_links(files)
for name, raw in files.items():
    if name.endswith(".md"):
        for target in re.findall(r"\]\(([^)]+)\)", raw.decode()):
            if "://" in target or target.startswith("#"):
                continue
            path = posixpath.normpath(posixpath.join(posixpath.dirname(name), target.split("#")[0]))
            if path not in files:
                raise ValueError(f"Broken packaged documentation link: {name} -> {target}")
manifest = {"format": "fresh-eyes-teammate-handoff-v3", "api_version": "0.2.1", "paid_calls_enabled": False,
            "recorded_reports_included": True, "files": {}}
output = project / "dist/fresh-eyes-teammate.zip"
output.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
    for relative, raw in sorted(files.items()):
        manifest["files"][relative] = hashlib.sha256(raw).hexdigest()
        info = zipfile.ZipInfo("fresh-eyes/" + relative)
        info.create_system = 3
        executable = relative in {"scripts/fresh-eyes", "scripts/docker-local"} or (
            (project / relative).is_file() and (project / relative).stat().st_mode & 0o111)
        info.external_attr = ((0o100755 if executable else 0o100644) << 16)
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, raw)
    archive.writestr("fresh-eyes/handoff-manifest.json", json.dumps(manifest, indent=2) + "\n")
with zipfile.ZipFile(output) as archive:
    if archive.testzip():
        raise ValueError("Archive integrity check failed")
    for relative, expected in manifest["files"].items():
        if hashlib.sha256(archive.read("fresh-eyes/" + relative)).hexdigest() != expected:
            raise ValueError("Archive manifest mismatch")
print(json.dumps({"archive": str(output), "files": len(files) + 1, "bytes": output.stat().st_size,
                  "sha256": hashlib.sha256(output.read_bytes()).hexdigest()}, indent=2))
