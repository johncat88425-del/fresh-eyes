# 10/20 凍結前的實際狀態

**尚未正式凍結，也沒有執行四個保留案例。** cases/holdout/freeze.json 是先前的案例 bytes 清單，不是 evaluation-freeze 產生的正式實驗版本。evaluation/results.json 仍不存在。依既定英國時間計畫，10/23 凍結、10/24 評估。

| 關卡 | 目前狀態 |
|---|---|
| B 最新 history.zip | d3941e97…a5b435；12 檔加交接說明，新增覆核單及更新交件草稿已合併 |
| 四份案例完整性 | hash 一致，仍為 draft；沒有修改驗收或先跑結果 |
| 固定 Git 來源 | 四份都已下載到工作區 work/holdout-sources，HEAD 等於固定 commit |
| 原始碼匯出 | 四份都可匯出。html2text 的 docs/authors.md 內部連結轉為 archived AUTHORS.rst 的普通檔案，不建立主機 symlink |
| 工程測試 | 最新數量見 TEAM_TASKS；不算保留集執行或模型成功 |
| 真人覆核 | [覆核單](../cases/HOLDOUT_REVIEW.md)已備妥，四案仍待真人判斷；目前沒有替人填 approved |
| 模型開發試跑 | [10/20 真實雙輪](../api/MODEL_TRIAL_RESULT_20261020.md)已完成，4 次呼叫、needs_review，單次授權已結束；證據截取修正未再做真實驗證 |
| 正式環境／配置 | v1 採 Linux arm64／Python 3.12，四份原契約一致；10/20 同 image 的實際 PyPI／拒絕出站／清理 gate 通過。模型／當時價格／共同額度仍須 freeze 前核對；沒有宣稱 amd64 已測 |

原始碼匯出只讀 Git archive、複製檔案，不安裝或執行任何保留集程式。內部連結會記錄來源、目標及內容 SHA；外部、循環、缺失目標、目錄連結和 hard link 仍拒絕。[核對 JSON](../PUBLIC_EXPORT.md)保留各 commit、archive hash 與實際匯出結果。

正式評估預設 **pypi_live**，每次記錄實際解析的依賴。offline_snapshot 可作另外的重現對照，不能宣稱觀察到上游漂移。[RUNBOOK](RUNBOOK.md)已同步此模式；新增的 B 覆核單也已加上這項區分。

現在可先由真人讀完覆核單，把不合理之處記下來。正式 freeze 建立後，真人才在對應 reviews 檔填實際姓名、時間與結論；不為了跑起來改 draft case bytes。[10/20 真實兩輪試跑](../api/MODEL_TRIAL_RESULT_20261020.md)的 US$0.03 單次授權也已結束；未來模型驗證需新的明確授權。
