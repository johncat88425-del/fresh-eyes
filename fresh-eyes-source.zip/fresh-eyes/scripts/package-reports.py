#!/usr/bin/env python3
"""Rebuild standalone reports and compatibility filenames from saved evidence."""

import json
from pathlib import Path
import sys

project = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(project / "src"))
from fresh_eyes.handoff import report_files, write_archive

for filename, mode in [("fresh-eyes-reports-fixed-2026-10-19.zip", None),
                       ("fresh-eyes-live-pilot-2026-10-19.zip", "pypi_live"),
                       ("fresh-eyes-real-pilot-2026-10-19.zip", "offline_snapshot")]:
    files = report_files(project, mode)
    if mode is None:
        (project / "OPEN_REPORTS.html").write_bytes(files["OPEN_REPORTS.html"])
    print(json.dumps(write_archive(project / "dist" / filename, files), indent=2))
