Read README.md and PUBLIC_EXPORT.md. This is a public source export, not the private owner handoff. Publication is a separate step.
