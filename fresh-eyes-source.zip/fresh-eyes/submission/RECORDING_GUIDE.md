# 錄影指南

給錄影的人用（B 準備，2026-10-20）。旁白照 [VIDEO_SCRIPT.md](VIDEO_SCRIPT.md)，英文字幕草稿在 [subtitles_draft.srt](subtitles_draft.srt)。所有畫面都用**唯讀展示頁**錄，裡面只有真實紀錄，不會不小心按到執行或確認。

## 錄之前

1. 產生並開啟展示頁：
   ```bash
   cd ~/Desktop/fresh-eyes && python3.12 web/demo/build.py --replace && python3 -m http.server 3001 --bind 127.0.0.1 --directory dist/demo
   ```
2. 瀏覽器：
   - 打開 http://127.0.0.1:3001/ ，右上角切到 **English**；
   - 視窗約 1280×800，縮放 110%；
   - 隱藏書籤列，關掉其他分頁和通知。
3. 錄影用 macOS 內建：⌘⇧5 →「錄製選取的部分」，框住瀏覽器視窗。
4. 先錄畫面、後配旁白比較好剪。等待時間剪掉的話，畫面要標「sped up」。
5. 錄影當天先跑一次 [TESTING.md](../TESTING.md) 第 1 節，確認展示頁正常。

## 今天就能錄的完整版（約 2:50）

| 時間 | 打開哪裡 | 怎麼操作 | 旁白 |
|---|---|---|---|
| 0:00–0:15 | `#/runs/10175eee750c464fa7ce86ad4c84f037` | 停在標題「Unresolved」，往下捲到 Original README run；展開一組輸出的 stderr，讓 `No such file or directory: 'md2html'` 出現在畫面上 | 腳本 0:00 那句 |
| 0:15–0:25 | `#/` 首頁 | 慢慢掃過標題和三個步驟 | 腳本 0:15 那句 |
| 0:25–0:45 | `#/cases/md2html-markdown` | 捲過 README 出處、兩組輸入和預期輸出；停在 Locked（kevin、時間、雜湊）；展開 Approval history | 腳本 0:25 那句 |
| 0:45–1:35 | `#/runs/563db9062b7b4e48a4490e41b6792ff6` | 依序停在：原始失敗 → Patch（Manual candidate，diff 一行）→ Candidate patch run 通過 → Final clean re-run 通過；最後回到頂端「Fix verified」 | 腳本 0:45「Version recordable now」那句，不念最後一句「Next, the same loop…」 |
| 1:35–1:55 | `#/runs/e9a04f641acb4c71b7ff0932e58f87e8` | 停在「Repair round 1 of 2 · Proposal rejected」和被拒提案（Rejected · Not applied、matched 0 times），再捲到「Repair round 2 of 2 · No candidate」和它的說明 | 下方「知道何時該停」旁白（代替還沒跑的邊界鏡頭） |
| 1:55–2:20 | 等 10/24 的真實結果 | 有結果：`#/evaluation`，停在指標和時間與費用表。沒有結果：**整段剪掉**，不要錄空的評估頁 | 腳本 1:55 那句，數字從 `evaluation/summary.md` 抄 |
| 2:20–2:40 | `#/runs/e9a04f641acb4c71b7ff0932e58f87e8` | 捲到兩輪的 Model calls 表（模型 ID、tokens、成本），再看右邊 Costs 卡片（$0.0136 pending reconciliation、Billed unknown） | 腳本 2:20 那句，不念夜間檢查那句 |
| 2:40–2:50 | 片尾字卡 | 名稱、賽道、repo 網址、展示頁網址（發布後） | 腳本 2:40 那句 |

**「知道何時該停」旁白（1:35，代替邊界鏡頭）：**

> "Here's Nemotron on the same failure. Nano and Ultra diagnose it correctly, but Ultra's edit doesn't match the README, so the patch checker refuses it. In the second round, Ultra says it can't see enough to fix it, and stops instead of guessing. Nothing was applied."

這段要照實講：它是「沒有修好、選擇停下」，不是「修好了」。

## 之後要換掉或補上的鏡頭

| 鏡頭 | 什麼時候換 | 換成什麼 |
|---|---|---|
| 0:45 修復 | AI-11 有模型 verified_fix 時 | 腳本的「Model version」：那一筆真實紀錄，旁白念 Nemotron 提出修補 |
| 1:35 停下 | 邊界案例真的跑過（CASE-15） | 腳本 1:35 的邊界鏡頭；兩輪那段可縮短保留 |
| 1:55 評估 | 10/24 之後 | 真實評估頁；數字只用 `evaluation/summary.md` 裡的 |

## 錄完核對

- [ ] 每個畫面的 run ID 都在 [TESTING.md](../TESTING.md) 第 1 節驗過
- [ ] 人工修正那段的旁白有說「prepared by hand」，沒有說成 Ultra 修的
- [ ] 沒有出現任何快速檢查（任意 repo）或夜間檢查的畫面
- [ ] 總長不超過 3:00，上傳 YouTube 設為公開，字幕已上傳
