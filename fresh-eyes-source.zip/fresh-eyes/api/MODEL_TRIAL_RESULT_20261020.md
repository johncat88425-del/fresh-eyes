# md2html：10/20 單次兩輪真實模型試跑

**結果 needs_review，沒有模型修復成功。** 這次依 Chris 的新授權，只執行一次 md2html-markdown 開發試跑：pypi_live、nano_ultra、最多兩輪／4 次模型呼叫，共用 US$0.03 及 600 秒，不重試、不 fallback。實際 4 次呼叫，按 usage 計算 **US$0.01362438**；帳戶實際扣款尚未對帳（null）。控制程序共 30.127 秒，沒有觸及外部 600 秒終止限制。

run_id：e9a04f641acb4c71b7ff0932e58f87e8。查看 [完整 HTML 報告](../reports/model-trial-md2html-20261020-003-once/report.html)、[前端格式紀錄](../reports/model-trial-md2html-20261020-003-once/run-record.json)、[帳本](../reports/model-trial-md2html-20261020-003-once/model-ledger.json)及[結果核對](../reports/model-trial-md2html-20261020-003-once/outcome-audit.json)。這是本機 engine 紀錄，沒有寫入正式 API 歷史，也不計任何評估成績。

## 實際發生的事

| 階段 | 結果 |
|---|---|
| 原始 README | requirements 安裝成功，但沒有建立 md2html 指令，兩組功能輸出失敗 |
| 第一輪 Nano／Ultra | 診斷為漏裝專案本身，提出 README 修改及對應 setup；完整提案已保存 |
| 第一輪 patch 檢查 | old 字串與 README 匹配 0 次，候選被拒，未套用、未試跑 |
| 第二輪 Nano／Ultra | 仍診斷為漏裝專案；Ultra 指出看不到完整安裝原文，回傳 patch=null |
| 最終 | needs_review，沒有候選功能試跑或獨立乾淨重跑；沒有 verified_fix |

四次模型回應都正常完成，不是輸出截斷、費用不足或 timeout。第二輪沒有候選是模型選擇停止猜測。原驗收 hash 47631208…b749a 及 kevin 的姓名／確認時間均未改。這仍是安裝步驟遺漏，沒有觀察到依賴漂移。

| 呼叫 | prompt tokens | completion tokens | usage 計算 USD |
|---|---:|---:|---:|
| classify（Nano） | 3141 | 430 | 0.00029166 |
| diagnose（Ultra） | 3191 | 878 | 0.005825 |
| classify_r2（Nano） | 3360 | 463 | 0.00031272 |
| diagnose_r2（Ultra） | 3418 | 1259 | 0.007195 |

每階段恰好一次，共用同一持久帳本。reasoning tokens 已包含在 completion，沒有重複計費。沒有重試、替代模型或第五次呼叫；剩餘額度不構成下一次授權。

## 查到的控制端問題及免費修正

執行時的 context() 只把長 README 的頭尾送給模型，剛好省略 L36–L45 安裝段及 L144–L153 使用段。第一輪因而猜了不存在的原文；第二輪看見精確匹配失敗後不再提出 patch。

試跑結束後，已改為優先保留 case／setup 引用行號的連續原文，再利用剩餘空間保留概覽；附 included_line_ranges、missing_cited_ranges，並禁止模型把不同片段接成原文。離線核對確認 md2html 的完整安裝段及使用段都可見，1895 bytes，安裝原文在來源恰好匹配一次，無缺少引用範圍。見 [離線回歸核對](../reports/model-trial-md2html-20261020-003-once/offline-context-regression.json)。

**修正沒有再用真實模型驗證。** 這次執行的 trial-plan 保存修正前的 code hash，不能把後續修正說成當時已使用，也沒有為了驗證修正再次消耗授權。原報告、候選及費用證據不回填、不改成成功。

## B 現在可驗收

1. 第一輪被拒候選已有真實完整資料，讀 evidence.repair_rounds[0].candidate_patch，顯示原文、替換內容、setup、rejected 原因及「未套用」。不必再用合成提案代替。
2. 第二輪 diagnosis 有真實 explanation，但沒有 candidate_patch；照實顯示沒有候選，不能沿用第一輪提案。最新頂層 candidate_patch 已清除是刻意的，完整歷程在 repair_rounds。
3. 時間軸顯示原始失敗 → 第一輪診斷／被拒 → 第二輪診斷／無候選 → needs_review；不畫不存在的候選／最終驗收。
4. 顯示 4 次真實呼叫及 usage 小計，實際扣款未知。回放資料保留回放標記，勿匯入評估成績。

## 已關閉與限制

單次 CLI 已退出，授權記錄為 consumed，沒有改任何持久付費開關；一般 API 的模型入口仍預設關閉。此次檢查時 8765 沒有執行中的 API，不能把它描述成已取得 live health 回應。試跑容器及 PyPI 代理網路已清理，Docker 清單中沒有殘留 fresh-eyes 容器／網路。

只有先前人工 md2html patch 通過 verified_fix。正式四案仍未執行、未正式凍結，沒有 evaluation/results.json。這次報告包可直接解壓看，不需要重啟 API 或開啟付費。

修正及封裝後 190 個 Python、10 個前端工程測試通過；這些測試沒有再使用真實模型，也沒有保留集執行。
