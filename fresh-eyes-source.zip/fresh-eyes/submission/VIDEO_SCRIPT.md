# Video script draft — Fresh Eyes (target 2:50, hard limit 3:00)

Draft updated 2026-10-24. The current candidate has a newly reverified manual fix and real boundary baselines, plus an unchanged AI-generated candidate that passed separate verification after a bootstrap failure; formal evaluation has not run. Official tips: pitch, not tutorial; lead with the problem; **say Nebius Token Factory and the NVIDIA model names out loud**. Every shot marked **[real run]** must be a recording of an actual run in the submitted build; if it isn't available, cut the shot rather than mock it. Waiting time may be cut, but say "sped up" on screen.

| Time | Screen | Narration (spoken) |
|---|---|---|
| 0:00–0:15 | md2html README install line, then its report: install OK, both inputs `No such file or directory: 'md2html'` **[real run: `10175eee…`, live PyPI]** | "Here's a README that tells you to install the requirements and then run `md2html`. Follow it exactly, in a clean container, and the command doesn't exist. That install step never creates it." |
| 0:15–0:25 | Fresh Eyes home: quick check box and the three-step flow | "Fresh Eyes is an agent that reads your README like a newcomer, runs it in a clean environment, and only calls a fix verified when the real output is right." |
| 0:25–0:45 | Step 1 and 2: case with README line numbers, goal, two inputs and expected outputs; "Locked" with the reviewer's name, time and hash, and the approval history **[real: the three dev cases were approved by the real reviewer on 2026-10-19/20. Show one of those, or record the reviewer approving a new real case that day. Never approve under a stand-in name to film it]** | "First, a person approves the acceptance check: two inputs, their expected outputs, and the README lines they come from. Then it's locked by hash, so the agent can never edit it." |
| 0:45–1:35 | **Model candidate version, recordable now with the interruption disclosed:** Original trial `1a5f5135…`: failure → Nano → Tavily → Ultra → accepted patch → environment error; then linked verification `5ac51103…`: exact same patch → candidate passes → independent re-run passes | "It runs the README exactly as written. It fails. Nemotron 3 Nano, on Nebius Token Factory, classifies the failure from the log. Nemotron 3 Ultra reads the evidence and proposes one small fix: here, one line in the README. Fresh Eyes never touches source code. The first trial stopped on an environment permission error. We kept that failure and verified the exact saved AI patch separately, without another model call. The candidate and an independent clean run both pass. This verifies the AI proposal; it is not an uninterrupted run." |
| 0:45–1:35 | **Version recordable now:** md2html report in the UI: original run failed → manual candidate patch (one-line diff) → candidate run passes → final clean re-run passes **[real run: `10cef22d…`, live PyPI, 24 October recheck]** | "Fresh Eyes runs the README exactly as written, and it fails. The fix here is a one-line README change, prepared by hand as a candidate. Fresh Eyes doesn't take our word for it: it starts again from a clean container with only that patch, checks the real output against the locked check, then does it once more from scratch. Two clean passes, so it's a verified fix. Next, the same loop with Nemotron proposing the patch." [Last sentence only if that's still the plan on recording day.] |
| 1:35–1:55 | yq boundary baseline (`0f766043…`): install passes, output fails because `jq` is absent **[real README-only run]** | "A successful installation still does not prove the workflow works. This original-README check fails on a missing system tool. No model was called here, and we keep it out of repair success rates." |
| 1:55–2:20 | Current evaluation page showing **not run**, then rich-cli startup replay `ebd91531…` | "Our four-repository comparison has not run yet: one revised check still needs human approval. Separately, a previously unregistered repository, rich-cli, installs and starts using only its documented commands. That proves startup, not functional correctness." |
| 2:20–2:40 | Cost ledger with real model IDs and usage; nightly history if it exists **[real run]** | "Every model call is in a ledger with the real model ID, tokens and cost, priced from Token Factory's own model catalog. Unknown costs stay unknown." [If nightly checks exist:] "Approved cases re-run every night, so drift shows up before a newcomer finds it." |
| 2:40–2:50 | Title card: name, track, repo URL | "Fresh Eyes. For maintainers and DevRel teams who want a newcomer's first five minutes to keep working. Built with NVIDIA Nemotron on Nebius Token Factory." |

## Evidence for each shot (as of 2026-10-19)

| Shot | Status | Evidence |
|---|---|---|
| 0:00 problem | Recordable now | `api/LIVE_PILOT.md`, run `10175eee750c464fa7ce86ad4c84f037` (offline repeat: `c2dd01c4…`) |
| 0:25 approval | Recordable now: mistletoe, md2html and json2yaml are locked by the real reviewer (kevin). The history panel appears only once the API runs the new build | `cases/CASE_NOTES.md` approval table; `GET /api/cases` |
| Optional: rejected proposal in full | Recordable now from real data: run `e9a04f64…` (20 Oct) round 1, which shows the full proposal (text to find, replacement `pip install -e .`, setup step), "Rejected · Not applied" and the reason "matched 0 times" | `api/MODEL_TRIAL_RESULT_20261020.md`, `api/B_QA.md` section R2 |
| 0:45 fix loop, manual version | Recordable now | latest manual recheck `10cef22de8974ff7b5134635e39ee0ae`, including its hash-checked patch; the earlier `563db906…` remains historical |
| 0:45 fix loop, model version | Recordable now as two linked records: original `1a5f5135…` stopped on bootstrap permissions; unchanged model patch verified in `5ac51103…`, with zero new calls. Do not edit these into a single uninterrupted run | `api/MODEL_PILOT.md`, `api/MODEL_TRIAL_RESULT_20261020.md` |
| Optional: "knows when to stop" | Recordable now as a replay, best from run `e9a04f64…`. Round 1 is rejected by the patch checker; in round 2 Ultra says it can't see the full install section and returns no patch. Narrate it as the agent declining to guess, not as a fix | run `e9a04f64…` (two rounds) or `e5150fec…` (one round); show the "Recorded real run · replay" badge |
| 1:35 boundary stop | Recordable as README-only baselines, not AI decisions: all three installed but remained unresolved; yq run `0f766043…` | `cases/boundary/README.md` |
| 1:55 evaluation | Not run yet; only the source inventory is pinned. Human review and the formal code/config freeze remain pending | `cases/holdout/freeze.json`, `evaluation/PRE_FREEZE.md` |
| 2:20 ledger | Recordable now from run `e5150fec…`: 2 calls with real model IDs, tokens, reasoning tokens and calculated cost; billed amount unknown | `reports/model-pilot-20261019-once/model-ledger.json` |

A shot recorded from the pilot shows the original run time in the report header; don't present it as happening live.

## Before recording

- [ ] Each **[real run]** shot exists in the submitted build. Display its original date and replay badge; a new screen recording does not make an old run live.
- [ ] Narration numbers match `evaluation/` exactly; no number without a denominator.
- [ ] If the demo used the manual candidate patch, the narration says "manual candidate", not Ultra.
- [ ] md2html is described as an install step that never created the command, not as dependency drift.
- [ ] Drop Sandboxes, nightly checks or Tavily lines if they aren't real at submission.
- [ ] If quick checks for any repo aren't supported yet, keep the quick-check box out of the 0:15 shot.
- [ ] English subtitles; check the video is **public** on YouTube and under 3:00.
