# Fresh Eyes

> Draft for the public repository README (B, 2026-10-20). Replace the current README only when the repo goes public, and check every `[TBD]` and every number against the evidence first.

**Fresh Eyes checks whether a README's first workflow still works, and proves any fix in a clean environment.**

It follows the README of a Python command-line tool exactly as written, in a fresh Linux container, and checks the real output against an acceptance check that a person approved once. If the README fails, NVIDIA Nemotron (on Nebius Token Factory) diagnoses the failure and may propose a small README or dependency fix. A fix only counts after it passes again in a new container, and once more from scratch.

Built for the Nebius × NVIDIA Global AI Hackathon, Coding & Agentic Engineering track.

## Try it

- **No install:** [Published recorded viewer](https://johncat88425-del.github.io/fresh-eyes/) (24 October recorded candidate). It opens on a simple step-by-step page; **Detailed view** has the full evidence. It replays real runs, with separately labelled synthetic state examples; nothing runs there and no model is called. Testing steps: [submission/JUDGE_TESTING_INSTRUCTIONS.md](JUDGE_TESTING_INSTRUCTIONS.md).
- **Locally:** see [Run it yourself](#run-it-yourself).

## What it has actually done (as of 24 Oct 2026)

| Repository | What happened | Evidence |
|---|---|---|
| md2html | The README's standard "everyday" install covers only the requirements, so the `md2html` command never exists and both inputs fail. (Its separate developer install would work.) A one-line README change to `pip install .` passed in a fresh container and again in an independent clean re-run. **This fix was written by hand, not by a model.** Rechecked on 24 Oct. | runs `10175eee…`, `563db906…`, `10cef22d…` |
| md2html, fixed by Nemotron (24 Oct) | Nano classified the failure, Tavily returned the project's README, and Ultra proposed a line-anchored README patch (`pip install -e .`). That trial was interrupted by an error in our own runner before verification. The unchanged patch was then checked with no new model call: the original README failed, the patched README passed in a fresh container and again in an independent clean re-run. 2 calls, about US$0.014 calculated from usage. | trial `1a5f5135…`, verification `5ac51103…` |
| md2html, earlier Nemotron runs (19–21 Oct) | Five real runs, none with an applicable fix. The patch checker refused edits that didn't match the README; once Ultra declined to guess; once the budget guard refused a call before sending; in the latest run Ultra used its whole completion limit on reasoning and returned no complete answer. Nothing was applied. 10 calls (6 Nano, 4 Ultra), US$0.0277 calculated from usage. | runs `e5150fec…`, `e9a04f64…`, `402356b0…`, `87b1fce1…`, `34f03a38…` |
| md2html, later medium-effort trials (24 Oct) | Three further attempts: incomplete Nano output; a rejected setup/README mismatch; and an Ultra timeout. No new verified fix. Five calls were dispatched; four have known usage totalling US$0.00729790, and the timed-out Ultra call has unknown usage with US$0.029654 held. Paid dispatch is blocked until reconciliation; no retry or fallback. | runs `b6c47833…`, `22ca7359…`, `18dd07f0…` |
| mistletoe | The README already works: both inputs produce the expected output. | run `a7bf8fc4…` |
| json2yaml | The README already works (offline package snapshot). | run `9a4e3a87…` |

**One unchanged model-generated candidate has passed separate clean verification, on one development repository.** It is not an uninterrupted end-to-end success or a formal evaluation result. Formal evaluation awaits the revised html2text human review and reconciliation of one unknown-usage timeout.

## How it works

1. **Pick a case.** A public Python CLI at a pinned commit, with the README lines its workflow comes from.
2. **Approve the acceptance check once.** A person confirms two inputs and their expected outputs. The check is then locked by hash; no repair step can change it, and the expected answers never enter the container.
3. **Run the README as written** in a clean container and compare the real output: HTML structure, parsed JSON or exact text. Exit code 0 alone never passes.
4. **If it fails, diagnose and propose.** `nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B` classifies the failure from the logs. `nvidia/Nemotron-3-Ultra-550b-a55b` explains it and may propose one patch, limited to checked text replacements or line-anchored edits in `README.md`, `requirements*.txt` or `pyproject.toml` dependency fields. Product source code is never edited. With two rounds, each round starts again from the original commit.
5. **Prove it.** The candidate must pass in a fresh container and again in an independent clean re-run. Only then is the result `verified_fix`.

Every run ends in one of eight explicit results (`already_passes`, `verified_fix`, `startup_only`, `needs_review`, `needs_input`, `unsupported`, `unresolved`, `infrastructure_error`), kept separate from whether the run finished.

## Cost and honesty rules

- Every model call is reserved against a budget before it is sent, and recorded with the returned model ID, token usage and the price source (Token Factory's model catalog). Costs from usage are marked "pending reconciliation"; unknown costs stay unknown, never $0.
- Paid calls are off by default and need an explicit, one-off authorisation with an amount.
- Approvals are attributed and append-only. Correcting a reviewer name is a separate, reasoned event.
- Examples and replays are always labelled; they never appear as new runs or in results.

## Run it yourself

Needs Python 3.12+ and Git. The core has no third-party Python dependencies.

```sh
python3.12 scripts/fresh-eyes doctor
python3.12 scripts/fresh-eyes validate cases/mistletoe.json
PYTHONPATH=src python3.12 -m unittest discover -s tests
python3.12 web/demo/build.py
node --test web/tests/*.test.mjs
```

The web app (two terminals):

```sh
python3.12 scripts/fresh-eyes serve      # API on 127.0.0.1:8765, execution off by default
python3 web/serve.py                     # frontend on http://localhost:5173/
```

Running cases in containers needs the local runtime (a Lima VM with rootless Docker), so far tested by the owner on macOS only; see step 3 of the [testing instructions](JUDGE_TESTING_INSTRUCTIONS.md). A clean, network-free Linux container has also passed the packaged source tests on the same physical Mac. A second physical machine has not yet been tested.

```sh
python3.12 scripts/start-local-runtime.py
python3.12 scripts/fresh-eyes doctor --docker scripts/docker-local
python3.12 scripts/run-development.py --case md2html
python3.12 scripts/run-development.py --case md2html --candidate-patch
```

Rebuild the read-only demo: `python3.12 web/demo/build.py` (uses the versioned `web/demo/recordings/`; no `reports/`, keys or API needed).

## Repository layout

| Path | What's there |
|---|---|
| `src/fresh_eyes/` | Contracts, runner, validators, patch rules, model client and ledger, API, evaluation |
| `cases/` | Development cases; `cases/holdout/` (frozen, not loaded by the API); `cases/boundary/` (should stop) |
| `web/` | Frontend (plain HTML and ES modules, English/中文) and the read-only demo builder |
| `api/` | API notes, OpenAPI contract, pilot and model-run records |
| `evaluation/` | Evaluation runbook and results format |

## Limits

- Python command-line tools only, with file inputs (no stdin mode yet).
- A small, purposively chosen sample, reviewed by the team itself, not by upstream maintainers.
- Runs so far are on Linux arm64 with Python 3.12.
- A bounded public-GitHub quick check supports an unambiguous README pip install and help/version command, at startup level only. Nightly monitoring and Token Factory Sandboxes have not been exercised.

## License

MIT. See [LICENSE](../LICENSE). Adjust this link to `LICENSE` if this draft is promoted to the repository root.
