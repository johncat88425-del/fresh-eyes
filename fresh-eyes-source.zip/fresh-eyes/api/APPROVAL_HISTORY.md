# 確認紀錄與明確更正

重新啟動更新後的 API 才會生效；原有資料庫與歷史任務保留。啟動時會把現存確認保存為 legacy_snapshot，原姓名及 approved_at 不改。這是「觀察到的舊資料」，無法重建先前已被舊版覆蓋的歷史。本次先用 SQLite backup 保存更動前資料到 A 的 work，未修改正式確認。

## 行為

- 第一次 POST /api/cases/{id}/approval：新增 revision 1。
- 相同驗收 hash、相同姓名再次 POST：回傳原確認，不改時間、不增加事件。
- 相同 hash、不同姓名再次 POST：409 approval_exists，不再靜默覆蓋。
- GET /api/cases/{id}/approval/history：依序列出原紀錄及更正。
- POST /api/cases/{id}/approval/correction：必須明確填新 reviewer、更正者、理由及 expected_revision。更新現行確認，同時追加歷史；保留原 approved_at。
- 兩人同時更正相同 revision，只有一筆成功，另一筆收到 409 approval_changed。

歷史表以 SQLite triggers 拒絕 UPDATE／DELETE。current approval 是現行指標；歷史不是靠 INSERT OR REPLACE 重寫。匯入新確認也會記 imported 事件。

## md2html 的 john → kevin

整合初期唯讀讀到 md2html 為 john；完工前再次檢查，兩筆皆為 kevin，md2html 的現行 approved_at=2026-10-19T22:58:24.855846+00:00，驗收 hash 均符合。更名發生於仍在運作的舊 API，因此沒有留下更正事件；A 事前備份保留 john 原紀錄，另外保存前後唯讀觀察 JSON，沒有代人改名或捏造歷史事件。**不需要再把 md2html 改名一次。** 重啟更新 API 後會保存目前狀態的 legacy_snapshot；以下是未來真的需要更正時的操作：

1. GET /api/cases/md2html-markdown/approval/history，讀取最新 revision。
2. 呼叫 client.correctApproval('md2html-markdown', body)，body 填：

| 欄位 | 值 |
|---|---|
| acceptance_sha256 | 476312080ff301755f0efdc94177eb3bffb1228b258089ab9790fc3449bb749a |
| reviewed_by | kevin（依本次真人回報的正確名稱） |
| corrected_by | 實際確認／操作本次更正的真人姓名 |
| reason | 說明原姓名輸入錯誤及更正依據 |
| expected_revision | 剛讀到的正整數，不要寫死舊版本 |

helper 已加入 approvalHistory(caseId) 和 correctApproval(caseId, body)。B 可接上「更正」小介面；新版一般確認按鈕仍相容。新增錯誤碼：approval_exists、approval_missing、approval_changed、correction_required、correction_unchanged。通用錯誤顯示仍會保留伺服器說明。

目前 approvals-export 的 v1 交接格式只搬移現行 reviewer／原確認時間；完整更正事件留在本機歷史表，沒有宣稱跨機同步整條歷史。詳見 [原交接方式](APPROVAL_TRANSFER.md)。
