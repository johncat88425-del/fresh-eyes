#!/usr/bin/env python3
"""Package an already built read-only demo; validate every byte and publish nothing."""
import hashlib
import json
from pathlib import Path
import sys
import zipfile

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "web/demo"))
from recordings import checked_text  # noqa: E402


def main():
    site = PROJECT / "dist/demo"
    if not (site / ".fresh-eyes-demo").is_file():
        raise ValueError("Build the demo before packaging")
    files = {p.relative_to(site).as_posix(): p.read_bytes() for p in site.rglob("*") if p.is_file()}
    manifest = json.loads(files["data/manifest.json"])
    expected = set(files) - {"data/manifest.json", ".fresh-eyes-demo"}
    if set(manifest["files"]) != expected:
        raise ValueError("Demo manifest does not cover the output")
    for name, raw in files.items():
        checked_text(raw, name)
        if name in expected and hashlib.sha256(raw).hexdigest() != manifest["files"][name]:
            raise ValueError("Demo file differs from manifest: " + name)
    health = json.loads(files["data/health.json"])
    if (health.get("read_only") is not True or health.get("execution_enabled") is not False or
            health.get("paid_calls_enabled") is not False):
        raise ValueError("Not a disabled, read-only demo")
    for name, raw in files.items():
        if name.startswith("data/runs/") and name.endswith(".json"):
            record = json.loads(raw)
            if record.get("data_origin") != "recorded_replay" or record.get("evaluation_eligible") is not False:
                raise ValueError("Unlabelled replay in demo")
    output = PROJECT / "dist/fresh-eyes-read-only-demo.zip"
    run_count = len(json.loads(files["data/runs.json"])["items"])
    readme = ("Fresh Eyes 唯讀展示；請完整解壓，再進入 fresh-eyes-demo 資料夾。\n"
              "執行 python3.12 -m http.server 3001 --bind 127.0.0.1\n"
              "開啟 http://127.0.0.1:3001/ 。直接雙擊 index.html 可能無法讀取 JSON。\n"
              "不需要 API、key 或 VM；只回放紀錄，不會執行或花模型費用。\n"
              f"3 個開發 repo、{run_count} 筆真實回放；人工修補已驗證，AI 尚無驗證成功，正式評估未執行。\n"
              "這個包尚未對外發布。\n").encode()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, raw in sorted(files.items()):
            archive.writestr("fresh-eyes-demo/" + name, raw)
        archive.writestr("READ_ME_FIRST.txt", readme)
    with zipfile.ZipFile(output) as archive:
        if archive.testzip():
            raise ValueError("Demo ZIP CRC check failed")
        for name, raw in files.items():
            if archive.read("fresh-eyes-demo/" + name) != raw:
                raise ValueError("Demo ZIP content changed")
    print(json.dumps({"archive": output.name, "files": len(files) + 1, "bytes": output.stat().st_size,
                      "sha256": hashlib.sha256(output.read_bytes()).hexdigest(), "published": False}, indent=2))


if __name__ == "__main__":
    main()
