// Select evidence for the compact repair summary without changing the stored engine result.
import { verdictOf } from './evaluation.js';

export function repairPathFacts(run) {
  const ev = run.evidence || {};
  const attempts = Array.isArray(ev.attempts) ? ev.attempts : [];
  const calls = Array.isArray(run.costs?.model_calls) ? run.costs.model_calls
    : Array.isArray(ev.model_calls) ? ev.model_calls : [];
  const humanRejected = verdictOf({ human_review: run.result_review }) === 'rejected';
  const rounds = [...attempts, ...(Array.isArray(ev.repair_rounds) ? ev.repair_rounds : [])]
    .map(a => a.round).filter(n => Number.isInteger(n) && n > 0);
  const latestRound = rounds.length ? Math.max(...rounds) : null;
  return {
    humanRejected,
    verifiedByAi: run.result_status === 'verified_fix' && run.repair_mode === 'model' && !humanRejected,
    attempt: phase => phase === 'original_readme' ? attempts.find(a => a.phase === phase)
      : attempts.findLast(a => a.phase === phase && (latestRound == null || a.round === latestRound)),
    modelOf(stage, fallback) {
      const id = calls.findLast(c => c.stage === stage || c.stage === `${stage}_r2`)?.returned_model || fallback || '';
      const match = /Nemotron-3-(Nano|Super|Ultra)/i.exec(id);
      return match ? `Nemotron 3 ${match[1][0].toUpperCase()}${match[1].slice(1).toLowerCase()}` : id || null;
    },
  };
}
