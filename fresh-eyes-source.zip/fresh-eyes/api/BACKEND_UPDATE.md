# 給 B：0.2.1 後端更新與現在要做的事

> 最新模型實測：Nano→Ultra 已真實呼叫各一次，按 usage 計算 US$0.00660426；候選比對失敗，結果 needs_review，沒有 AI 修復成功，也沒有重試。VM 已恢復；一般 Web 付費入口仍關閉。見 [真實模型紀錄](MODEL_PILOT.md)。

> 10/19 CORS 修正：--allow-origin 現在追加至預設清單，不會移除 localhost／127.0.0.1 的 5173、3000。需重啟 API 才會生效；health 版本應為 0.2.1。

> 10/19 追加：你的 web/ 已接入交接包並完成一輪實際瀏覽器整合測試。以下接口仍有效；下一批工作以 [B_NEXT_STEPS.md](../PUBLIC_EXPORT.md) 為準。啟動介面用 python3.12 web/serve.py，原 design/ 草圖保留參考。

先更新後端包、停止舊 API，再重新啟動。`GET /api/health` 應回覆 **`api_version: "0.2.1"`**。你可以把新版後端放在獨立資料夾；前端仍透過 localhost 呼叫，不用搬動或覆蓋原本的設計草圖。

你目前是純 HTML 樣稿，也不用先換前端框架。後端開一個 Terminal 執行 `python3.12 scripts/fresh-eyes serve`；前端把新版 `api/client.js` 放進自己的前端資料夾，改用 module script 引入。

在有 `design/ui-mockup.html` 的前端專案目錄，另一個 Terminal 執行：

```sh
python3.12 -m http.server 3000 --bind 127.0.0.1 --directory design
```

打開 `http://127.0.0.1:3000/ui-mockup.html` 串接。直接雙擊 HTML 的 file 頁面仍可看草圖，但其 null origin 不在 API 的允許清單，不能當成串接方式。

## 你提出的四點

| 問題 | 這版處理 | 仍待完成 |
|---|---|---|
| 離線無法看依賴漂移 | 分成 `offline_snapshot` 與 `pypi_live`；後者不使用離線 links／cache，走隔離網路＋PyPI 代理 | 真實 Docker／PyPI 出站驗收、每晚排程與漂移實驗；目前不能聲稱已證明漂移 |
| VM 不可用 | 新建 VM 改放永久路徑；保留既有／部分 instance，補恢復指南 | 依目前決定先交付程式；之後由 A 在一般 Terminal 恢復，Sandboxes 權限／實測也仍待做 |
| 原始步驟誤用了修後指令 | `verified-fix` 原始步驟已改成 `pip install -r requirements.txt`；修復與最終步驟才是 `pip install .` | 無；範例仍明確標記未執行 |
| SQLite 連線未關閉 | 增加 transaction＋finally close，涵蓋正常與例外路徑 | 已加入連線確實關閉與 rollback 測試 |

## 今天只接一條完整流程

1. **選案例**：用 `api.cases()`，顯示 repo、SHA、目標與兩組輸入／預期值。
2. **確認成功標準**：填真正確認者的名字，呼叫 `api.approve(case_id, acceptance_sha256, name)`。成功後才用回傳資料顯示已鎖定；失敗保留原狀。暫不提供修改目標／fixture 的功能。
3. **提交任務**：用 `api.startRun(...)`，成功取得 run_id 才輪詢。未啟用 runner／缺本機資產時顯示實際錯誤，不換成範例成功畫面。
4. **報告**：用 `api.run(id)`；排隊／執行每 1–2 秒更新，completed／failed 停止。Patch 按鈕依 `patch_available` 決定，並區分已驗證與候選。

VM、PyPI 隔離、Sandbox 與模型不由前端處理。監看與美化放在這條流程之後；只依 capabilities 宣告已完成的功能。

## 欄位對齊

| 欄位 | 前端用法 |
|---|---|
| `run_state` | queued／running／completed／failed，是任務生命週期 |
| `result_status` | 8 種驗收結論，執行中可為 null；completed 不等於通過 |
| `repair_mode`／`repair_author` | 現在只有 none 或 manual_candidate；作者為 manual 時寫「人工候選 patch」，沒有 Ultra 診斷紀錄就不顯示該階段 |
| `costs.*_usd` | null 顯示未知；實際未呼叫模型且帳本為空時，後端的模型費用 0 代表沒有使用模型 |
| `dependency_mode` | 顯示「離線快照」或「即時 PyPI」；缺此欄的舊紀錄標示未記錄，不擅自判成正式連線結果 |
| `data_origin` | example 保留「範例／未執行」標記，不進真實歷史或評估；靜態範例不要拿假 run_id 輪詢 |
| `evidence` | 原始 log／輸出用文字轉義顯示；執行中不把內層暫定 status 當最終結論 |

## 10 個靜態範例

| UI 狀態 | `api.example(name)` 的 name |
|---|---|
| queued | `queued` |
| running | `running` |
| already_passes | `already-passes` |
| verified_fix | `verified-fix` |
| startup_only | `startup-only` |
| needs_review | `needs-review` |
| needs_input | `needs-input` |
| unsupported | `unsupported` |
| unresolved | `unresolved` |
| infrastructure_error | `infrastructure-error` |

`needs_input` 原本就在結果 enum，本版補上缺少的範例。這個範例是必要資料檔缺失，不要求把 API key 交給前端或 repo。

**你的完成條件：從自己的介面選一案、確認、提交，最後把後端的真實回應呈現出來。** 後端未啟用或 VM 不可用時，正確呈現錯誤也能完成這次前端串接驗收；它不算產品功能修復成功。
