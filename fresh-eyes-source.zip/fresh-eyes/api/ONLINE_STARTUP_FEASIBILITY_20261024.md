# 第3項：評審期線上真實執行的可行性（A，10/24）

**判斷：小範圍工程有條件可在五天內完成，但目前沒有已確認的隔離Linux公開主機與主機預算，不能承諾五天內上線。** 已經有實際本機網頁→GitHub→Docker→啟動報告的閉環，缺的是公開服務的部署與營運。Token Factory推論授權／餘額不視為運算主機授權或額度；也不把Chris的私人Mac直接公開當服務。

## 固定範圍

- 只接受公開GitHub URL和選填commit，僅現有小型Python CLI README安裝／明示help或version；其他回報不支援或需要人確認。
- 無AI、無修補、無金鑰進執行主機；不提供上傳壓縮檔、任意shell、私人repo、持續Web服務。
- 公開入口只暴露提交startup與讀取自己的任務結果；approval、correction、model plan、其他任務列舉等控制API不得直接轉發。
- 既有容器限制與PyPI-only網路仍需在實際主機重新驗證；通過本機Lima不等於雲端平台已驗證。

## 五天內的驗收順序（不是已完成）

1. 確認隔離Linux主機／TLS固定網址／評審期可用性／明確運算總上限。無主機就不進行公開執行部署。
2. 以現有runner建服務，補公開閘道：短期評審憑證或一次性工作票、每IP與全域配額、單任務時間／CPU／RAM／下載大小上限、佇列與停止開關。憑證放交件測試說明；付費模型始終關閉。
3. 兩個不同repo與不支援／逾時／佇列滿／跨任務讀取測試；實測拒絕一般網路、資源回收、日誌遮蔽、重啟後任務狀態。
4. 接公開前端，驗證GitHub計畫與實跑固定同一commit，不用舊回放頂替新任務。
5. 由另一台電腦驗收，固定交件網址與版本，寫入至12/15的可用性安排；影片與Devpost只描述已通過的範圍。

建議10/26前做go/no-go：主機和總上限未確認，或真實平台隔離／外部驗收未過，就不把公開實跑列為已交付。不能因時間到就關掉隔離或開無上限服務。

## 若未能上線

保留公開瀏覽器README計畫＋可下載、可運作的本機test build，影片實際展示自己的repo實跑。官方接受working demo、hosted application或test build，且要求能供評審測試；不是一定要全天候公開運算服務。

B提出「評審開issue貼repo後由團隊代跑」可作額外協助，但不是即時自助服務，也不代替可供評審自行驗證的test build。未建流程／未有回覆時不宣稱已提供；本輪沒有代評審發issue、送訊息或建立付費主機。

## 現有可用證據

`evidence/own-github-ui-20261024.json`：本機真實瀏覽器提交rich-cli，startup_only、模型0。`api/OWN_REPO_DELIVERY_20261024.md`：入口與已知限制。公開README計畫是讀文件，不是執行證據。

官方規則：https://nebiusglobalaihackathon.devpost.com/rules
