# Fresh Eyes

> Draft for the public repository README (B, 2026-10-20). Replace the current README only when the repo goes public, and check every `[TBD]` and every number against the evidence first.

**Fresh Eyes checks whether a README's first workflow still works, and proves any fix in a clean environment.**

It follows the README of a Python command-line tool exactly as written, in a fresh Linux container, and checks the real output against an acceptance check that a person approved once. If the README fails, NVIDIA Nemotron (on Nebius Token Factory) diagnoses the failure and may propose a small README or dependency fix. A fix only counts after it passes again in a new container, and once more from scratch.

Built for the Nebius × NVIDIA Global AI Hackathon, Coding & Agentic Engineering track.

## Try it

- **No install:** [TBD: link to the read-only demo]. It replays real runs; nothing runs there and no model is called.
- **Locally:** see [Run it yourself](#run-it-yourself).

## What it has actually done (as of 20 Oct 2026)

| Repository | What happened | Evidence |
|---|---|---|
| md2html | The README's standard "everyday" install covers only the requirements, so the `md2html` command never exists and both inputs fail. (Its separate developer install would work.) A one-line README change to `pip install .` passed in a fresh container and again in an independent clean re-run. **This fix was written by hand, not by a model.** | runs `10175eee…`, `563db906…` |
| md2html, with Nemotron | Two real runs. Nano and Ultra diagnosed the missing install correctly both times, but neither run produced an applicable fix. The patch checker refused edits that didn't match the README, and in round 2 Ultra declined to guess. Result: `needs_review`, nothing applied. 6 calls, US$0.0202 calculated from usage. | runs `e5150fec…`, `e9a04f64…` |
| mistletoe | The README already works: both inputs produce the expected output. | run `a7bf8fc4…` |
| json2yaml | The README already works (offline package snapshot). | run `9a4e3a87…` |

**No model-generated fix has passed yet.** [TBD: update after the next authorised model run and the holdout evaluation (frozen 23 Oct, run 24 Oct).]

## How it works

1. **Pick a case.** A public Python CLI at a pinned commit, with the README lines its workflow comes from.
2. **Approve the acceptance check once.** A person confirms two inputs and their expected outputs. The check is then locked by hash; no repair step can change it, and the expected answers never enter the container.
3. **Run the README as written** in a clean container and compare the real output: HTML structure, parsed JSON or exact text. Exit code 0 alone never passes.
4. **If it fails, diagnose and propose.** `nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B` classifies the failure from the logs. `nvidia/Nemotron-3-Ultra-550b-a55b` explains it and may propose one patch, limited to exact replacements in `README.md`, `requirements*.txt` or `pyproject.toml` dependency fields. Product source code is never edited. With two rounds, each round starts again from the original commit.
5. **Prove it.** The candidate must pass in a fresh container and again in an independent clean re-run. Only then is the result `verified_fix`.

Every run ends in one of eight explicit results (`already_passes`, `verified_fix`, `startup_only`, `needs_review`, `needs_input`, `unsupported`, `unresolved`, `infrastructure_error`), kept separate from whether the run finished.

## Cost and honesty rules

- Every model call is reserved against a budget before it is sent, and recorded with the returned model ID, token usage and the price source (Token Factory's model catalog). Costs from usage are marked "pending reconciliation"; unknown costs stay unknown, never $0.
- Paid calls are off by default and need an explicit, one-off authorisation with an amount.
- Approvals are attributed and append-only. Correcting a reviewer name is a separate, reasoned event.
- Examples and replays are always labelled; they never appear as new runs or in results.

## Run it yourself

Needs Python 3.12+ and Git. The core has no third-party Python dependencies.

```sh
python3.12 scripts/fresh-eyes doctor
python3.12 scripts/fresh-eyes validate cases/mistletoe.json
PYTHONPATH=src python3.12 -m unittest discover -s tests
node --test web/tests/*.test.mjs
```

The web app (two terminals):

```sh
python3.12 scripts/fresh-eyes serve      # API on 127.0.0.1:8765, execution off by default
python3 web/serve.py                     # frontend on http://localhost:5173/
```

Running cases in containers needs the local runtime (a Lima VM with rootless Docker). [TBD: A to confirm the minimal steps for someone else's machine.]

```sh
python3.12 scripts/start-local-runtime.py
python3.12 scripts/fresh-eyes doctor --docker scripts/docker-local
python3.12 scripts/run-development.py --case md2html
python3.12 scripts/run-development.py --case md2html --candidate-patch
```

Rebuild the read-only demo: `python3.12 web/demo/build.py` (uses the versioned `web/demo/recordings/`; no `reports/`, keys or API needed).

## Repository layout

| Path | What's there |
|---|---|
| `src/fresh_eyes/` | Contracts, runner, validators, patch rules, model client and ledger, API, evaluation |
| `cases/` | Development cases; `cases/holdout/` (frozen, not loaded by the API); `cases/boundary/` (should stop) |
| `web/` | Frontend (plain HTML and ES modules, English/中文) and the read-only demo builder |
| `api/` | API notes, OpenAPI contract, pilot and model-run records |
| `evaluation/` | Evaluation runbook and results format |

## Limits

- Python command-line tools only, with file inputs (no stdin mode yet).
- A small, purposively chosen sample, reviewed by the team itself, not by upstream maintainers.
- Runs so far are on Linux arm64 with Python 3.12.
- [TBD: whether quick checks for arbitrary public repos, nightly checks or Token Factory Sandboxes made it in. Describe only what works.]

## License

MIT. See [LICENSE](../LICENSE). Adjust this link to `LICENSE` if this draft is promoted to the repository root.
