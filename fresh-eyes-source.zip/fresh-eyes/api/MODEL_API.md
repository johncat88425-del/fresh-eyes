# 本機單次模型 API（10/20）

`serve` 預設仍關閉模型，不讀 `.env`。新增的入口只接受主機事先固定的一份開發計畫，不能從瀏覽器改 repo、驗收、模型、額度、輪數、依賴來源或輸出目錄。它不是公開付費 API。

先依 [MODEL_TRIAL.md](MODEL_TRIAL.md) 準備計畫。附加計畫而不啟用：

```sh
python3.12 scripts/fresh-eyes serve --model-plan /你的新計畫.json
```

只有另一次明確的支出授權成立後，主機才可使用下面的完整啟動形式；這是操作模板，本輪沒有對真實模型執行：

```sh
python3.12 scripts/fresh-eyes serve \
  --enable-runner --enable-live-pypi \
  --source-root /已固定commit的開發來源目錄 \
  --docker scripts/docker-local \
  --model-plan /已核對且獲准的新計畫.json \
  --enable-paid-models --env-file .env \
  --tokenizer-references /已核對的tokenizer目錄
```

計畫本身必須是對應 `pypi_live` 的正額度計畫；離線計畫另須備妥對應 wheelhouse。API 的正式資料目錄必須已有同一驗收、同一確認者和時間的確認記錄；不會為了執行代人建立 approval。

`GET /api/health` 的 `model_trial_plan` 只有公開摘要：case/hash、route、模式、金額、輪數、呼叫數、時間、available/consumed。前端只在相符案例且 available 時提供模型選項。送出仍用原端點：

```json
{"case_id":"md2html-markdown","verification_level":"functional","repair_mode":"model","dependency_mode":"pypi_live"}
```

送出前以 exclusive create 建立輸出目錄旁的 `*.api-claim.json`；排隊即消耗一次。關閉瀏覽器、更換 API 資料目錄、重啟、工作失敗都不重設，不能刪掉記錄重用授權。已存在輸出的計畫在啟動檢查直接拒絕；完成後重啟一般 API 時移除模型相關旗號。正常 API 不需要停機才能讓付費開關恢復關閉：claim 成立後 health 就不再提供第二次模型任務。

佇列保存逐輪進度、完整提案、報告與 patch；API job ID 和 engine run ID 分別保留。結果仍是開發紀錄、`evaluation_eligible=false`。無模型時／無候選時不製造 ledger 或 patch。原始流程健康時不啟動模型；失敗後才載入指定 key 與核對 catalog。沒有 retry 或 fallback。

驗證：9 個 API 工程測試涵蓋 HTTP、進度、報告、patch、單次消耗、重啟和參數篡改；另已經瀏覽器操作兩輪合成案例，明示「測試替身」、真實模型 0 次、送出後關閉、重載可讀、375px 無頁面橫向捲動。這不是實際模型網頁修復；UI-14 的真實模型驗證仍未完成。
