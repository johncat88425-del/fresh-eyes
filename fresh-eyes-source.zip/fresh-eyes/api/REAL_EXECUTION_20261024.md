# 10/24 真實執行與覆核交接

本輪完成執行環境恢復、陌生 repo 啟動及三個邊界案例實跑。**新增 Nebius 呼叫 0、Tavily 呼叫 0；目前仍沒有 AI 產生的 verified_fix。**

| 證據 | 結果 |
|---|---|
| [平台 v1](../reports/platform-release-gate-20261024-v1.json) | full 出站通過，但清理時連帶刪除了無標籤基礎映像，timeout 步驟因此失敗；保留原記錄 |
| [平台 v2](../reports/platform-release-gate-20261024-v2.json) | 加 `image rm --no-prune` 後，full／timeout／interrupt／自有資源清理全部通過；新固定 image a0f57064…86704 |
| [rich-cli 啟動](../reports/github-rich-cli-startup-20261024-v1/report.html) | 固定 commit 46f4d246…412，照 README 安裝及 help 成功，startup_only；不是功能驗收 |
| [邊界 baseline](../reports/boundary-baseline-20261024-v1/boundary-results.json) | kevin 接受的三案都執行；安裝成功，工作流程 unresolved，沒有誤報成功 |
| [人工修補重驗](../reports/md2html-manual-recheck-20261024-v1/report.html) | md2html 原 README failed，既有人工 candidate passed、獨立乾淨重跑 passed；沿用原確認 |

邊界的實際原因：j2cli 是 `pkg_resources` 缺少（尚未走到 `imp`）；yq 是系統 `jq` 缺少；gfm-to-html 是 GitHub API 被 PyPI-only 代理 403 拒絕後，套件的例外處理又報 TypeError。這是 README-only baseline，不是 AI 自主分類／停損的證據，三案不進修補率。

## kevin 的決定

原始含帳號 ID 的 JSON 存在 ignored 私密目錄，不入 ZIP。主專案已核對 B 當時呈現的 goal／repo／README 來源／setup／workflow／fixtures，以及驗收 hash；新匯入器不只比對舊版未包含指令的 acceptance hash。

- 接受：markdown2、commonmark、markdown-it-py，以及三個 boundary。
- 不接受：html2text 的逐字／空白驗收、htmldiff 的相同輸入設計。
- [匯入摘要](../evaluation/review-intake-20261024-v6/receipt.json)保留原姓名／時間及拒絕理由，不宣稱已驗證帳號身分。
- [正式覆核](../evaluation/review-intake-20261024-v6/holdout-reviews.json)仍有 rejected；正式四案批次確實被擋，沒有先看另外三案的結果，也沒有偷偷縮分母。
- [boundary 覆核](../evaluation/review-intake-20261024-v6/boundary-reviews.json)已綁新計畫；只有這三案被執行。

## B 接下來

1. B 已將 A 的防錯修正納入私人覆核 artifact v2，A 又合併 B v2；六筆原接受已核對並轉到 [v7](../evaluation/review-intake-20261024-v7/receipt.json)，不需重看。帳號身分仍不由本機匯入器認證；B 轉述 kevin 使用 Chris 帳號的脈絡保留於私人共用日誌。
2. html2text v2 已合併：輸入／預期文字不改，`text_lines` 只忽略空白行與行尾空白，仍檢查文字、順序與縮排。新 hash `766ed9bf…9f2523`，**仍待 kevin 的新決定**。原契約／manifest 存於 evaluation/archive，舊拒絕保留；沒有先跑案例倒推答案。
3. htmldiff 依原拒絕停止，不再實跑或為它擴寫雙檔框架。原草稿留存，不當作第二種已觀察或修好的故障。
4. B29／B30 核對這批真實 startup／boundary／manual 證據的中英呈現。不要把新人工成功畫成 AI 成功，也不要把 boundary 三筆混進正式評估。

資料來源見 [本輪證據摘要](../evidence/real-progress-20261024.json)。正式模型批次和新開發付費仍關閉；舊單次開發額度不因一般「繼續」重新取得。

新單案覆核可以用 `scripts/import-review-decisions.py --previous evaluation/review-intake-20261024-v7` 合併進**新的**輸出目錄；它只延續同一 freeze／plan、相同驗收的既有批准，舊檔不覆寫。新 html2text 的記錄仍必須有正確新 hash、原確認者與帶時區時間。跨 freeze 的延續須先逐項核對、另建綁定，不能靠選項跳過版本限制。
