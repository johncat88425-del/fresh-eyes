# 10/24：第一次不中斷的真實 AI 修補

**run `5c225204bcd946228a7ef4700c8c0c8c` 完整走完 Nano→Ultra→候選驗收→獨立乾淨重跑。**

[完整報告](../reports/model-trial-md2html-followup-20261024-3/report.html) · [原始報告 JSON](../reports/model-trial-md2html-followup-20261024-3/report.json) · [模型帳本](../reports/model-trial-md2html-followup-20261024-3/model-ledger.json)

- 原 README `pip install -r requirements.txt` 安裝成功，但沒有建立 CLI，兩組輸出失敗。
- 真實 Nano 分類 documentation，真實 Ultra 提議 README 改 `pip install .`；由修補檢查器套用，沒有人工編輯，也沒有載入前一份保存候選。
- 候選環境兩組功能驗收通過，另開乾淨環境兩組再次通過。固定來源 commit、驗收 hash、人類既有確認不改。不是「退出碼0」或只跑 help。
- 2 calls，usage .00546874（Nano .00016674，Ultra .00530200），實際 billed 尚未對帳；新 Tavily 0。全程約23.5秒，包含容器安裝和兩次驗證；不是效能基準。
- 此修補的文字與先前人工 patch 相同，但這次提案來自新的 Ultra 回覆，來源／call ID／帳本均另存。相同正確解法不等於人工 patch 被重標。

## 同批失敗也保留

1. `2978ec94…`：Nano 誤判缺輸入，1call／.00015618；沒有Ultra。
2. `0c0141f2…`：第一輪正確指向安裝，但 setup 不在修後 README 被拒；第二輪 Nano 誤判 unsupported，停止。3calls／.00732768。
3. `5c225204…`：上述完整成功，2calls／.00546874。成功即停，三次總6calls／.01295260，低於新.24上限；沒有HTTP重試或fallback。三次已用完，不用未花完的金額再開第四次。

第一次失敗後補了通用 fixture input 名稱／大小／是否有工作流程紀錄，未送輸入本文或預期答案，也未繞過分類。後兩次仍一失敗一成功，不能宣稱改動必然改善或已達穩定修補。舊逾時 .029654 仍占額、帳務未知；Chris 明確准許的例外只適用這次新 scope。付費已恢復關閉。

## 能說與不能說

目前有不中斷的開發成功，也有先前保存候選分開驗證成功，**仍只有同一個 md2html repo**。這三次是經過開發修正的探索，不能作正式成功率或路由省錢比較。正式四案仍未跑；html2text v2 待 kevin 決定。

[成功證據](../evidence/first-uninterrupted-ai-fix-20261024.json) · [全部開發呼叫小計](../evidence/development-model-accounting-followup-20261024.json)
