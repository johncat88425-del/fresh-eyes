> Public source candidate. See [export scope](PUBLIC_EXPORT.md). No API key is needed for tests or the read-only demo. From this directory: `python3.12 web/demo/build.py --replace`, then `python3.12 -m http.server 3001 --bind 127.0.0.1 --directory dist/demo`.

# Fresh Eyes

**A／B 共用進度請更新 [TEAM_TASKS.md](PUBLIC_EXPORT.md)**：所有完成與未完成工作、負責人及證據集中在這一份。

> 10/20 最新：[提前至 10/22 的交接](api/READY_THROUGH_1022.md)。已整合 B 至 B18–B19，含模型選項狀態與人工覆核顯示；新增單次開發模型 API／人工結果覆核匯入／容量試算／boundary baseline 入口；json2yaml live 及平台關卡實跑通過，新增模型呼叫 0。唯讀展示維持 3 案例、6 筆精選回放，可無 reports/ 重建；尚未發布。

> 先前 10/19 單輪：Nano→Ultra 已真實呼叫各一次，按 usage 計算 US$0.00660426；候選比對失敗，結果 needs_review，沒有 AI 修復成功，也沒有重試。VM 已恢復；一般 Web 付費入口仍關閉。見 [真實模型紀錄](api/MODEL_PILOT.md)。

Verify a README's first CLI workflow using a fixed functional acceptance contract.

**Status: local execution/validation prototype with a teammate HTTP API, integrated frontend and a static read-only demo. The core supports gated Nano/Ultra or all-Ultra routing, at most two repair rounds, durable model budgets, and frozen A/B/C/D evaluation protocols. Two real model development trials made six calls in total; both ended needs_review. Three distinct development repositories have execution evidence; the only verified README fix remains manual. The owner-pinned one-shot model API has HTTP/browser engineering checks, but has not run real inference through the Web. No holdout evaluation has run. Nightly monitoring, arbitrary-repo startup and Sandboxes execution are outside v1.**

The control process keeps expected results outside the container. Every fixture must produce its expected functional output; exit code zero alone does not pass. A manual candidate patch must pass both its first trial and another fresh-container trial before the result becomes `verified_fix`.

The public-source candidate passed 235 Python and 27 frontend engineering tests after clean extraction. Public preparation and withheld local metadata are described in [packaging/PUBLIC_SOURCE.md](packaging/PUBLIC_SOURCE.md); nothing has been published.

## Run without installing Python packages

Python 3.12+ and Git are needed for the core. The core has no third-party Python dependencies.

```sh
python3.12 scripts/fresh-eyes doctor
python3.12 scripts/fresh-eyes validate cases/mistletoe.json
PYTHONPATH=src python3.12 -m unittest discover -s tests -v
```

The tests use a synthetic repo and a clearly named test double; their results are engineering checks, not product benchmarks. Third-party project code is never executed on the host by these tests.

## Frontend teammate: start here

Latest real development trial: four model calls within US$0.03, usage-calculated US$0.01362438, result needs_review; no AI verified fix. See [evidence and the subsequent offline-only context fix](api/MODEL_TRIAL_RESULT_20261020.md).

Read [HANDOFF.md](PUBLIC_EXPORT.md) for the Chinese handoff, or [api/README.md](api/README.md) for the English interface guide.

```sh
python3.12 scripts/fresh-eyes serve
```

In a second terminal, run `python3.12 web/serve.py` and open [the local frontend](http://localhost:5173/). It includes case selection, acceptance review, run/error reports, history and all ten state previews, with Chinese/English display. Both frontend and API are included in the handoff ZIP. See [frontend notes](web/README.md).

The loopback-only API starts without packages, Docker or API keys. Version 0.2.1 serves real pinned case contracts, acceptance-review endpoints, an OpenAPI 3.1 contract and ten explicitly labelled static UI examples, including needs_input. Execution is disabled by default. Examples never appear as actual run history. See `api/client.js` for a dependency-free frontend helper and [the update for B](api/BACKEND_UPDATE.md).

With explicitly configured local assets and `--enable-runner`, the same API queues reviewed functional cases, persists progress/history in SQLite and serves real evidence/patches. It has one worker, at most four active/queued jobs, and recovery of interrupted runs. A data-directory lock prevents a second API instance from overwriting the active instance's jobs. These default modes do not call models or load `.env`. A separately owner-armed [single-use development plan](api/MODEL_API.md) is required for `repair_mode: model`.

## Prepared workspace runtime

The persistent VM has recorded execution evidence; its current state must be checked before another run. All three development repos now have offline and live-PyPI evidence. json2yaml's new live run passed both fixtures without models; the platform egress/cleanup gate also passed on 20 Oct. See [the latest handoff](api/READY_THROUGH_1022.md) and [the earlier offline report](api/JSON2YAML_OFFLINE.md).

The current Mac has Python 3.12 but no system Docker installation. Lima 2.2.1 and a Docker client were prepared under the parent workspace's `work/runtime`, without installing Homebrew packages. Lima's release checksum was verified. Chris restored the persistent VM on 2026-10-19. Rootless Docker 29.9.1 is available; real offline development runs now show mistletoe already passing and a manual README patch for md2html passing both candidate and independent fresh verification. See [actual evidence and limits](api/LOCAL_PILOT.md). These runs retain development-review attribution; no human approval or model call was created.

From a normal terminal, in this project directory:

```sh
python3.12 scripts/start-local-runtime.py
python3.12 scripts/fresh-eyes doctor --docker scripts/docker-local
python3.12 scripts/run-development.py --case mistletoe
python3.12 scripts/run-development.py --case md2html
python3.12 scripts/run-development.py --case md2html --candidate-patch
```

First startup downloads a Linux image and provisions rootless Docker inside the VM. The VM has no host directory mounts. New VM state defaults to the persistent short path `~/.local/share/fresh-eyes/lima`; its location is recorded in `work/runtime/lima-home.txt`. Existing complete/partial instances are preserved. See [runtime recovery](RUNTIME_RECOVERY.md). The recorded controlled PyPI gate passed on this local configuration; the socket disappeared again on 20 Oct, so check current availability before executing repositories. Logs, caches and downloaded tools stay separate from product source.

Stop the VM when finished:

```sh
python3.12 scripts/start-local-runtime.py --stop
```

For a separate no-network Linux core/API/frontend check, see [packaging/README.md](packaging/README.md). It does not execute a third-party repo or model. The scripts above use prepared workspace assets. On another computer, configure a Docker engine and clone the recorded repo commits. Offline development additionally needs a prepared wheelhouse; live PyPI mode needs the isolated-network gate. A portable VM installer is future work.

## Explicit container run

```sh
python3.12 scripts/fresh-eyes run cases/mistletoe.json \
  --source /path/to/mistletoe-checkout \
  --wheelhouse /path/to/reviewed-wheels \
  --output reports/mistletoe \
  --development
```

Cases marked `development_reviewed` require the explicit development flag. This is not upstream maintainer approval. The checkout HEAD must match the recorded 40-character SHA; source is exported from Git rather than copied from the working tree. Untracked files and local edits do not enter the run.

The v1 development and formal evaluation environment is **Linux arm64 / Python 3.12**, with an immutable local image ID and a passed real platform gate. All four existing holdout contracts already specify arm64. The initial amd64 proposal has not been executed. Every report records the actual platform, image ID and any offline wheel hashes.

## B integration and current inventory

B's model handoff and subsequent nine-file history update plus handoff note have been merged. See [integration status and next work](PUBLIC_EXPORT.md). The history update adds the correction UI and a json2yaml README source correction without changing its acceptance hash. Chris restarted the formal API; all three human approvals are preserved as revision-1 legacy snapshots. Case files retain their static reviews; actual approvals live in the API database. The four held-out contracts remain hidden.

See `cases/candidates.json` for source URLs, pinned commits, review status and unresolved questions:

- `mistletoe`: reviewed Markdown-to-HTML workflow. After fixing the runner's original environment error, real offline/live trials already pass; no README fault is asserted.
- `md2html`: real original workflow fails because the requirements-only step does not install the project CLI. The manual `pip install .` README patch passed candidate and independent clean verification. The separate real model candidate was rejected before validation. This is an installation omission, not observed dependency drift.
- `json2yaml`: third development contract, YAML-to-JSON output. Kevin approved the unchanged acceptance hash. Both fixtures pass in offline and live-PyPI runs; the 20 Oct live run has model_calls=0. See [the handoff](api/READY_THROUGH_1022.md) and [offline report](api/JSON2YAML_OFFLINE.md).
- Four draft holdout contracts live under cases/holdout, with an immutable inventory checked by scripts/fresh-eyes verify-holdout. They are excluded from normal API discovery. The frozen evaluation runner is implemented; human review and actual evaluation remain pending.
- `csvkit` remains an unused discovery candidate.

There are three distinct executed development repos: one documented failing workflow and two healthy ones. The earlier offline/live batches reused the same two; json2yaml adds a third repo, with both modes now checked. Only the manual md2html fix is verified. v1 uses this narrower development sample; no upstream acceptance, observed drift, model-fix success or general success rate is claimed.

## Execution boundaries

- Fresh Docker containers, immutable local image ID and no host bind mounts. Offline mode has no network; opt-in live mode uses a separate isolated internal network and PyPI-only CONNECT proxy.
- Non-root container, read-only root filesystem, dropped capabilities and explicit CPU/memory/PID/tmpfs limits.
- Offline wheels prepared with `pip download --only-binary=:all:`; packages are not built or executed on the host.
- Only exact README/requirements/dependency-field edits; no source, entrypoint or shell-wrapper changes.
- Container outputs are validated by the host. The container never receives expected results or model keys.
- Documented Python/pip aliases resolve explicitly to the fresh venv interpreter; reports retain both the original and executed argv. A prefix/pip-location probe runs before repository setup, and bootstrap failures are infrastructure errors.
- Reports distinguish infrastructure failures, unresolved workflows and verified manual fixes.

The offline wheel mirror is part of the recorded development environment and cannot observe upstream dependency releases. Formal evaluation and nightly fresh-install checks must use `pypi_live` after the actual Docker/PyPI gate passes; live mode does not use that wheelhouse or pip cache. See [dependency modes](api/DEPENDENCY_MODES.md). The local real egress gate has passed; scheduling and observed drift experiments remain pending. Missing packages or network failures are not automatically README faults. This prototype is intended for reviewed local cases; it is not a hardened public arbitrary-code execution service.

Reports contain `report.json` and an escaped static `report.html`. A failed or missing container runtime produces an honest `infrastructure_error` report with no repository attempts.

## Gated model integration

Use a local `.env` for credentials; do not commit or include it in handoffs. Ordinary run/serve/repair-plan commands do not load it or call models. Only explicitly activated evaluation-run or model-trial-run reads its selected env file, first checks the catalog against the frozen public model configuration, then applies the authorized budgets. The specifically authorized development trial activated it once and has exited; evaluation is still unrun. The separate `sandboxes-doctor --env-file .env` diagnostic reads the key and Project ID; `--check-remote` enables read-only metadata checks and cannot submit operations. See [Sandboxes access and remaining gates](PUBLIC_EXPORT.md).

The separate [development model-trial CLI](api/MODEL_TRIAL.md) now supports an attributed approval snapshot, a checked plan, one unused output directory and lazy key activation after a failed baseline. Its new behavior has engineering tests and a real-case read-only preview; the first real two-round trial has now completed as needs_review, with its separate evidence and consumed authorization.

The internal engine classifies a failed baseline, proposes one restricted patch per round and requires both candidate and independent fresh verification. It defaults to one round; an explicit two-round protocol keeps the original patch base, failed-candidate evidence and the same budget. nano_ultra and all_ultra use the same flow. The HTTP API accepts none/manual_candidate by default and model only for an owner-armed single-use plan; no such real plan is armed this turn. See [model API](api/MODEL_API.md), [budget rules](api/MODEL_INTEGRATION.md) and [evaluation runbook](evaluation/RUNBOOK.md). A read-only repair-plan command works from saved evidence without credentials or network.

The offline runtime, live PyPI gate and development baseline/manual-candidate trials have recorded evidence. Approval transfer/history, the frozen four-group runner and post-run team-review import are implemented. All three development cases have human approval. All four pinned holdout Git sources and archive exports are prepared; no holdout code was executed. There is no formal evaluation freeze or results.json yet; see [pre-freeze status](evaluation/PRE_FREEZE.md). Next gates are human review, real model validation of the context fix under separate authorization, then formal evaluation. The separate boundary baseline entry is implemented, with human review and real execution still pending.

## Sources and license

Fresh Eyes source is MIT licensed. Third-party source checkouts stay in workspace scratch storage with their original licenses. Repo2Run is relevant prior work, not a dependency or a claimed inferior baseline. The project plan is in the parent [PROJECT3.md](PUBLIC_EXPORT.md); the standalone teammate zip includes the self-contained handoff and API guide.
