// Build the screen-only demo video from DEMO_VIDEO_SCRIPT_V3.md (B, 2026-10-24).
//
// Every frame is our own read-only demo (served as in submission/gallery/README.md) driven in a throwaway headless
// Chrome, so nothing else on the screen is captured. Narration is the Mac's built-in voice, one clip per sentence, so
// captions and the .srt line up exactly. Corner labels and captions are drawn into the page (this ffmpeg has no
// drawtext/subtitles filter).
//
//   node submission/video/make_video.mjs                 # all scenes -> submission/video/out/
//   SCENES=1,2 node submission/video/make_video.mjs      # only some scenes (for checking)
//   LIVE_URL=http://127.0.0.1:8765 node ...              # scene 4 runs a real check on the local app (runner on)
//
// Needs: the demo on http://127.0.0.1:3003/fresh-eyes/, Google Chrome, ffmpeg, say.
import { spawn, execFileSync } from 'node:child_process';
import { mkdirSync, rmSync, writeFileSync, readFileSync, copyFileSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const OUT = join(HERE, 'out');
const WORK = process.env.WORK || mkdtempSync(join(tmpdir(), 'fe-video-'));
const BASE = process.env.BASE || 'http://127.0.0.1:3003/fresh-eyes/?lang=en';
const LIVE_URL = process.env.LIVE_URL || '';
const ENDCARD = process.env.ENDCARD || join(HERE, '..', 'gallery', 'endcard.png');  // from gallery/shoot.sh (REPO=… DEMO=… for links)
const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
// Zoe (Premium) at 165 words a minute (Chris, 24 Oct). RATE='' keeps a voice's own pace.
const VOICE = process.env.VOICE || 'Zoe (Premium)', RATE = process.env.RATE ?? '165';
const FPS = 15, W = 1920, H = 1080;
const LEAD = 0.6, GAP = 0.85, TAIL = 0.9;  // seconds of silence before, between and after caption lines

// Breathing room inside a caption line (Chris, 24 Oct: "one sentence at a time, with rests"). The voice reads these
// [[slnc ms]] commands as silence; captions show the plain text.
function spoken(line) {
  return line
    .replace(/([.?!])\s+(?=\S)/g, '$1 [[slnc 600]] ')   // two sentences in one caption line
    .replace(/([:;])\s+/g, '$1 [[slnc 380]] ')
    .replace(/,\s+/g, ', [[slnc 200]] ');
}

const RUN = { fails: '10175eee750c464fa7ce86ad4c84f037', aiFix: '5ac511039adb4977b32ef129e86ee006', e2e: '5c225204bcd946228a7ef4700c8c0c8c',
              aiTrial: '1a5f5135c92f4d15a5ff6dabe0a78b64', twoRounds: 'e9a04f641acb4c71b7ff0932e58f87e8' };

// Script v4 (submission/DEMO_VIDEO_SCRIPT_V3.md, revised 24 Oct): say what Fresh Eyes is first, then the real md2html
// story, with the uninterrupted AI fix of 24 Oct (5c225204) at the centre.
const SCENES = [
  { label: 'RECORDED SITE', url: `${BASE}#/`, min: 14,
    say: ['This is Fresh Eyes.',
          "It checks whether a project's README actually works for someone seeing it for the first time.",
          'It follows the instructions in a clean environment and checks the real output. When something is broken, it uses NVIDIA Nemotron to find a fix, and then proves it.'],
    actions: [] },
  { label: 'RECORDED · 19 Oct 2026', url: `${BASE}#/runs/${RUN.fails}`, min: 16,
    say: ["Here's a real example. The md2html project tells you to install the requirements, then run md2html.",
          "We followed it exactly, on a clean machine. The install worked, but the md2html command didn't exist.",
          'New users hit problems like this all the time, and maintainers rarely see them.'],
    actions: [{ at: 0, delay: 2.5, do: 'scrollText', text: 'README commands' },
              { at: 1, delay: 2.0, do: 'clickText', text: 'stderr', tag: 'summary' },
              { at: 1, delay: 2.3, do: 'scrollText', text: 'No such file or directory' }] },
  { label: 'RECORDED SITE', url: `${BASE}#/start`, min: 16,
    say: ['Before any check runs, a person decides what success means: which README lines, two sample inputs, and the exact expected output.',
          "That decision is locked with a hash, so the AI can't quietly change the test to make itself pass.",
          'And the expected answers never go inside the test environment.'],
    actions: [{ at: 0, delay: 1.0, do: 'scrollText', text: 'md2html' },
              { at: 0, delay: 2.2, do: 'clickText', text: 'md2html', tag: 'label' },
              { at: 0, delay: 3.4, do: 'clickText', text: 'Continue', tag: 'button' },
              { at: 1, do: 'clickText', text: 'Show details', tag: 'summary' },
              { at: 1, delay: 0.4, do: 'scrollText', text: 'Checked by:' }] },
  LIVE_URL
    ? { label: 'LIVE', clock: true, url: `${LIVE_URL}/?lang=en#/start/md2html-markdown`, min: 30, live: true,
        say: ['Now a live check. Fresh Eyes runs the README exactly as written, in a fresh container.',
              "A clean exit isn't enough. Only the right output counts.",
              "Here's the answer: the instructions don't work as written."],
        actions: [{ at: 0, delay: 1.2, do: 'clickText', text: 'Try the instructions', tag: 'button' }] }
    : { label: 'RECORDED · 19 Oct 2026', url: `${BASE}#/answer/${RUN.fails}`, min: 13,
        say: ['Then Fresh Eyes runs the README exactly as written, in a fresh container.',
              "A clean exit isn't enough. Only the right output counts.",
              "For md2html, the answer is no: the instructions don't work as written."],
        actions: [] },
  // Scenes 5-7: the uninterrupted end-to-end AI fix of 24 Oct (run 5c225204: Nano -> Ultra -> two clean passes).
  { label: 'RECORDED · 24 Oct 2026', url: `${BASE}#/runs/${RUN.e2e}`, min: 26,
    say: ['This is where Nemotron, running on Nebius Token Factory, comes in.',
          'Nemotron 3 Nano sorts the failure as a documentation problem.',
          'Nemotron 3 Ultra finds the cause: the README installs the dependencies, but never the package that provides the command.',
          'So it suggests a small change to the README, tied to exact line numbers. It can only edit the README or dependency files, never the source code.'],
    actions: [{ at: 0, delay: 0.8, do: 'scrollText', text: 'What Nemotron did' },
              { at: 3, do: 'scrollText', text: 'Edit 1 of 1' }] },
  { label: 'RECORDED · 24 Oct 2026', url: `${BASE}#/runs/${RUN.e2e}`, min: 22, scrollTo: 'Edit 1 of 1',
    say: ["A suggested fix doesn't count until it's proven.",
          'With the change, the README passes the locked check in a fresh container, and passes again in a second, independent clean run.',
          'Start to finish, it took about twenty-four seconds, with no human edits along the way.'],
    actions: [{ at: 1, do: 'scrollText', text: 'Candidate patch run', tag: '.tl-head, .tl-head *' },
              { at: 1, delay: 3.4, do: 'scrollText', text: 'Final clean re-run', tag: '.tl-head, .tl-head *' },
              { at: 2, do: 'scrollText', text: 'What Nemotron did' }] },
  { label: 'RECORDED · 24 Oct 2026', url: `${BASE}#/runs/${RUN.e2e}`, min: 22,
    say: ['Every model call is logged, with the model name, the tokens used, and the estimated cost. This fix took two calls and about half a cent, calculated from usage; the final bill has not been reconciled yet.',
          "The worst-case cost is set aside before each call, so a run never starts a call it can't afford.",
          "Not every attempt succeeds. When a suggested edit doesn't fit, it's rejected, and the run stops instead of guessing."],
    actions: [{ at: 0, delay: 0.6, do: 'scrollText', text: 'Model calls' },
              { at: 2, do: 'label', text: 'RECORDED · 20 Oct 2026' },
              { at: 2, do: 'nav', url: `${BASE}#/runs/${RUN.twoRounds}` },
              { at: 2, delay: 1.5, do: 'scrollText', text: 'matched 0 times' }] },
  { label: 'RECORDED SITE', url: `${BASE}#/examples`, min: 12,
    say: ["Everything you've seen comes from real runs, including the failures.",
          "Fresh Eyes. A newcomer's first five minutes, checked and proven.",
          'Links to the demo and the source code are below.'],
    actions: [{ at: 1, do: 'card', file: ENDCARD }] },
];

const sh = (cmd, args) => execFileSync(cmd, args, { stdio: ['ignore', 'pipe', 'pipe'] }).toString();
const dur = f => parseFloat(sh('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', f]));
const sleep = ms => new Promise(r => setTimeout(r, ms));

// 1. Narration: one clip per sentence, then the scene timeline.
function narrate(i, scene) {
  const starts = [], clips = [];
  let t = LEAD;
  scene.say.forEach((line, j) => {
    const aiff = join(WORK, `s${i}_${j}.aiff`), wav = join(WORK, `s${i}_${j}.wav`);
    sh('say', ['-v', VOICE, ...(RATE ? ['-r', RATE] : []), '-o', aiff, spoken(line)]);
    sh('ffmpeg', ['-y', '-v', 'error', '-i', aiff, '-ar', '48000', '-ac', '1', wav]);
    const d = dur(wav);
    starts.push(t); clips.push({ wav, start: t, end: t + d, text: line });
    t += d + GAP;
  });
  const length = Math.max(scene.min, t - GAP + TAIL);
  return { starts, clips, length };
}

// 2. Chrome over the DevTools protocol.
async function chrome() {
  const profile = mkdtempSync(join(tmpdir(), 'fe-chrome-'));
  const port = 9400 + Math.floor(Math.random() * 400);
  const proc = spawn(CHROME, ['--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--mute-audio',
    `--user-data-dir=${profile}`, `--remote-debugging-port=${port}`, `--window-size=${W},${H}`, 'about:blank'], { stdio: 'ignore' });
  let target;
  for (let k = 0; k < 50 && !target; k++) {
    await sleep(200);
    try { target = (await (await fetch(`http://127.0.0.1:${port}/json/list`)).json()).find(x => x.type === 'page'); } catch {}
  }
  if (!target) throw new Error('Chrome did not start');
  const ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((ok, bad) => { ws.onopen = ok; ws.onerror = bad; });
  let id = 0; const wait = new Map();
  ws.onmessage = ev => { const m = JSON.parse(ev.data); if (m.id && wait.has(m.id)) { wait.get(m.id)(m); wait.delete(m.id); } };
  const send = (method, params = {}) => new Promise((ok, bad) => {
    const n = ++id; const timer = setTimeout(() => { wait.delete(n); bad(new Error(`${method}: no answer in 15 s`)); }, 15000);
    wait.set(n, m => { clearTimeout(timer); m.error ? bad(new Error(`${method}: ${m.error.message}`)) : ok(m.result); });
    ws.send(JSON.stringify({ id: n, method, params }));
  });
  const close = async () => {
    try { ws.close(); } catch {}
    const gone = new Promise(r => proc.once('exit', r)); proc.kill(); await Promise.race([gone, sleep(3000)]);
    try { rmSync(profile, { recursive: true, force: true, maxRetries: 5 }); } catch {}
  };
  return { send, close };
}

// Corner label, optional clock and caption, redrawn after every navigation; plus helpers the actions call.
const PAGE_HELPERS = `
window.__fe = {
  state: { label: '', caption: '', clock: false, on: true },
  draw() {
    const s = this.state;
    let box = document.getElementById('__fe_overlay');
    if (!box) {
      box = document.createElement('div'); box.id = '__fe_overlay';
      box.innerHTML = '<div id="__fe_label"></div><div id="__fe_caption"></div>';
      const css = document.createElement('style');
      css.textContent = '#__fe_overlay{position:fixed;inset:0;pointer-events:none;z-index:2147483647;font:600 17px/1.35 -apple-system,system-ui,sans-serif}'
        + '#__fe_label{position:absolute;left:18px;bottom:34px;padding:5px 11px;border-radius:8px;background:rgba(17,24,39,.82);color:#fff;letter-spacing:.06em;font-size:13px}'
        + '#__fe_label.live{background:#b91c1c}'
        + '#__fe_caption{position:absolute;left:50%;bottom:30px;transform:translateX(-50%);max-width:1140px;padding:8px 18px;border-radius:8px;background:rgba(0,0,0,.8);color:#fff;font-size:26px;font-weight:500;text-align:center}'
        + '#__fe_caption:empty{display:none}';
      (document.head || document.documentElement).appendChild(css);
      (document.body || document.documentElement).appendChild(box);
    }
    box.style.display = s.on ? '' : 'none';
    const lab = document.getElementById('__fe_label');
    const now = new Date();
    lab.textContent = s.label + (s.clock ? ' · ' + now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '');
    lab.className = s.label === 'LIVE' ? 'live' : '';
    lab.style.display = s.label ? '' : 'none';
    document.getElementById('__fe_caption').textContent = s.caption;
  },
  set(patch) { Object.assign(this.state, patch); this.draw(); },
  find(text, tags) {
    const all = [...document.querySelectorAll(tags || 'h1,h2,h3,h4,summary,button,a,code,pre,td,th,li,p,span,div')]
      .filter(e => e.offsetParent !== null && e.textContent.includes(text) && !e.closest('#__fe_overlay'));
    return all.sort((a, b) => a.textContent.length - b.textContent.length)[0] || null;
  },
  scrollText(text, ms, tags) {
    const e = this.find(text, tags); if (!e) return 'missing: ' + text;
    const r = e.getBoundingClientRect();
    const to = Math.max(0, Math.min(document.documentElement.scrollHeight - innerHeight, scrollY + r.top - innerHeight * 0.3));
    const from = scrollY, t0 = performance.now(); ms = ms || 1400;
    const step = now => { const k = Math.min(1, (now - t0) / ms), e2 = k < .5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
      scrollTo(0, from + (to - from) * e2); if (k < 1) requestAnimationFrame(step); };
    requestAnimationFrame(step); return 'ok';
  },
  clickText(text, tags) { const e = this.find(text, tags); if (!e) return 'missing: ' + text; e.click(); return 'ok'; },
};
setInterval(() => window.__fe && window.__fe.draw(), 500);
`;

async function record(i, scene, timeline, cdp) {
  const dir = join(WORK, `f${i}`); rmSync(dir, { recursive: true, force: true }); mkdirSync(dir, { recursive: true });
  const overlay = { label: scene.label, clock: !!scene.clock, caption: '', on: true };
  const apply = () => cdp.send('Runtime.evaluate', { expression: `window.__fe && window.__fe.set(${JSON.stringify(overlay)})` });
  const nav = async url => {
    await cdp.send('Page.navigate', { url });
    for (let k = 0; k < 40; k++) {  // wait for the app to render something real
      await sleep(150);
      const r = await cdp.send('Runtime.evaluate', { expression: `!!(document.readyState === 'complete' && (document.querySelector('#view *') || !document.querySelector('#view')))`, returnByValue: true });
      if (r.result.value) break;
    }
    await sleep(500); await apply();
  };
  await nav(scene.url);
  if (scene.scrollTo) {  // start where the previous scene left off
    await cdp.send('Runtime.evaluate', { expression: `window.__fe.scrollText(${JSON.stringify(scene.scrollTo)}, 1)` }); await sleep(300);
  }
  const events = [
    ...timeline.clips.map(c => ({ t: c.start, run: async () => { overlay.caption = c.text; await apply(); } })),
    ...timeline.clips.map((c, j) => ({ t: (timeline.clips[j + 1]?.start ?? timeline.length) - 0.05, run: async () => { if (j === timeline.clips.length - 1) { overlay.caption = ''; await apply(); } } })),
    ...scene.actions.map(a => ({ t: (a.at === 0 ? 0.3 : timeline.starts[a.at]) + (a.delay || 0), run: async () => {
      if (a.do === 'nav') { await nav(a.url); return; }
      if (a.do === 'label') { overlay.label = a.text; await apply(); return; }
      if (a.do === 'card') {  // a full-frame still (the end card) faded in over the page; label hidden, captions stay
        overlay.label = ''; await apply();
        const src = `data:image/png;base64,${readFileSync(a.file).toString('base64')}`;
        await cdp.send('Runtime.evaluate', { expression: `(() => { const i = document.createElement('img'); i.src = ${JSON.stringify(src)};
          i.style.cssText = 'position:fixed;inset:0;width:100vw;height:100vh;object-fit:cover;z-index:2147483646;opacity:0;transition:opacity .6s';
          document.body.appendChild(i); requestAnimationFrame(() => requestAnimationFrame(() => { i.style.opacity = 1; })); })()` });
        return;
      }
      const arg = a.do === 'clickText' ? `${JSON.stringify(a.text)}, ${JSON.stringify(a.tag || null)}` : `${JSON.stringify(a.text)}, 0, ${JSON.stringify(a.tag || null)}`;
      const r = await cdp.send('Runtime.evaluate', { expression: `window.__fe.${a.do}(${arg})`, returnByValue: true });
      if (r.result.value !== 'ok') console.warn(`scene ${i + 1}: ${r.result.value}`);
    } })),
  ].sort((a, b) => a.t - b.t);

  const frames = Math.ceil(timeline.length * FPS);
  const t0 = performance.now(); let last = null, e = 0, stalls = 0, pending = Promise.resolve();
  for (let k = 0; k < frames; k++) {
    const due = k / FPS;
    while (e < events.length && events[e].t <= due) { const ev = events[e++]; pending = pending.then(ev.run); }
    const wait = t0 + due * 1000 - performance.now(); if (wait > 0) await sleep(wait);
    const name = join(dir, `${String(k).padStart(5, '0')}.jpg`);
    if (performance.now() - t0 > (due + 1 / FPS) * 1000 && last) { copyFileSync(last, name); continue; }  // behind: repeat the last frame
    let shot;
    try { shot = await cdp.send('Page.captureScreenshot', { format: 'jpeg', quality: 88 }); stalls = 0; }
    catch (err) {  // headless Chrome occasionally stalls one capture: keep the last frame and go on
      if (!last || ++stalls > 3) throw err;
      console.warn(`scene ${i + 1}: ${err.message}; repeating the last frame`);
      copyFileSync(last, name); continue;
    }
    writeFileSync(name, Buffer.from(shot.data, 'base64')); last = name;
  }
  await pending;
  return dir;
}

// 3. Put it together.
const pick = process.env.SCENES ? process.env.SCENES.split(',').map(n => +n - 1) : SCENES.map((_, i) => i);
mkdirSync(OUT, { recursive: true });
const health = await fetch(`${BASE.split('?')[0]}data/health.json`).catch(() => null);
if (!health?.ok) { console.error('Start the demo on 3003 first (submission/gallery/README.md).'); process.exit(1); }
const cdp = await chrome();
await cdp.send('Page.enable'); await cdp.send('Runtime.enable');
// A 1440×810 layout drawn at 4/3 scale: 1920×1080 frames with text large enough to read on a phone.
await cdp.send('Emulation.setDeviceMetricsOverride', { width: W * 3 / 4, height: H * 3 / 4, deviceScaleFactor: 4 / 3, mobile: false });
await cdp.send('Page.addScriptToEvaluateOnNewDocument', { source: PAGE_HELPERS });

const parts = [], srt = []; let offset = 0;
try {
  for (const i of pick) {
    const scene = SCENES[i]; const tl = narrate(i, scene);
    console.log(`scene ${i + 1}: ${tl.length.toFixed(1)} s`);
    const frames = await record(i, scene, tl, cdp);
    // Audio: the sentence clips at their start times over silence of the scene's length.
    const audio = join(WORK, `a${i}.wav`);
    const inputs = tl.clips.flatMap(c => ['-i', c.wav]);
    const mix = tl.clips.map((c, j) => `[${j + 1}:a]adelay=${Math.round(c.start * 1000)}[d${j}]`).join(';')
      + `;[0:a]${tl.clips.map((_, j) => `[d${j}]`).join('')}amix=inputs=${tl.clips.length + 1}:normalize=0[m]`;
    sh('ffmpeg', ['-y', '-v', 'error', '-f', 'lavfi', '-t', String(tl.length), '-i', 'anullsrc=r=48000:cl=mono', ...inputs,
      '-filter_complex', mix, '-map', '[m]', '-t', String(tl.length), audio]);
    const part = join(WORK, `p${i}.mp4`);
    sh('ffmpeg', ['-y', '-v', 'error', '-framerate', String(FPS), '-i', join(frames, '%05d.jpg'), '-i', audio,
      '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-r', '30', '-preset', 'medium', '-crf', '20', '-c:a', 'aac', '-b:a', '160k',
      '-t', String(tl.length), part]);
    parts.push(part);
    // A still from the middle of each scene, for checking.
    copyFileSync(join(frames, `${String(Math.floor(tl.length * FPS / 2)).padStart(5, '0')}.jpg`), join(OUT, `scene-${i + 1}.jpg`));
    tl.clips.forEach(c => srt.push({ a: offset + c.start, b: offset + c.end, text: c.text }));
    offset += tl.length;
  }
} finally { await cdp.close(); }

const list = join(WORK, 'parts.txt');
writeFileSync(list, parts.map(p => `file '${p}'`).join('\n'));
const name = pick.length === SCENES.length ? 'fresh-eyes-demo' : `fresh-eyes-demo-scenes-${pick.map(i => i + 1).join('-')}`;
sh('ffmpeg', ['-y', '-v', 'error', '-f', 'concat', '-safe', '0', '-i', list, '-c', 'copy', join(OUT, `${name}.mp4`)]);
const ts = s => { const ms = Math.round(s * 1000); const p = (n, w = 2) => String(n).padStart(w, '0');
  return `${p(Math.floor(ms / 3600000))}:${p(Math.floor(ms / 60000) % 60)}:${p(Math.floor(ms / 1000) % 60)},${p(ms % 1000, 3)}`; };
writeFileSync(join(OUT, `${name}.srt`), srt.map((c, n) => `${n + 1}\n${ts(c.a)} --> ${ts(c.b)}\n${c.text}\n`).join('\n'));
console.log(`${join(OUT, name)}.mp4  ${offset.toFixed(1)} s${offset > 180 ? '  (over 3:00!)' : ''}`);
if (!process.env.WORK) rmSync(WORK, { recursive: true, force: true });
