# B 的真人確認：跨機交接已可用

這個功能只搬移已記錄的真人團隊確認，不會把 draft／development_reviewed 自動變成批准。原始 reviewer、時間與 acceptance hash 保留，contract 檔案不改；不執行 repo、不讀 key、不呼叫模型。

## B：看完案例後匯出

先在原有 UI 確認成功條件；填的應是實際看過兩組輸入與預期值的真人。若不認同，記錄原因，不要確認。

在 B 的專案目錄執行，data-dir 必須對應當時 serve 使用的資料目錄：

```sh
python3.12 scripts/fresh-eyes approvals-export \
  --data-dir .fresh-eyes/api --output approvals-B.json
```

把 approvals-B.json 交回 A。沒有已確認紀錄會匯出 0 筆，不能拿開發審閱或 AI reviewer 冒充真人。

## A：先檢查，再匯入

```sh
python3.12 scripts/fresh-eyes approvals-import approvals-B.json \
  --data-dir .fresh-eyes/api
```

預設只預覽：列出原 reviewer、case ID、將匯入／已存在的數量，不寫資料庫。核對檔案確實由隊友提供後，用同一命令加 --apply：

```sh
python3.12 scripts/fresh-eyes approvals-import approvals-B.json \
  --data-dir .fresh-eyes/api --apply
```

一次匯入在同一 SQLite transaction 內完成；repo、commit、acceptance hash 必須符合本機目前案例。重複紀錄、內容不符或與本機已有 reviewer／時間衝突會拒絕，不靜默覆寫；同一份再次匯入則不重複新增。已運行 API 的下一次查詢即可讀到匯入紀錄，不用同步整份 SQLite。

這是沒有數位簽章的團隊資料交接。payload SHA-256 只能檢查檔案是否符合內容，不能驗證身分；操作者仍需知道來源是誰。它不是上游維護者認可，不會建立新的真人審閱事實。

目前只支援一般 API 登記的開發案例；保留集仍不公開載入，不能靠此命令解除保留集隔離。真實現有資料尚未由工具代替任何人批准；工程測試使用明確標示的合成 reviewer。

## 現行確認與更正歷史

新增確認匯入時會記 imported 歷史事件；已有不同的確認仍拒絕覆蓋。v1 交接檔只攜帶現行 reviewer／原 approved_at，不同步完整更正事件。需要改名時使用 [明確更正](APPROVAL_HISTORY.md)，不要把衝突的匯入當成更名方式。
