# B 首批交付已整合：真實離線試跑完成

> 最新模型實測：Nano→Ultra 已真實呼叫各一次，按 usage 計算 US$0.00660426；候選比對失敗，結果 needs_review，沒有 AI 修復成功，也沒有重試。VM 已恢復；一般 Web 付費入口仍關閉。見 [真實模型紀錄](MODEL_PILOT.md)。

已整合 fresh-eyes-B-2026-10-19.zip 的 12 個檔案。原檔和被替換的 5 個舊檔已備份到工作區 work/B-integration-20261019-153c2541；交接 ZIP 不包含這些本機備份。

## 已完成

- 前端依 health 顯示依賴模式，送出 dependency_mode；即時 PyPI 未開放時不可選。草稿與缺值有對應顯示。
- 開發集 3 案：mistletoe、md2html、json2yaml。新增案例保留 draft，沒有代替真人 approve。
- 四個保留案例的檔案與驗收 hash 已固定於 cases/holdout/freeze.json。一般 API 不載入該目錄。
- 新增只讀命令 python3.12 scripts/fresh-eyes verify-holdout，檢查檔案、contract 與 acceptance hash；沒有執行、批准或評估功能。
- 修正 macOS /var 與 /private/var 路徑別名的測試比較，8 個啟動測試另在 symlink TMPDIR 通過。
- 離線安裝找不到 distribution／build dependency 時，保留 log／freeze 並回報 infrastructure_error，不據此斷言 README 故障。已在隔離環境建置 json2yaml／docopt 與相關依賴 wheels，第三案功能仍待真人覆核。
- 130 個工程測試通過。實際瀏覽器確認三案顯示、json2yaml 草稿與即時 PyPI 禁用狀態；沒有批准、執行 repo 或呼叫付費服務。

## 更新：離線與即時 PyPI 試跑已完成

先前 VM 已恢復並完成下列試跑；最新檢查 Docker socket 已消失，需重新啟動；mistletoe 原始通過，md2html 原始失敗，人工候選與獨立乾淨重跑通過。模型呼叫 0，真人確認仍未建立。另完成受控 PyPI gate、兩案 live 重跑及四個 wheels；看 [本輪證據](LIVE_PILOT.md)、[原離線證據](LOCAL_PILOT.md)與 [B 工作單](../PUBLIC_EXPORT.md)。

新收到的 all.zip 共 18 檔，已驗證路徑、型別與 handoff checksum，保存在工作區 B-all-review；其新增評估頁與投稿草稿尚未覆蓋目前版本，先由 B 修正工作單列出的四項資料問題。原首批 12 檔整合狀態不變。

## 原先順序及目前狀態

| 順序 | 誰做 | 完成條件 |
|---|---|---|
| 1 | 你或朋友，實際看過內容的真人 | 先看 mistletoe、md2html 的 README 與兩組輸入／預期值。合理才在介面確認；有疑慮記在 cases/CASE_NOTES.md。確認表仍是空白 |
| 2 | 你，在一般 Terminal | 已完成：永久 VM 啟動，Docker 29.9.1 可連線 |
| 3 | A／後端 | 已完成：兩案原始流程、md2html 人工候選與獨立乾淨驗證。仍為開發審閱、arm64，離線與 live 結果分開記錄，詳見 LIVE_PILOT.md |
| 4 | B | 核對真實報告的狀態、log、diff、依賴模式與未知費用。先確認已有的成功／失敗路徑，再整理 demo 腳本 |
| 5 | A／後端 | 已完成隔離 wheel 建置；json2yaml 仍待 B 真人覆核，功能未跑 |
| 6 | A＋B | 有額度與批准上限、可用 runner 後，才接真實 Nano／Ultra；保留集等正式評估入口與真人確認完成後再跑 |

更新後重新啟動 API，GET /api/cases 應有 3 案且含 json2yaml-yaml2json。合併前啟動的程序不會自動讀取新檔；API 仍為 0.2.1，沒有變更前端接口。

## B 提出的事項：剩餘範圍

- **sdist**：已有離線缺套件的環境錯誤分類；已完成四個 wheels 的隔離建置，第三案功能／安裝流程仍待真人覆核後實跑。
- **保留集入口**：已有 freeze manifest／完整性檢查；正式評估 runner 尚未實作，不能說保留集已跑完。
- **跨機器確認**：已實作 approval 匯出／預覽／明確套用，保留原覆核人、時間、repo／commit 與 acceptance hash，拒絕不符或衝突。見 [交接操作](APPROVAL_TRANSFER.md)。尚無真人確認可匯出，不會代人 approve。
- **新案例載入**：文件明確要求重啟；沒有新增熱載入。
- **舊安裝命令、stdin、CSV validator**：目前不擴充；現有七份功能 contract 都能表達，不擋兩案試跑。
- **OpenAPI Review enum**：已對齊 approved、development_reviewed、draft、example；前端仍應保留未知值。
- **真實成功路徑**：已完成兩案離線開發證據與前端查看；受控 PyPI 與 live 重跑已完成；正式模型／保留集仍待做。

## 評估範圍要如實呈現

開發集靜態預期為兩個可能健康、一個可能故障，不是已確認的健康／故障數量。四個保留案例集中在 Markdown／HTML 轉換，結果不能外推成所有 Python CLI 的修復率。不要為了增加失敗數而更換已凍結案例或降低預期輸出。

B 的原始筆記與問題清單保留原文；本文件記錄整合後處理狀態。Sandboxes 申請等待回覆，付費模型維持關閉。
