# Video script draft — Fresh Eyes (target 2:50, hard limit 3:00)

Written 2026-10-19. Official tips: pitch, not tutorial; lead with the problem; **say Nebius Token Factory and the NVIDIA model names out loud**. Every shot marked **[real run]** must be a recording of an actual run in the submitted build; if it isn't available, cut the shot rather than mock it. Waiting time may be cut, but say "sped up" on screen.

| Time | Screen | Narration (spoken) |
|---|---|---|
| 0:00–0:15 | md2html README install line, then its report: install OK, both inputs `No such file or directory: 'md2html'` **[real run: `10175eee…`, live PyPI]** | "Here's a README that tells you to install the requirements and then run `md2html`. Follow it exactly, in a clean container, and the command doesn't exist. That install step never creates it." |
| 0:15–0:25 | Fresh Eyes home: quick check box and the three-step flow | "Fresh Eyes is an agent that reads your README like a newcomer, runs it in a clean environment, and only calls a fix verified when the real output is right." |
| 0:25–0:45 | Step 1 and 2: case with README line numbers, goal, two inputs and expected outputs; "Locked" with the reviewer's name, time and hash, and the approval history **[real: the three dev cases were approved by the real reviewer on 2026-10-19/20. Show one of those, or record the reviewer approving a new real case that day. Never approve under a stand-in name to film it]** | "First, a person approves the acceptance check: two inputs, their expected outputs, and the README lines they come from. Then it's locked by hash, so the agent can never edit it." |
| 0:45–1:35 | **Model version, record only once real model runs exist:** Step 3 timeline: original README run fails → classification → diagnosis with cited evidence → patch diff → fresh run → final independent re-run passes | "It runs the README exactly as written. It fails. Nemotron 3 Nano, on Nebius Token Factory, classifies the failure from the log. Nemotron 3 Ultra reads the evidence and proposes one small fix: here, one line in the README. Fresh Eyes never touches source code. Then it starts again from a clean environment with only that patch, and checks the real output. Only now is it a verified fix." |
| 0:45–1:35 | **Version recordable now:** md2html report in the UI: original run failed → manual candidate patch (one-line diff) → candidate run passes → final clean re-run passes **[real run: `563db906…`, live PyPI]** | "Fresh Eyes runs the README exactly as written, and it fails. The fix here is a one-line README change, prepared by hand as a candidate. Fresh Eyes doesn't take our word for it: it starts again from a clean container with only that patch, checks the real output against the locked check, then does it once more from scratch. Two clean passes, so it's a verified fix. Next, the same loop with Nemotron proposing the patch." [Last sentence only if that's still the plan on recording day.] |
| 1:35–1:55 | A boundary case stopping (`unsupported`), and the locked check unchanged **[real run]** | "When a fix would need source changes, a system package or a real key, it stops and says why, instead of hacking around the check." |
| 1:55–2:20 | Evaluation table **[real results]**: A / B / C / D with denominators, failures, time and cost | "We froze four holdout repositories before running anything. Here are the real results, including the failures. [TBD numbers.] Comparing Nano-plus-Ultra with Ultra for everything: [TBD]." |
| 2:20–2:40 | Cost ledger with real model IDs and usage; nightly history if it exists **[real run]** | "Every model call is in a ledger with the real model ID, tokens and cost, priced from Token Factory's own model catalog. Unknown costs stay unknown." [If nightly checks exist:] "Approved cases re-run every night, so drift shows up before a newcomer finds it." |
| 2:40–2:50 | Title card: name, track, repo URL | "Fresh Eyes. For maintainers and DevRel teams who want a newcomer's first five minutes to keep working. Built with NVIDIA Nemotron on Nebius Token Factory." |

## Evidence for each shot (as of 2026-10-19)

| Shot | Status | Evidence |
|---|---|---|
| 0:00 problem | Recordable now | `api/LIVE_PILOT.md`, run `10175eee750c464fa7ce86ad4c84f037` (offline repeat: `c2dd01c4…`) |
| 0:25 approval | Recordable now: mistletoe, md2html and json2yaml are locked by the real reviewer (kevin). The history panel appears only once the API runs the new build | `cases/CASE_NOTES.md` approval table; `GET /api/cases` |
| Optional: rejected proposal in full | Recordable now from real data: run `e9a04f64…` (20 Oct) round 1, which shows the full proposal (text to find, replacement `pip install -e .`, setup step), "Rejected · Not applied" and the reason "matched 0 times" | `api/MODEL_TRIAL_RESULT_20261020.md`, `api/B_QA.md` section R2 |
| 0:45 fix loop, manual version | Recordable now | run `563db9062b7b4e48a4490e41b6792ff6`; patch from the API patch endpoint |
| 0:45 fix loop, model version | Not possible yet: two real model runs, both `needs_review`, so there's no model-generated verified fix. The next authorised run tests the context fix | `api/MODEL_PILOT.md`, `api/MODEL_TRIAL_RESULT_20261020.md` |
| Optional: "knows when to stop" | Recordable now as a replay, best from run `e9a04f64…`. Round 1 is rejected by the patch checker; in round 2 Ultra says it can't see the full install section and returns no patch. Narrate it as the agent declining to guess, not as a fix | run `e9a04f64…` (two rounds) or `e5150fec…` (one round); show the "Recorded real run · replay" badge |
| 1:35 boundary stop | Not run yet. The contracts and expected end states are ready in `cases/boundary/` (static only) | `cases/boundary/README.md` |
| 1:55 evaluation | Not run yet; only the source inventory is pinned. Human review and the formal code/config freeze remain pending | `cases/holdout/freeze.json`, `evaluation/PRE_FREEZE.md` |
| 2:20 ledger | Recordable now from run `e5150fec…`: 2 calls with real model IDs, tokens, reasoning tokens and calculated cost; billed amount unknown | `reports/model-pilot-20261019-once/model-ledger.json` |

A shot recorded from the pilot shows the original run time in the report header; don't present it as happening live.

## Before recording

- [ ] Each **[real run]** shot exists in the submitted build, recorded the same day.
- [ ] Narration numbers match `evaluation/` exactly; no number without a denominator.
- [ ] If the demo used the manual candidate patch, the narration says "manual candidate", not Ultra.
- [ ] md2html is described as an install step that never created the command, not as dependency drift.
- [ ] Drop Sandboxes, nightly checks or Tavily lines if they aren't real at submission.
- [ ] If quick checks for any repo aren't supported yet, keep the quick-check box out of the 0:15 shot.
- [ ] English subtitles; check the video is **public** on YouTube and under 3:00.
