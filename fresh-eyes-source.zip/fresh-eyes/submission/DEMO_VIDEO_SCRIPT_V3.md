# Demo video script v3: the AI-written fix is the centre (B, 2026-10-24; revised: says what Fresh Eyes is first)

Replaces v2 now that a Nemotron-written patch has passed clean verification (run `5ac51103…`, validating the unchanged
proposal from trial `1a5f5135…`). Same rules as v2: under 3 minutes, English, only our own app on screen, no music,
every scene labelled RECORDED with its date (or LIVE), nothing staged.

**Made:** `submission/video/out/fresh-eyes-demo.mp4`, 2:41, 1920×1080, Apple voice Zoe (Premium) at 162 words a minute + burned-in captions,
plus `fresh-eyes-demo.srt`. Built by `node submission/video/make_video.mjs` from the read-only demo (17 recordings).

## Scenes (399 words of narration)

| # | Label | Screen | Narration |
|---|---|---|---|
| 1 | RECORDED SITE | `#/` | This is Fresh Eyes. It checks whether a project's README actually works for someone seeing it for the first time. It follows the instructions in a clean environment and checks the real output. When something is broken, it uses NVIDIA Nemotron to find a fix, and then proves it. |
| 2 | RECORDED · 19 Oct 2026 | `#/runs/10175eee…` | Here's a real example. The md2html project tells you to install the requirements, then run md2html. We followed it exactly, on a clean machine. The install worked, but the md2html command didn't exist. New users hit problems like this all the time, and maintainers rarely see them. |
| 3 | RECORDED SITE | `#/start` | Before any check runs, a person decides what success means: which README lines, two sample inputs, and the exact expected output. That decision is locked with a hash, so the AI can't quietly change the test to make itself pass. And the expected answers never go inside the test environment. |
| 4 | RECORDED · 19 Oct 2026 | `#/answer/10175eee…` | Then Fresh Eyes runs the README exactly as written, in a fresh container. A clean exit isn't enough. Only the right output counts. For md2html, the answer is no: the instructions don't work as written. |
| 5 | RECORDED · 24 Oct 2026 | `#/runs/5ac51103…` | This is where Nemotron, running on Nebius Token Factory, comes in. Nemotron 3 Nano sorts the failure, and Tavily looks up the project's own documentation. Nemotron 3 Ultra finds the cause: the README installs the dependencies, but never the package that provides the command. So it suggests a small change to the README, tied to exact line numbers. It can only edit the README or dependency files, never the source code. |
| 6 | RECORDED · 24 Oct 2026 | `#/runs/5ac51103…` | A suggested fix doesn't count until it's proven. With the change, the README passes the locked check in a fresh container, and passes again in a second, independent clean run. To be transparent: the first attempt was interrupted by a problem in our own test setup. So we re-checked the exact same patch, without calling the model again. |
| 7 | RECORDED · 24 Oct 2026 | `#/runs/1a5f5135…` | Every model call records the model, tokens and estimated cost. This proposal used less than two cents, calculated from usage; billing is not reconciled. Before each call, the worst-case cost is set aside, so a run never starts a call it can't afford. And when a suggested edit doesn't fit, it's rejected. In this earlier run, Ultra chose not to guess. |
| 8 | RECORDED SITE | `#/examples` | Everything you've seen comes from real runs, including the failures. Fresh Eyes. A newcomer's first five minutes, checked and proven. Links to the demo and the source code are below. |

Scene 4 becomes LIVE (`LIVE_URL=…`) if A runs the local app with the runner on during recording; its narration then says
"Now a live check" and the time is shown.

## Honesty checks (each one is in the narration or on screen)

- The 19 Oct fix of the same README was written by a person; this script doesn't show it, so it can't be confused with the AI one.
- The AI patch is called verified only because the original README failed and the unchanged patch passed in a fresh
  container and again in an independent clean re-run (`5ac51103…`).
- Scene 6 says the first attempt was interrupted by a problem in our own test setup and the same patch was re-checked
  without calling the model again. On screen: the run's notice "validates an unchanged saved AI proposal".
- "Under two cents": the original trial's ledger shows Nano $0.0002 + Ultra $0.0139 calculated from usage
  (billing not reconciled). If the submitted text gives another figure, change this line.
- No claim about formal evaluation, success rates or other repositories.

## Still to do before upload

- End card without links: regenerate `gallery/endcard.png` with `REPO=… DEMO=…` once the public repo and Pages URL are final.
- If WIN-4 produces an uninterrupted end-to-end AI fix, or the maintainer note / formal evaluation run for real, update
  scenes 6–8 first, then rebuild.
- Chris watches it once and uploads it to YouTube from their own account.


## A 對最新 Zoe 版的修訂（10/24）

保留 Chris 定案的 Zoe (Premium)、162 字／分、先介紹產品。B 最新原片經 ffprobe 確認 161.041 秒、1920×1080、有 H.264／AAC；先前 Samantha 158.488 秒只是舊版。

第 7 段改為 usage estimate 和 billing not reconciled；這裡只算原提案那兩次呼叫，不包含其他失敗試跑。原片與原字幕仍保留，新旁白需要 B 重製音軌／燒錄字幕，不能直接套舊時間碼。

目前公開網址已可用，片尾請放 `https://johncat88425-del.github.io/fresh-eyes/`、`https://github.com/johncat88425-del/fresh-eyes`。正式評估沒有執行；不新增成功率或「全自動一次成功」說法。
