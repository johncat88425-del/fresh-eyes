# Figma AI prompt: Fresh Eyes, redesigned for absolute beginners

B, 2026-10-21. Paste everything inside the box into Figma AI (Figma Make / First Draft). The prompt is in English because the tool follows English most precisely; the Chinese notes at the bottom are for us.

---

```
Design a calm, beautiful, extremely simple web app called "Fresh Eyes".
The test: an 80-year-old who has never used a computer must understand, within 5 seconds of opening it,
what this site is for and what to press first. Every design decision serves that test.

WHAT THE PRODUCT DOES (explain it this simply on screen)
Many software projects come with written instructions (a "README"). Fresh Eyes follows those instructions
exactly, on a brand-new computer, and tells you plainly whether they work. If they don't, it shows a small fix
and only calls it "fixed" after the fix works twice on fresh computers.

WHO USES IT
- Primary: a first-time, older, non-technical visitor (and hackathon judges, who are busy).
- They should never need to know words like API, hash, container, patch, model, token, CLI.

DESIGN PRINCIPLES (strict)
1. One screen = one question = one main button. Never more than 3 pieces of information above the fold.
2. Plain words only. Use "instructions" not "README", "a fresh computer" not "clean container",
   "fix" not "patch", "check" not "validator". Technical words may appear only inside a collapsed "Show details" area.
3. Big and readable: body text 20px minimum, headings 36–48px, line height 1.6, max line length 60 characters.
4. Huge, obvious buttons: at least 56px tall, full width on phones, a verb on the button ("Start", "See the result").
   Every button and icon has a visible text label. Nothing works only on hover.
5. Show where you are: a simple step indicator "Step 1 of 3" with large numbered circles at the top of each step.
6. Colour is never the only signal: every status has a word and a symbol (✓ Works, ✗ Doesn't work, ! Needs a person).
7. Contrast at least 7:1 for text (WCAG AAA). Generous white space. No dense tables, no small grey text,
   no more than 2 badges anywhere on a screen.
8. Always a way back: a large "← Back" and a "Start again" link; an always-visible "Help" button that opens a
   plain-language explanation with one picture.
9. Calm and friendly, never alarming: failures are explained as "the instructions are missing a step", not errors.

VISUAL STYLE
- Warm, light background (#FAF8F5), white cards with soft shadow, 20px corner radius.
- One accent colour: deep teal #0F6D68 for the main button and links (white text on it).
- Status colours, always paired with a word and a symbol:
  Works = green #1A7A47 on #E2F3E9; Doesn't work = red #B02A3B on #FBE4E7;
  Needs a person = amber #8F5D00 on #FBF0D6; Still running = blue #2C5FB5 on #E6EEFA.
- Typeface: a highly legible humanist sans (Inter, or Noto Sans TC for Chinese). Numbers in tabular figures.
- Simple line illustrations (a person reading a paper checklist, a fresh laptop, a green tick), not photos.
- A friendly logo: a teal circle with a small open eye.
- Provide light theme first; a matching dark theme as a variant.

SCREENS TO DESIGN (desktop 1440px wide AND phone 390px wide for each)

Screen 1 – Welcome (home)
- Big headline: "Do these instructions really work?"
- One sentence below: "We follow a project's instructions on a brand-new computer and tell you, in plain words, if they work."
- ONE large primary button: "Start".
- Under it, one quiet text link: "See a real example first".
- A small illustration on the right (desktop) or above (phone). Nothing else above the fold.
- Below the fold, a 3-step strip with big numbered circles: 1 Choose a project · 2 We try the instructions · 3 You get a clear answer.

Screen 2 – Step 1 of 3: Choose a project
- Question as the headline: "Which project should we check?"
- 3 large selectable cards (radio-card style, whole card clickable, 120px tall), each with the project name in big text,
  one plain sentence, and a status word: "md2html – turns notes into a web page", "mistletoe – turns notes into a web page",
  "json2yaml – changes one data format into another".
- Main button "Continue" (disabled until a card is chosen, with the text "Choose a project to continue").

Screen 3 – Step 2 of 3: What should happen?
- Headline: "This is what the instructions promise".
- Show ONE example as a simple before → after picture: a small note card "# Hello / A **bold** start" → an arrow →
  a rendered card showing the big word "Hello" and the bold word "bold".
- One sentence: "A person checked this example and agreed it's the right result. It is locked so nobody can change it."
- A friendly "✓ Checked by a person" label.
- Main button "Try the instructions".

Screen 4 – Step 3 of 3: Trying… (progress)
- Headline: "We're following the instructions on a fresh computer".
- A large, slow progress indicator with 3 plain stages that tick off one by one:
  "Getting a fresh computer ready" → "Following the instructions" → "Checking the result".
- Reassurance text: "This usually takes about a minute. You can leave this page open."
- No logs, no numbers.

Screen 5 – The answer (one of three states; design all three)
 5a. Works: huge green ✓ and the headline "Yes – the instructions work." One sentence: "We followed them exactly and got the right result."
 5b. Doesn't work, then fixed: red ✗ then green ✓ in a two-step picture. Headline: "The instructions were missing one step – here is the fix."
     Show the fix as a single highlighted line change in big text: "pip install -r requirements.txt" → "pip install ."
     A label that is honest: "Fix written by a person" (our real example was fixed by a person, not by AI).
     One sentence: "We tried the fix on two brand-new computers and it worked both times."
 5c. Needs a person: amber "!" and the headline "We stopped instead of guessing." One sentence:
     "Our AI could see the problem but could not safely fix it, so it asks a person to decide."
- Each answer screen has: a main button "Check another project", a secondary button "Show details" that expands a calm
  panel with the step-by-step timeline, and a small "Download the fix" button only in 5b.
- Inside "Show details" (collapsed by default) you may show: a vertical timeline of steps with ✓/✗, time taken,
  and a short technical note. Keep it to at most 5 rows.

Screen 6 – Real examples (the "See a real example first" link)
- Headline: "Real checks we have run".
- A simple list of 4 large rows, each: project name, one plain sentence, a big status word with symbol, "See it" button.
  Example rows: "md2html – the instructions were missing a step (✗)"; "md2html – fixed by a person and proven twice (✓)";
  "md2html – our AI stopped instead of guessing (!)"; "mistletoe – the instructions already work (✓)".
- No dates, IDs or costs on this screen (they live inside "Show details").

GLOBAL ELEMENTS
- Top bar: logo + "Fresh Eyes" on the left; on the right only two large items: "Help" and a language switch "中文 / English".
- A thin banner when showing recorded examples: "You are looking at a recording of a real check. Nothing new is being run."
- Footer: one line, small but readable: "Made for the Nebius × NVIDIA hackathon. Built with NVIDIA Nemotron on Nebius Token Factory."

COMPONENTS TO CREATE AS A SMALL DESIGN SYSTEM
Primary button, secondary button, text link, selectable project card, step indicator (3 steps), status label
(Works / Doesn't work / Needs a person / Running – each with symbol + word), before→after example card,
one-line "fix" diff card (old line struck through in red, new line in green, large monospace),
progress stages, collapsible "Show details" panel, help drawer, recorded-example banner.
Use auto layout, 8px spacing grid, and name every layer clearly.

DO NOT
- Do not use tables, charts, dense dashboards, more than one primary button per screen, tiny icons without labels,
  carousels, pop-ups that appear on their own, or jargon outside "Show details".
- Do not claim the AI fixed anything: in our real data the only verified fix was written by a person.
```

---

## 給我們的說明（不用貼給 Figma）

- **為什麼這樣設計：** 你要「80 歲第一次用電腦的人也知道怎麼開始」，所以原則是：
  - 每頁只問一個問題、只有一個主要按鈕；
  - 字至少 20px、按鈕至少 56px 高；
  - 所有術語（README、patch、hash、模型、成本）都改成白話，或收進預設收合的「看細節」；
  - 狀態永遠是「符號＋文字」，不只靠顏色；
  - 文字對比至少 7:1（WCAG AAA）。
- **流程：** 歡迎 → 選專案 → 看預期結果 → 執行中 → 答案（三種：能用／缺一步但已修好／停下來請人判斷）。另有「真實範例」頁給評審快速看。
- **內容都照實：** md2html 的修正標「人寫的」；模型那次寫「AI 停下來沒有亂猜」。沒有宣稱 AI 修好了任何東西。
- **和現在網站的關係：** 現在的網站（B22）給開發者和評審看完整證據；這個 Figma 設計是給一般人的「前門」。Figma 出稿後，可以把它做成網站首頁的簡單版本，原本的詳細頁面留在「看細節」後面。這部分等你看過 Figma 的結果再決定，我可以照設計稿把它寫成程式。
- **Figma 連線：** 這個 session 沒有接上 Figma，所以要你自己把上面方框裡的內容貼進 Figma AI。如果你在 claude.ai 的連接器設定裡授權 Figma 並開新 session，我可以直接讀設計稿來實作。
