"""WIN-5 static scan: README says `pip install -r requirements.txt` only, then runs a console-script command
that only exists after installing the package itself. Reads public README/setup files via the GitHub API; never
downloads archives or executes anything."""
import base64, json, re, sys, time, tomllib, urllib.parse, urllib.request

API = "https://api.github.com"
H = {"Accept": "application/vnd.github+json", "User-Agent": "fresh-eyes-win5-static-scan"}


def get(url):
    for _ in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=H), timeout=20) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError as e:
            if e.code == 403:
                time.sleep(20); continue
            if e.code == 404:
                return None
            raise
    return None


def content(repo, path):
    # raw.githubusercontent.com serves public files without the API's 60-an-hour limit.
    try:
        with urllib.request.urlopen(urllib.request.Request(f"https://raw.githubusercontent.com/{repo}/HEAD/{path}", headers=H), timeout=20) as r:
            return r.read(400000).decode("utf-8", "replace")
    except urllib.error.HTTPError:
        return None


def scripts(repo):
    names = {}
    py = content(repo, "pyproject.toml")
    if py:
        try:
            names.update((k, "pyproject.toml") for k in tomllib.loads(py).get("project", {}).get("scripts", {}))
        except tomllib.TOMLDecodeError:
            pass
    st = content(repo, "setup.py")
    if st:
        for m in re.finditer(r"['\"]([A-Za-z0-9_.-]+)\s*=\s*[A-Za-z0-9_.]+:[A-Za-z0-9_]+['\"]", st):
            names[m.group(1)] = "setup.py"
    return names


queries = sys.argv[1:]
seen, out = set(), []
for q in queries:
    res = get(f"{API}/search/repositories?q={urllib.parse.quote(q)}&sort=stars&order=desc&per_page=30") or {}
    time.sleep(7)  # unauthenticated search: 10 requests a minute
    for item in res.get("items", []):
        repo = item["full_name"]
        if repo in seen or item.get("archived") or item.get("fork"):
            continue
        seen.add(repo)
        readme_name = next((n for n in ("README.md", "README.rst", "readme.md", "README") if content(repo, n)), None)
        if not readme_name:
            continue
        readme = content(repo, readme_name)
        readme_meta = {"path": readme_name}
        lines = readme.splitlines()
        req = [i + 1 for i, l in enumerate(lines) if re.search(r"pip3? install -r requirements", l)]
        if not req:
            continue
        installs_pkg = [i + 1 for i, l in enumerate(lines) if re.search(r"pip3? install (-e |--editable )?\.(\s|$|\[)|setup\.py (install|develop)|pip3? install (-U )?[A-Za-z][\w.-]+\s*$", l)]
        cmds = scripts(repo)
        used = {n: [i + 1 for i, l in enumerate(lines) if re.match(rf"\s*(\$\s*)?{re.escape(n)}(\s|$)", l)] for n in cmds}
        used = {n: v for n, v in used.items() if v}
        if used and not installs_pkg:
            out.append({"repo": repo, "stars": item.get("stargazers_count"), "pushed": item.get("pushed_at", "")[:10],
                        "readme": readme_meta["path"], "requirements_lines": req, "commands": {n: {"defined_in": cmds[n], "readme_lines": v} for n, v in used.items()},
                        "description": (item.get("description") or "")[:120]})
            print(json.dumps(out[-1]), flush=True)
print(f"scanned {len(seen)} repositories; {len(out)} match", file=sys.stderr)
