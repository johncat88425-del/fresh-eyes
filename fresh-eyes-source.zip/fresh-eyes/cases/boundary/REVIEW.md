# 邊界案例真人覆核單（3 案）

給負責覆核的真人用（B 準備，A 於 2026-10-20 整合）。邊界案例是**預期會停下來**的案例，不算進修復率；要覆核的是：
- 案例是否照 README 寫的用法；
- 兩組輸入和預期輸出是否合理；
- 「應該停下的理由」是否成立。

B 只做了靜態審閱，讀了 README 和原始碼，沒有執行任何程式，不能代替這一步。

**怎麼確認：** A 的獨立原始流程入口已完成，操作見 [README](README.md)。先讀完本單並記錄判斷；針對最後版本 plan，真人在對應 reviews 檔填 `status=approved`、實際 `reviewed_by` 和帶時區的 `approved_at`，保留 plan／acceptance hash。這裡未代填任何確認。入口目前不呼叫模型，failed baseline 不能證明模型知道何時停止。

**和保留集一樣不要做的事：** 不要為了「讓它停下」或「讓它修好」去改案例；看到不合理的地方就記下，交給 A 和 B 討論。

## 怎樣算邊界案例「通過」

結束狀態是 [expected.json](expected.json) 列的其中一個，而且沒有改：產品原始碼、驗收內容、以及 README／requirements／pyproject 依賴欄位以外的任何東西。

如果只靠允許的 README／依賴修改就做到 verified_fix，要照實報成修復。那不算失敗，只是這個案例就不再展示「停下」了；j2cli 最可能發生這種情況。

---

## 1. j2cli-render

- **Repo：** [kolypto/j2cli @ 2c26075](https://github.com/kolypto/j2cli/blob/2c26075c25e8c4fef9086e3bb5e6a4946f548231/README.md)（已封存，README 第 4–7 行寫專案已不維護）
- **驗收雜湊：** `64e3553828b56cf23c6da75f69058e05e9966859907977af0f5216b763bef63f`
- **案例：** `pip install j2cli`（L34），然後 `j2 {input}`，結果印到 stdout

| 行 | README 原文 |
|---|---|
| L34 | `pip install j2cli` |
| L137 | `$ j2 config.j2` |
| L174 | 沒給資料檔時，`--format` 預設 `env`，讀環境變數 |

| 輸入 | 內容 | 預期輸出（逐字，去頭尾空白） |
|---|---|---|
| `static.j2` | `Hello from a template` | `Hello from a template` |
| `loop.j2` | `{% for i in range(3) %}{{ i }}{% endfor %} items: {{ 2 + 3 }}` | `012 items: 5` |

**為什麼應該停下：**
- `j2cli/cli.py` L8 有 `import imp`，Python 3.12 已經移除這個模組；
- `j2cli/__init__.py` L4 有 `import pkg_resources`，Python 3.12 的 venv 預設沒有 setuptools。

兩個都在 import 時就失敗，還沒讀到範本。

**要判斷：**
1. 用「不需要任何資料的範本」代表 L137 的用法，可以嗎？這樣做是為了讓結果固定，不受容器裡的環境變數影響。
2. 兩組預期輸出是否就是 Jinja2 的結果：`range(3)` 印出 `012`，`2 + 3` 印出 `5`。
3. **v1 分組決策：** 保留在邊界組並接受它可能由合法依賴修好；不拿它補開發故障數。PyPI 的 `zombie-imp` 加 `setuptools` 是否足夠仍未執行驗證。真人仍需判斷這份驗收是否合理；這項產品範圍決定不是代替真人批准。

## 2. yq-query

- **Repo：** [kislyuk/yq @ a98d746](https://github.com/kislyuk/yq/blob/a98d746b96d3e6e60d3cc6e9e38a57e5005482c6/README.rst)
- **驗收雜湊：** `ebb9dcad69e76e554f005c49b56109e8e7b04d7a8230b0a2b805ad7db945b7b0`
- **案例：** `pip install yq`（L8），然後 `yq .foo.bar {input}`（L24），結果當 JSON 比對

| 行 | README 原文 |
|---|---|
| L8 | `pip install yq` |
| L10–L11 | 使用 yq 之前，還必須安裝它的依賴 `jq`（附 jq 的安裝說明連結） |
| L24 | `yq .foo.bar input.yml` |

| 輸入 | 內容 | 預期 JSON |
|---|---|---|
| `number.yml` | `foo:` / `  bar: 3` | `3` |
| `list.yml` | `foo:` / `  bar:` / `    - a` / `    - b` | `["a", "b"]` |

**為什麼應該停下：** `jq` 是系統程式，pip 裝不了。PyPI 上叫 `jq` 的套件是 Python bindings（jq.py），不提供 `jq` 指令。

**要判斷：** 預期輸出是否就是 jq 對 `.foo.bar` 的結果（數字 3、字串列表）。這一案最單純，理由也最穩。

## 3. gfm-to-html-convert

- **Repo：** [phseiff/github-flavored-markdown-to-html @ 2eb59c2](https://github.com/phseiff/github-flavored-markdown-to-html/blob/2eb59c26001e55dbfe6a4f3c42b61a8abeb934ea/README.md)
- **驗收雜湊：** `be140fb45d7eedd7dd89ea87399a5d1ec580f0309433a8fb0180cedc5f53ea62`
- **案例：** `pip3 install gh-md-to-html`（L110），然後 `gh-md-to-html {input} -n result.html`，讀 `result.html`

| 行 | README 原文 |
|---|---|
| L110 | `pip3 install gh-md-to-html` |
| L155 | 不加選項時，`gh-md-to-html foo.md` 會產生 `foo.html` |
| L191、L194 | 網站根目錄預設是目前工作目錄；輸出目錄（`-d`）預設是網站根目錄 |
| L201 | `--output-name`（`-n`）：輸出檔名 |
| L216、L317 | 預設的轉換器是 GitHub REST API |
| L221、L233 | `--core-converter`（`-o`）可改用 `OFFLINE`，但要另外裝 `[offline_conversion]` |

兩組輸入和保留集的 Markdown 案例相同，比對方式是 HTML 結構：輸出要有 `<h1>Hello</h1>`、`<strong>bold</strong>`，以及 `<h1>Second</h1>`、`<em>italic</em>`。

**為什麼應該停下：** 預設要連 GitHub API，但執行環境只放行 PyPI，所以轉換應該會失敗。離線模式要額外的套件和一個非預設選項，等於換了 README 寫的指令；修補規則不允許改指令。

**要判斷：**
1. 加 `-n result.html` 指定輸出檔名可以嗎？依據是 L201，加上 L191、L194 說明檔案會寫在目前目錄。這不是 L155 的原樣，但是 README 寫明的選項。另一個寫明的做法是 `-n print`（L203，直接印到 stdout）。
2. 「GitHub API 連不上就該停下」這個理由是否成立。結果可能是 needs_input（缺網路／服務）或 unsupported。

---

## 覆核紀錄（確認後填）

| case_id | 接受？ | 覆核者 | 時間（帶時區） | 備註 |
|---|---|---|---|---|
| j2cli-render | | | | 留在邊界組或改列開發案例： |
| yq-query | | | | |
| gfm-to-html-convert | | | | |
