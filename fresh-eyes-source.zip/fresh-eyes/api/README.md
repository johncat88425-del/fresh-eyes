# Teammate API — first backend handoff

This local API uses Python 3.12+ and the standard library. No package installation, Docker, model key or paid service is needed to build the frontend against it.

20 Oct: a separately owner-armed [single-use development model plan](MODEL_API.md) now supports `repair_mode: model`. Attaching a plan alone never enables it. Defaults below still keep models off; the new path has HTTP/browser engineering checks, not a new real model result.

Version 0.2.1 fixes --allow-origin to preserve the default frontend origins. It also includes the missing needs_input example (ten total), fixes the original-command timeline, closes every SQLite connection, and adds opt-in controlled PyPI execution. See [B's integration update](BACKEND_UPDATE.md) and [dependency modes and pending validation](DEPENDENCY_MODES.md). Restart the old API; `/api/health` must show `api_version: "0.2.1"`.

From this repository:

```sh
python3.12 scripts/fresh-eyes serve
```

Open [API health](http://127.0.0.1:8765/api/health), [registered cases](http://127.0.0.1:8765/api/cases), [labelled UI examples](http://127.0.0.1:8765/api/examples), or [OpenAPI](http://127.0.0.1:8765/api/openapi.json). The server binds only to `127.0.0.1`. It does not load `.env`, call model APIs, search, download or run arbitrary repositories.

The default frontend origins are `http://localhost:5173`, `http://127.0.0.1:5173`, `http://localhost:3000` and `http://127.0.0.1:3000`. Extra origins extend this default list; they do not replace it. Repeat --allow-origin to add more. For a different port, pass the exact origin:

```sh
python3.12 scripts/fresh-eyes serve --allow-origin http://localhost:8080
```

Contracts are loaded at startup. Restart after adding case files; the integrated B delivery has three development cases. Frozen cases/holdout contracts are excluded. Verify their integrity with scripts/fresh-eyes verify-holdout; this does not execute or approve them. See [B integration status](AFTER_B_HANDOFF.md).

## Routes

| Method / path | Purpose |
|---|---|
| `GET /api/health` | Capabilities, execution switch, London timezone and optional public single-use-plan summary; paid calls default off |
| `GET /api/cases` | Real pinned contracts, goal, fixtures/expected values and acceptance hash |
| `POST /api/cases/{case_id}/approval` | Record a person's review against the current acceptance hash |
| `POST /api/runs` | Queue an enabled, registered functional case; returns HTTP 202 |
| `GET /api/runs` | Real run summaries only, newest first, up to 100 |
| `GET /api/runs/{run_id}` | Real persisted progress and evidence |
| `GET /api/runs/{run_id}/patch` | Actual diff, or HTTP 404 if no patch exists |
| `GET /api/examples` | Static, explicitly labelled examples for UI work; never real history |
| `GET /api/examples/{name}` | A single static example |
| `GET /api/openapi.json` | Versioned interface contract |

## Frontend integration

```js
const base = 'http://127.0.0.1:8765';
const { items: cases } = await fetch(`${base}/api/cases`).then(r => r.json());
const { items: examples } = await fetch(`${base}/api/examples`).then(r => r.json());
// examples['verified-fix'] is EXAMPLE data, not a real model or runner result.
```

Use examples to implement loading, success, startup-only, unresolved, unsupported and infrastructure-error views before the runner is ready. Keep an **Example / not executed** badge whenever `data_origin === 'example'`. Do not merge examples into real `/api/runs` history or evaluation metrics.

Render untrusted README/log/diff/output with `textContent` or framework escaping, never raw HTML. Render `run_state` separately from `result_status`. A completed job may have failed its workflow. `startup_only` is not functional success. Unknown costs are `null`, not zero; record zero only when no calls occurred. Engineering test doubles remain separately labelled and never count as real repairs.

Poll `GET /api/runs/{id}` every 1–2 seconds while `run_state` is `queued` or `running`; stop on `completed` or `failed`. Persisted runs survive API restarts. Incomplete jobs become `failed` / `infrastructure_error`, with an interruption reason; the API does not silently rerun them.

All stored timestamps are UTC ISO strings. Display in `Europe/London`, including BST/GMT, with `Intl.DateTimeFormat` or the frontend equivalent. See the [OpenAPI schema](openapi.json) and the examples for field shapes.

## Human review

Show a case's goal, environment, both inputs and expected outputs before offering confirmation. The person enters their own name. Send that name with the exact current hash:

```json
{
  "reviewed_by": "<name of the person who actually reviewed the fixtures>",
  "acceptance_sha256": "<hash returned by GET /api/cases>"
}
```

POST to `/api/cases/{case_id}/approval`. A stale hash receives 409. Approval belongs to this exact acceptance version, is persisted locally and is team review, not upstream maintainer approval. No fixture-editing endpoint is exposed yet; a goal/fixture change requires a new reviewed contract.

## Real local execution — backend owner only

Execution is disabled by default, so the frontend teammate can start independently. On the prepared development machine, enable the reviewed-case runner explicitly:

```sh
python3.12 scripts/fresh-eyes serve \
  --enable-runner --development \
  --docker scripts/docker-local \
  --source-root ../../work/candidates \
  --wheelhouse ../../work/wheelhouse
```

This requires an already available local Docker engine, matching Linux arm64 Python image, the pinned checkouts, and prepared offline wheels. The existing reviewed development cases are allowed by `--development` and remain labelled as development review; this flag does not invent a human approval. Without the flag, complete actual acceptance review first.

The command above uses `offline_snapshot` for development/replay, which cannot observe newly released packages. Formal evaluation uses `pypi_live` with `--enable-live-pypi` after real network validation. Live mode has no wheelhouse requirement or offline/cache fallback. The real local arm64 PyPI egress/cleanup gate passed on 20 Oct; all three development repos have live execution evidence. Nightly scheduling is outside v1.

Submit a baseline:

```sh
curl -sS http://127.0.0.1:8765/api/runs \
  -H 'Content-Type: application/json' \
  -d '{"case_id":"mistletoe-markdown","verification_level":"functional","repair_mode":"none"}'
```

The prepared manual candidate is available only for `md2html-markdown`; request `"repair_mode":"manual_candidate"`. It is not AI repair. A candidate diff is downloadable even when not verified; check `result_status` before labelling it a verified fix. HTTP 202 only means queued. An unavailable Docker engine must finish as `infrastructure_error`, without claiming a repo failure or success.

## Error response and current limits

Errors use `{"error":{"code":"...","message":"..."}}`:

| HTTP | Example code | UI response |
|---|---|---|
| 400 | `invalid_json`, `case_required`, `invalid_level`, `unknown_fields` | Show request/field error |
| 403 | `origin_not_allowed`, `invalid_host` | Correct local frontend/server origin |
| 403 | `live_pypi_disabled` | The backend owner must explicitly enable live package access |
| 404 | `case_not_found`, `run_not_found`, `patch_unavailable` | Show unavailable item, not empty success |
| 409 | `needs_review`, `acceptance_changed`, `source_mismatch`, `candidate_unavailable` | Explain what must be reviewed or selected |
| 429 | `queue_full` | Wait; one worker, at most four pending/active jobs |
| 501 | `startup_not_implemented` | Explain arbitrary-repo startup is not available yet |
| 503 | `runner_disabled`, `assets_unavailable`, `source_unavailable` | Keep UI/examples usable; backend setup required |

This is a loopback development server. Arbitrary repo startup, Sandboxes execution and nightly scheduling are outside v1. Nano/Ultra repair exists in the CLI and the owner-pinned single-use API; no real Web model run has been performed. The current real model evidence is two CLI development trials, both needs_review. See [current handoff](READY_THROUGH_1022.md); private credentials and runtime assets are excluded from source packages.
