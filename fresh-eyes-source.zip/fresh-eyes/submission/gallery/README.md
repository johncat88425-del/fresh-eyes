# Devpost 圖庫

B 準備（2026-10-20）。截圖都來自唯讀展示頁的真實紀錄（英文介面），用 headless Chrome 產生；封面和片尾字卡來自 `card.html`。

| 檔案 | 用途 | 英文說明（可直接貼到 Devpost） |
|---|---|---|
| `cover.png`（1500×1000） | Devpost 縮圖 | — |
| `1-overview.png` | 圖庫 | Read-only demo: recorded execution evidence is separate from labelled synthetic state examples. |
| `2-readme-fails.png` | 圖庫 | md2html run exactly as its README says: the install succeeds, but the md2html command never exists, so both inputs fail. |
| `3-verified-fix.png` | 圖庫 | A one-line README fix passes in a fresh container and again in an independent clean re-run. This fix was written by hand, not by a model. |
| `4-two-rounds-stop.png` | 圖庫 | Nemotron on the same failure: round 1's edit doesn't match the README and is refused; in round 2 Ultra declines to guess. Nothing is applied. |
| `5-locked-check.png` | 圖庫 | The acceptance check: README lines, two inputs and expected outputs, approved once by a person and locked by hash. |
| `6-start-here.png` | 圖庫 | Where everyone starts: one question and one big button. No jargon until you ask for the details. |
| `7-plain-answer.png` | 圖庫 | The same verified fix as a plain answer: what was missing, the one changed line, and who wrote the fix. |
| `8-nemotron-fix.png` | 圖庫（先前保存候選） | A README fix written by Nemotron: Nano classified the failure, Tavily found the project's docs, Ultra proposed a line-anchored patch, and the unchanged patch passed in two fresh environments. Its first trial was interrupted by our own runner, so the same patch was re-checked with no new model call. |
| `9-nemotron-fix-plain-disclosure.jpg` | 圖庫 | The newcomer answer discloses the original interruption and links its unchanged saved AI proposal. |
| `10-uninterrupted-ai-fix.jpg` | 圖庫（建議第一張） | A new uninterrupted real run: the original README failed, Nano classified the failure, Ultra proposed a README repair, and the patch passed both a fresh acceptance run and an independent clean re-run. Two model calls; usage estimate US$0.00546874, billing unreconciled. |
| `endcard.png`（1920×1080） | 影片片尾字卡 | — |

說明照實寫：第 3 張是人工修正，第 4 張是沒有修好、選擇停下。第 8、9 張是已保存 AI 候選的分開驗證，不是不中斷的端到端成功；正式評估仍未跑。

第 10 張是 A 實際擷取的新 `5c225204bcd946228a7ef4700c8c0c8c` 成功紀錄；與第 8、9 張分開。新試跑沒有 Tavily 呼叫，修好的仍是同一個 md2html 專案，不能算第二個不同專案。

## 重新產生

先在一個分頁啟動展示頁（子路徑和 GitHub Pages 一樣）：

```bash
cd ~/Desktop/fresh-eyes && python3.12 web/demo/build.py --replace && mkdir -p /tmp/fe-pages && rm -rf /tmp/fe-pages/fresh-eyes && cp -R dist/demo /tmp/fe-pages/fresh-eyes && python3 -m http.server 3003 --bind 127.0.0.1 --directory /tmp/fe-pages
```

再開另一個分頁產生圖片（用暫時的 Chrome 設定檔，不會碰到你的 Chrome）：

```bash
cd ~/Desktop/fresh-eyes && bash submission/gallery/shoot.sh
```

有公開網址之後，片尾字卡可以把連結加上去：

```bash
cd ~/Desktop/fresh-eyes && REPO=https://github.com/帳號/repo DEMO=https://帳號.github.io/repo/ bash submission/gallery/shoot.sh
```

A 核對：第 9 張原 PNG 截於中斷說明加入前，原件留存；新 JPG 已由整合版實際擷取，顯示揭露和原試跑連結，投稿請選新 JPG。
