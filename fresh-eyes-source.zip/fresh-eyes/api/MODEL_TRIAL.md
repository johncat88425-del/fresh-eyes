# 開發案例模型試跑

> 10/20 新增：[已完成的真實兩輪結果](MODEL_TRIAL_RESULT_20261020.md)。4 次呼叫、usage 計算 US$0.01362438，needs_review；授權 consumed，沒有重試。以下計畫／啟用說明仍適用未來的新授權。

這是 A 調整 md2html 等開發案例的入口，和保留集正式評估分開。只接受 cases/ 直層登記的案例及 approvals-export 已有的真人確認；不接受 cases/holdout，不建立或更改確認。結果固定 evaluation_eligible=false，不能改標成 A／B／C／D 成績。

最新工程測試數見 TEAM_TASKS。新入口以自有合成 repo 和假模型測過；真實 md2html 已完成一次兩輪試跑，結果 needs_review；之後的證據截取修正只經離線驗證，沒有再啟用模型。唯一真實 verified_fix 仍是人工候選。[單次開發 API](MODEL_API.md)另有工程驗證；付費預設關閉。

## 先產生可檢查的計畫

從持有真人確認的 API 資料目錄匯出記錄，只讀資料、不新增確認：

```sh
python3.12 scripts/fresh-eyes approvals-export --output /你的工作目錄/team-approvals.json
```

公開模型配置沿用 evaluation-freeze 的 Nano／Ultra ModelSpec 欄位，不能含 key。準備明確的 runner image ID、pinned Git 來源、模式和新輸出目錄後：

```sh
python3.12 scripts/fresh-eyes model-trial-plan \
  --case-id md2html-markdown \
  --approvals /你的工作目錄/team-approvals.json \
  --source /你的原始碼目錄/md2html \
  --model-config /你的工作目錄/public-models.json \
  --runner-id 'sha256:實際64位image雜湊' \
  --dependency-mode pypi_live \
  --route nano_ultra --max-patch-rounds 1 \
  --budget-usd 0 --time-limit-s 600 \
  --docker scripts/docker-local \
  --output-root reports/model-trial-md2html-new \
  --output /你的工作目錄/trial-plan.json
```

這只查本機 HEAD、公開配置及驗收記錄，保存 code、review、模型及 artifacts 的 hash；不連 Docker、不讀 .env、不查 catalog、不執行 repo。預算預設 0，不能付費執行。offline_snapshot 另帶 --wheelhouse；pypi_live 不接受 wheelhouse。

預覽保存的計畫：

```sh
python3.12 scripts/fresh-eyes model-trial-run --plan /你的工作目錄/trial-plan.json
```

即使傳 env-file，沒有 --execute 仍不讀 key。計畫必須存到試跑輸出目錄之外；舊計畫／輸出都不覆蓋、不續跑。程式、review、wheels 或配置改變後要建立新計畫。

## 新授權後才執行

原 US$0.02 單輪授權已完成。另有這次的明確金額與輪數後，建立相符的正額度計畫，才在預覽命令追加以下參數。本次授權已執行並結束，下一次仍須新的明確授權：

```text
--execute --enable-paid-models
--env-file .env
--tokenizer-references /已核對的本機tokenizer目錄
```

一輪最多 2 個模型請求，兩輪最多 4 個；同一試跑共用預算及 deadline，沒有 retry 或 fallback。計畫不是財務授權，也不是 Nebius 帳戶層限額。

原始功能先試跑；本來健康或 runtime 不可用時，不啟動模型、不讀 key。只有原始功能失敗才載入指定 env、驗證 tokenizer 和當時 catalog，再依保存的模型 ID、容量及費率建立持久帳本。catalog 不符、未知費用、預算或時間不足會停止，不自動再開試跑。deadline 是控制端限制，runtime 準備／清理可能超時。

key_read=false 代表未進入金鑰啟用；啟用途中出錯則記 null，不能確知是否已讀。Ctrl+C 保留 interrupted binding 和已建立的 ledger，不捏造最終結果。

## 輸出與交接

- report.json／report.html：原始、每輪候選及獨立重跑證據；被拒的候選全文保留在 repair_rounds。
- run-record.json：前端欄位的本機 engine 紀錄，api_persisted=false，不寫進正式 API 歷史。回放時明示來源。
- trial-plan.json／trial-binding.json：開發範圍、計畫 hash、identity、狀態與報告 hash。
- model-ledger.json：啟動過 planner 才產生，usage 計算額與未對帳扣款分開。
- private-ledger.sqlite3：本機持久帳本，不進報告 ZIP。
- report-package.zip：完整結束後自動產生，附 manifest 和相對連結檢查；解壓整包，雙擊 OPEN_REPORTS.html。不含 .env、SQLite、wheels 或第三方 checkout。

合成測試標 engineering_test，不能報成產品成果。實際扣款及本機 runner 未知費用保持 null。B 的逐輪時間軸已整合；本機 API 路徑另見 MODEL_API.md。

本機零預算預覽的公開核對摘要見 [readiness](../evidence/model-trial-readiness-20261020.json)。模型配置來自 10/19 保存的 catalog，本輪未重查價格，未宣稱目前仍相同。
