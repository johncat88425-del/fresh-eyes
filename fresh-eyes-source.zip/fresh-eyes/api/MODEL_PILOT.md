# Nano → Ultra 首次真實單輪：needs_review

2026-10-19。Run ID：e5150fecaff34918af941bfca2ad5161。這是核心 engine 的獨立開發試跑，沒有匯入 Web API 的 SQLite 歷史。

**兩個模型都成功回覆，但候選被拒絕，沒有 AI 修復成功。** 原始 README 的安裝通過，兩組 workflow 均因找不到 CLI 而失敗。Nano 分類 documentation；Ultra 也指出只安裝 dependencies、沒有安裝專案本身。候選未能在原檔中唯一精確匹配，程式回報 needs_review，未套用變更，也沒有候選／最終容器驗收。

- [原始完整 HTML 報告](../reports/model-pilot-20261019-once/report.html)
- [用量與費用帳本 JSON](../reports/model-pilot-20261019-once/model-ledger.json)
- [啟用前檢查](../reports/model-pilot-20261019-once/preflight.json)
- [單輪授權範圍](../reports/model-pilot-20261019-once/authorization.json)

| 階段 | 官方模型 ID | prompt tokens | completion tokens | 依 usage 計算 USD |
|---|---|---:|---:|---:|
| 分類 | nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B | 3,133 | 547 | 0.00031926 |
| 診斷 | nvidia/Nemotron-3-Ultra-550b-a55b | 3,186 | 1,033 | 0.006285 |
| 合計 | 2 次真實呼叫 | | | **0.00660426** |

上限為 Chris 批准的 US$0.02；沒有重試、模型 fallback 或全 Ultra 對照。價格取自當次官方 catalog；費用為 calculated_usd，帳戶實際扣款 billed_usd 尚未對帳，保持 null。Ultra 的 802 reasoning tokens 已包含在 completion tokens，沒有重複計費。實際 prompt tokens 均低於各自請求保留上界；見 [預算方法與限制](PROMPT_BUDGET.md)。

## 這輪暴露的問題與已完成的補強

本次程式只保留診斷說明，沒有保留被拒絕候選的完整 edits，所以不能確定具體哪段 old 字串不符。沒有用人工 patch 補造這份模型結果，也沒有回寫原始 engine 報告。

後續程式已補上 candidate_patch 快照與 proposed／rejected／accepted_for_validation 狀態；比對錯誤會指出檔案及匹配次數。工程測試確認拒絕時仍保留原始失敗證據、候選內容，且不修改來源、不建立已套用的 patch。這些補強尚未再花錢重測，不能說本次模型候選已通過。

執行仍是固定 md2html commit、Linux arm64、受控即時 PyPI、development_reviewed；沒有建立真人 approval、執行保留集、觀察到依賴漂移或啟用一般 Web 付費入口。此次單一 baseline 容器及網路資源已清除。

## B 現在可做

可把這份真實 needs_review 紀錄加入報告 QA，確認「兩模型有回覆」和「修補未通過」能同時正確顯示。若使用錄製 JSON，標示真實紀錄回放；不要灌進正式評估，也不要把先前人工 verified_fix 配成 Ultra 修補成功。原先評估頁四項修正與真人覆核工作繼續進行。
