# Beginner front door: clickable prototype (B27)

The design in [submission/FIGMA_PROMPT.md](../../submission/FIGMA_PROMPT.md) as plain HTML, one file per screen. Built for the test "an 80-year-old using a computer for the first time knows what to press first". Open [index.html](index.html) (double-click works, no server needed) to see every screen.

| File | Screen |
|---|---|
| `01-welcome.html` | One question, one big **Start** button, a quiet "See a real example first" link |
| `02-choose.html` | Step 1 of 3: three big project cards; **Continue** waits for a choice |
| `03-promise-{md2html,mistletoe,json2yaml}.html` | Step 2 of 3: the locked example as before → after, "Checked by a person" |
| `04-trying.html?case=…` | Step 3 of 3: three stages tick off. **A demonstration** (yellow banner says so), then it links to that project's real answer |
| `05a-works.html`, `05a-works-json2yaml.html` | Answer: ✓ works |
| `05b-fixed.html` | Answer: ✗ → ✓, the one-line fix, "Fix written by a person", **Download the fix** (`md2html-fix.patch`, the real diff) |
| `05c-needs-person.html` | Answer: ! the AI stopped instead of guessing (the real two-round Nemotron run) |
| `05d-doesnt-work.html` | Answer: ✗ doesn't work as written |
| `06-examples.html` | Five real checks, no dates, IDs or costs |
| `07-help.html` | Help as a page; the same text opens as a dialog from **Help** on every page |
| `08-components.html` | Buttons, status labels, step indicator, project card, fix card, progress, details |

- **Content is real:** every answer is a recorded development run from `web/demo/recordings` (runs `a7bf8fc4`, `9a4e3a87`, `563db906`, `e9a04f64`, `10175eee`). The only fix that worked was written by a person, and the pages say so. "Show details" links to the full report in the detailed site on `localhost:5173`.
- **Rules kept:**
  - text at least 18px (body 20px), buttons at least 56px tall (main ones 64px);
  - every status is a symbol plus a word;
  - text contrast at least 7:1 in light and dark (computed for every colour pair);
  - focus outline 4px;
  - Help is a native dialog: Escape closes it and focus goes back to the Help button;
  - the progress page announces each stage to screen readers and honours reduced motion.
- **Languages:** both are in each page; the 中文 / English button switches and remembers the choice. `?lang=en` in a link also sticks for the next pages.
- **Checked (2026-10-21, browser pane):** every page at 320 px and 375 px wide, in both languages and with every "Show details" open, has no sideways scrolling. The whole click path was tested, along with dark mode and the Help dialog. Not checked: Safari, real phones, a screen reader.
- **Edit text in `make_pages.py`**, then run `python3 design/beginner/make_pages.py`; don't hand-edit the HTML. Styles are in `style.css`, behaviour in `fe.js`.
- **Built into the site (B24, 2026-10-21):** `#/`, `#/start`, `#/start/{case}`, `#/answer/{run}`, `#/examples`; the old overview is now `#/dashboard`. See [web/README.md](../../web/README.md#beginner-front-door-b24-2026-10-21).
