#!/usr/bin/env bash
# Regenerate the Devpost gallery from the read-only demo served at http://127.0.0.1:3003/fresh-eyes/
# (see README.md). Uses a throwaway Chrome profile; optional REPO / DEMO add links to the end card.
set -euo pipefail
cd "$(dirname "$0")"
CH="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
PROFILE="$(mktemp -d)"
trap 'rm -rf "$PROFILE"' EXIT
BASE="http://127.0.0.1:3003/fresh-eyes/?lang=en"
shot() {  # name, width,height, url
  "$CH" --headless=new --disable-gpu --hide-scrollbars --no-first-run --user-data-dir="$PROFILE" \
    --window-size="$2" --virtual-time-budget=6000 --screenshot="$1.png" "$3" >/dev/null 2>&1
  echo "$1.png"
}
curl -sf -o /dev/null "http://127.0.0.1:3003/fresh-eyes/data/health.json" || { echo "Start the demo server on 3003 first (see README.md)." >&2; exit 1; }
shot 1-overview 1440,900 "$BASE#/dashboard"  # #/ is the beginner welcome since B24
shot 2-readme-fails 1440,1500 "$BASE#/runs/10175eee750c464fa7ce86ad4c84f037"
shot 3-verified-fix 1440,2000 "$BASE#/runs/563db9062b7b4e48a4490e41b6792ff6"
shot 4-two-rounds-stop 1440,2600 "$BASE#/runs/e9a04f641acb4c71b7ff0932e58f87e8"
shot 5-locked-check 1440,1300 "$BASE#/cases/md2html-markdown"
shot 6-start-here 1440,900 "$BASE#/"
shot 7-plain-answer 1440,1400 "$BASE#/answer/563db9062b7b4e48a4490e41b6792ff6"
shot 8-nemotron-fix 1440,2400 "$BASE#/runs/5ac511039adb4977b32ef129e86ee006"   # verified 24 Oct; run must exist in the build
shot 9-nemotron-fix-plain 1440,1300 "$BASE#/answer/5ac511039adb4977b32ef129e86ee006"
LINKS=""
[ -n "${REPO:-}" ] && LINKS="$LINKS&repo=$REPO"
[ -n "${DEMO:-}" ] && LINKS="$LINKS&demo=$DEMO"
shot cover 1500,1000 "file://$PWD/card.html?kind=cover"
shot endcard 1920,1080 "file://$PWD/card.html?kind=end$LINKS"
