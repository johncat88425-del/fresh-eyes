# 本機真實試跑：兩個開發案例

> 2026-10-19。Linux arm64、離線 snapshot、開發審閱模式。不是正式保留評估，也不是 AI 修復成果。

> 後續狀態：VM 與本次臨時前端／API 程序目前已停止。下列報告及資料包仍可離線閱讀；localhost 預覽需恢復程序後才可用。後續 VM 已恢復，新的即時 PyPI 結果見 [LIVE_PILOT.md](LIVE_PILOT.md)；本文件保留原離線紀錄。

VM 已由 Chris 手動恢復。實測 rootless Docker 29.9.1 可連線，guest 沒有主機目錄掛載。付費模型、Tavily、Sandboxes 操作保持關閉。

## 結果

| API run ID | 案例／方式 | 結論 | 證據 |
|---|---|---|---|
| `7d80fd8fc98746629b48d4b3d721c51d` | mistletoe，原始 README | `already_passes`，兩組輸出通過 | [HTML](../reports/local-pilot-20261019-7bc2f968/state/reports/7d80fd8fc98746629b48d4b3d721c51d/report.html) |
| `c2dd01c4d9194bfca08a2911e75c8c74` | md2html，原始 README | `unresolved`，requirements 安裝成功，但 CLI 不存在 | [HTML](../reports/local-pilot-20261019-7bc2f968/state/reports/c2dd01c4d9194bfca08a2911e75c8c74/report.html) |
| `f9875e507dc3428684759e98570e0872` | md2html，人工候選 patch | `verified_fix`；原始失敗，候選及最終獨立重跑通過 | [HTML](../reports/local-pilot-20261019-7bc2f968/state/reports/f9875e507dc3428684759e98570e0872/report.html)、[實際 diff](../reports/local-pilot-20261019-7bc2f968/md2html-manual-candidate.diff) |

md2html 僅修改 README 安裝指令：`pip install -r requirements.txt` → `pip install .`。產品原始碼、驗收輸入／預期值／比對方式都沒有改。

- mistletoe commit：`ebf9ae4e9279f3d8c79b7cf2710f7e73ea6438a7`。
- md2html commit：`e0175df5d2144f671435ff32b5d5e9a7d9f8bc86`。
- 五次 attempt 使用五個不同的乾淨容器，全部 `network: none`，同一 base image：`sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1`。
- 每次保存 venv／pip／工作目錄執行檢查、pip install report、freeze、功能輸出與驗收結論；候選與最終重跑的兩組功能輸出皆通過。
- 已核對 contract／acceptance hash 未改，完成後沒有留下 `fresh-eyes` 容器。[一致性檢查](../reports/local-pilot-20261019-7bc2f968/evidence-audit.json)。
- 經真實 API 提交並在 B 前端查看，原始／候選／最終時間軸、人工 patch 與未知 runner 費用均可顯示；實際 patch 端點內容與 engine 報告一致。
- 模型呼叫 0，模型費用 $0；本機運算未計價，`runner_usd: null`。沒有建立真人 approval，仍為 `development_reviewed`。

原始報告中的 engine run ID 與 API 任務 ID 分開產生；請以表格的 API ID 查 API，資料包保留兩者的對照。

## 本輪修正與首輪排除

首輪 Docker 的 `/work` tmpfs 隱含 `noexec`，導致已安裝的 CLI 回報權限錯誤。Runner 現在明確使用 `exec,nosuid,nodev`，並在執行 repo 安裝前驗證工作目錄可執行；其餘非 root、唯讀 root filesystem、無網路與資源上限保留。111 個工程測試通過，修正後重新執行上表三筆任務。

受影響的首輪紀錄完整保留於 `reports/local-pilot-20261019-09562964`，另有 `environment-diagnosis.json`，明確排除於 README 故障／修復成績；沒有覆寫成新的成功結果。

## 可以交給 B 的資料

歷史內部 ZIP 是 `dist/fresh-eyes-real-pilot-2026-10-19.zip`，不作為公開下載連結。公開 source ZIP 已附上本頁連結的安全報告與 [可重建回放](../web/demo/README.md)，包含三筆 API JSON、HTML／JSON engine 報告、實際 diff、只讀 API snapshots 與 hash manifest；不含 SQLite、key、第三方 checkout、wheelhouse 或 VM。資料可離線閱讀，不是 API 匯入檔。

本機目前的 [前端](http://127.0.0.1:52631/?api=http://127.0.0.1:52632)／[API health](http://127.0.0.1:52632/api/health) 僅在這台電腦且程序運行時可用。另一台電腦請用資料包，localhost 連結不能跨機使用。

## 還沒有證明的事

真人覆核、即時 PyPI 出站政策、依賴漂移、正式 amd64／保留集評估、AI 診斷與修補、Sandboxes 執行、任意 repo 安裝／啟動、每晚排程。兩個開發 repo 不能外推成普遍修復率。
