> **10/24 最新狀態：既有 VM 已恢復，平台 v2 gate 通過。** 固定 image 為 sha256:a0f57064cbdcd6285fa45f51237ab0b35ea8ebaed06a1f5973e89e19dfb86704；真實 startup／boundary／人工修補重驗已有新紀錄。以下缺 socket 的內容是過往故障紀錄。

# 真實執行環境恢復與 10/19 關卡

> 2026-10-19 更新：Chris 已重新啟動既有 VM，Docker 29.9.1 可連線；實際出站 gate、live-PyPI 試跑與隔離 wheels 建置完成。見 [本輪證據](api/LIVE_PILOT.md)。以下指令留供日後啟停，不需現在重建。

10/20 晚間補記：目前 socket 再次消失；工具沙盒不能讀取 boot-session sysctl，最新 Linux v3 停在前置。以下 10/19 成功是歷史紀錄，不代表現在可執行。其他電腦請自行準備 Docker，使用 README 的明確 --docker 路徑；此啟動腳本需要 Chris 工作區已準備的工具，並非通用安裝器。

## 1. 目前可確認的狀態

先前 VM 暫存狀態遺失，工具沙盒也無法自行讀取開機識別資訊。Chris 手動恢復後，現已實際連上永久目錄的 Docker socket；guest 初始化完成、Docker 運行中、沒有主機目錄掛載。首次試跑揭露工作目錄 noexec 問題，已修正並重跑；受影響的首輪報告另行保留及排除。

新的啟動腳本預設把新 VM 放在 **`~/.local/share/fresh-eyes/lima`**；永久路徑記錄在工作區 `work/runtime/lima-home.txt`。若舊位置有完整或部分 instance，會保留它並沿用／要求檢查，不會自動搬移、刪除磁碟或覆蓋既有設定。

## 2. 後端負責人手動恢復

先切換到 fresh-eyes 專案根目錄，再於已準備 Lima／Docker 工具的 Mac 一般 Terminal 執行：

```sh
python3.12 scripts/start-local-runtime.py
```

新 VM 使用 2 CPU、2 GiB RAM、12 GiB 磁碟，不掛載主機目錄，可能需要重新下載映像。這是本機執行，不使用 Nebius 餘額。原暫存 VM 若仍在，腳本會優先保留，不為了換路徑重建它。

完成後在專案目錄執行：

```sh
python3.12 scripts/fresh-eyes doctor --docker scripts/docker-local
```

必須實際看到 Docker server 可連線，再跑開發案例。看到 `Runtime ready` 只代表初始化完成，仍需確認一次 doctor 和真實案例報告。若一般 Terminal 也失敗，保存錯誤；不刪磁碟、不加權限旗標繞過系統邊界。

## 3. 兩條環境路線一起處理

| 路線 | 負責人 | 完成條件 |
|---|---|---|
| 本機 Lima／Docker | 你在一般 Terminal 恢復，後端接續驗證 | doctor 成功，至少一個固定案例在新環境產生實際功能輸出 |
| Token Factory Sandboxes | 後端於 10/19 優先確認 | 帳號確實開通、計費／額度已知、快照／分支／清除／網路能力實測；只拿到推論 key 不算已開通 |

不能把兩條都未確認的狀態當成「環境沒問題，明天再跑」。10/19 半天關卡結束前，至少要有一個可執行真實 repo 的環境；沒有就如實記為展示阻礙，繼續做不需執行的產品工作。

Sandboxes 尚未整合，付費呼叫仍關閉。Docker 的 proxy／network 設定不會自動適用於 Sandboxes；若採用後者，要依它的實際出站政策另做相同驗證。

## 4. 正式評估與每晚檢查的網路關卡

依 [依賴模式說明](api/DEPENDENCY_MODES.md)，使用 `pypi_live`。驗收至少包含：

- 從乾淨環境按原 README 成功連到 PyPI，取得當時符合限制的版本；沒有拿離線 wheelhouse 或舊 cache 補答案。
- 執行環境直接連外失敗；經代理連到允許的 PyPI HTTPS 端點成功。
- 經代理連其他網域、metadata、內網與 loopback 目的地失敗；取消與超時能清除 worker、proxy、network 和暫存映像。
- 保存實際版本、可取得的 pip 安裝報告／hash、結果與時間；下載／代理故障與 repo 功能失敗分開處理。
- 至少一次乾淨原始流程與一次最終驗證有真實紀錄。要聲稱觀察到依賴漂移，還需要兩次實際安裝差異與對應功能結果，不能只憑模式已實作。

離線真實試跑已取得人工 README 修補與獨立重跑的證據；**本節的本機即時 PyPI 出站 gate、live 原始及獨立最終重跑已完成；仍沒有夜間依賴漂移成果**。採樣目的地與中斷清除的範圍見 EGRESS_GATE，不能外推成任意平台／協定。
