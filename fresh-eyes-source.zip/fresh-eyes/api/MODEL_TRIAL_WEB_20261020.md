# Latest development model trials

These are development records, not holdout evaluation. No AI-generated patch has
passed verification. The md2html defect is an omitted package-install step; no
dependency drift has been demonstrated.

| Version | Engine run | Real calls | Outcome | Calculated USD |
|---|---|---|---|---|
| Web v1 | 402356b03f1d4b65acaf27f5065bc11f | 1 Nano | needs_review; classification incorrectly suggested infrastructure | 0.00020862 |
| Classification v2 | 87b1fce1dc82492cb7d0daac7157a39b | 1 Nano | documentation correctly identified; Ultra reservation rejected before dispatch | 0.00034056 |
| Bounded v3 | 34f03a385a8a4eb8b719e0a2fadb14ad | 1 Nano + 1 Ultra | unresolved / incomplete_output; Ultra used its 1536-token completion cap entirely for reasoning and returned no complete JSON candidate | 0.00693330 |

The newly authorized development work used **4 calls / US$0.00748248** in total,
below the US$0.015 cap. The request-count limit is exhausted; remaining monetary
capacity is not permission for more calls. No retries or fallback were used.
Paid execution is off. Per-run actual billed amounts remain unknown.

Web v1 was genuinely submitted through the frontend on an isolated API state
directory. Its API job ID is e4bef3c4d2b246b19944ad3fc149a84e; the engine ID differs
as shown above. Only previously attributed acceptance approvals were imported;
no human approval was invented.

Before v3, the planner gained explicit classification definitions, shorter
successful installer logs and compact JSON. Cited installation/usage lines remain
prioritized, errors remain visible, and raw execution evidence remains unchanged.
The dedicated development config limited Ultra to 1536 completion tokens to fit
the remaining worst-case reservation. The observed truncation shows that this
cap was insufficient for this response. The code does not accept incomplete output
or turn a diagnosis into a successful repair.

The formal evaluation config remains separate. Raising a completion cap changes
reservation capacity; first preview the worst-case costs and bind a fresh plan.
These development outcomes are not evidence of a repair success rate or savings
from model routing.

Reports are retained under `reports/model-trial-md2html-web-20261020-v1/`,
`reports/model-trial-md2html-category-20261020-v2/` and
`reports/model-trial-md2html-bounded-20261020-v3/`. The validated public recordings
contain all three, alongside the six earlier development records.
