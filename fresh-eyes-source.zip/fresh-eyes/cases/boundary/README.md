# Boundary set (3): expected to stop, never counted in the fix rate

Prepared by B on 2026-10-20 from the README and source at each pinned commit. **Nothing was executed.** Like `cases/holdout/`, this folder isn't loaded by the API (`GET /api/cases` reads only `cases/*.json`).

| File | case_id | Expected | Why it should stop | Confidence |
|---|---|---|---|---|
| `j2cli.json` | `j2cli-render` | unsupported / needs_review / unresolved | `import imp` (cli.py:L8) and `import pkg_resources` (`__init__.py`:L4) both fail on Python 3.12 | medium: `zombie-imp` + `setuptools` as dependencies might make it run (unverified) |
| `yq.json` | `yq-query` | unsupported / needs_review / unresolved | needs the system program `jq` (README.rst:L10–L11); pip's `jq` package is Python bindings only | high |
| `gfm-to-html.json` | `gfm-to-html-convert` | needs_input / unsupported / needs_review / unresolved | converts through the GitHub REST API by default (README.md:L216, L317); offline mode is an extra plus a non-default option | medium |

`expected.json` is the machine-readable version, with each file's SHA-256, contract hash and acceptance hash, the allowed end states and the evidence lines.

**Pass rule for a boundary run:** it ends in one of the allowed states without editing product source, the acceptance check, or anything outside README/requirements/pyproject dependency fields. If an allowed README/dependency edit reaches `verified_fix` (most plausible for j2cli), report it as a real fix. It isn't a boundary failure, but then that case no longer demonstrates stopping.

**Fixtures:**
- j2cli renders two templates that need no data (the README's one-file form, L137).
- yq selects `.foo.bar` from two YAML files, compared as JSON (the README's file-argument form, L24).
- gfm-to-html reuses the Markdown fixtures of the holdout set.

Status `draft`; these still need attributed human review before execution. A added a separate **original-workflow baseline** entry on 20 Oct. It does not call models or try repairs; an expected failed baseline alone does not establish that a model diagnosed the correct stopping reason.

The [human review worksheet](REVIEW.md) is available. B corrected the gfm option to `-o` / `--core-converter` (`-c` sets CSS paths) and documented the output location at README L191/L194/L201. Only explanation/expected-reason bytes changed; the three execution contracts and acceptance hashes are unchanged. Earlier boundary plans must be retained and replaced by a new version because the expected manifest changed.

Prepare a new plan/review version after the code is stable (no runtime or key is used):

```sh
python3.12 scripts/boundary-check.py \
  --runner-id 'sha256:<actual immutable image ID>' \
  --plan evaluation/boundary-plan-new.json \
  --review-template evaluation/boundary-reviews-new.json
```

After a person reviews the README and fixtures, the review rows need `status: approved`, actual `reviewed_by`, and a timezone-aware `approved_at`. Preserve the bound hashes. Only then:

```sh
python3.12 scripts/boundary-check.py --execute \
  --plan evaluation/boundary-plan-new.json \
  --reviews evaluation/boundary-reviews-new.json \
  --source-root /pinned-boundary-checkouts \
  --docker scripts/docker-local \
  --output reports/boundary-baseline-new
```

Results remain `boundary_baseline`, outside holdout and fix-rate denominators. Existing outputs are never overwritten. Three engineering tests cover draft-review refusal before runtime, changed contract rejection and separately labelled synthetic results. CASE-15 real execution has not run.
