"""Public replay integrity and rebuilding without ignored/private owner files."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest

PROJECT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("demo_build", PROJECT / "web/demo/build.py")
demo = importlib.util.module_from_spec(spec)
spec.loader.exec_module(demo)
LATEST = "e9a04f641acb4c71b7ff0932e58f87e8"


class DemoTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "clean"
        self.root.mkdir()
        for name in ("web", "cases", "api/examples", "evidence"):
            shutil.copytree(PROJECT / name, self.root / name)
        self.out = Path(self.temp.name) / "site"

    def test_build_without_reports_database_env_or_runner(self):
        result = demo.build(self.root, self.out)
        self.assertEqual((result["cases"], result["approved"], result["recorded_runs"]), (3, 3, 9))
        self.assertFalse((self.root / "reports").exists())
        self.assertFalse((self.out / "evaluation.json").exists())
        self.assertFalse((self.out / "examples/two-round-success.json").exists())
        health = json.loads((self.out / "data/health.json").read_text())
        self.assertTrue(health["read_only"])
        self.assertFalse(health["paid_calls_enabled"])
        self.assertFalse(health["execution_enabled"])
        for record in (self.out / "data/runs").glob("*.json"):
            r = json.loads(record.read_text())
            self.assertEqual(r["data_origin"], "recorded_replay")
            self.assertFalse(r["evaluation_eligible"])
            self.assertFalse(r["costs"]["paid_calls_enabled"])
        r = json.loads((self.out / f"data/runs/{LATEST}.json").read_text())
        self.assertEqual(r["result_status"], "needs_review")
        rounds = r["evidence"]["repair_rounds"]
        self.assertEqual([r["status"] for r in rounds], ["rejected", "no_candidate"])
        self.assertTrue(rounds[0]["candidate_patch"]["patch"]["edits"])
        self.assertNotIn("candidate_patch", rounds[1])
        self.assertEqual(r["evidence"]["model_calls"], 4)
        self.assertEqual(str(r["evidence"]["model_ledger"]["calculated_usd"]), "0.01362438")
        self.assertIsNone(r["evidence"]["model_ledger"]["billed_usd"])
        manifest = json.loads((self.out / "data/manifest.json").read_text())
        for name, digest in manifest["files"].items():
            self.assertEqual(hashlib.sha256((self.out / name).read_bytes()).hexdigest(), digest)
        examples = json.loads((self.out / "data/examples.json").read_text())["items"]
        self.assertEqual(len(examples), 10)
        for name, body in examples.items():
            self.assertEqual(json.loads((self.out / f"data/examples/{name}.json").read_text()), body)

    def test_recording_tampering_stops_before_output(self):
        p = self.root / f"web/demo/recordings/runs/{LATEST}.json"
        p.write_bytes(p.read_bytes() + b" ")
        with self.assertRaisesRegex(ValueError, "hash changed"):
            demo.build(self.root, self.out)
        self.assertFalse(self.out.exists())

    def test_stale_approval_hash_does_not_lock_a_case(self):
        p = self.root / "evidence/approval-history-verified.json"
        proof = json.loads(p.read_text())
        event = proof["approval_events"][0]
        case_id = event["case_id"]
        event["acceptance_sha256"] = "0" * 64
        p.write_text(json.dumps(proof))
        cases, history = demo.cases_and_history(self.root)
        case = next(c for c in cases if c["case_id"] == case_id)
        self.assertNotEqual(case["review"]["status"], "approved")
        self.assertNotIn(case_id, history)

    def test_failed_public_scan_preserves_previous_good_demo(self):
        demo.build(self.root, self.out)
        before = (self.out / "data/manifest.json").read_bytes()
        for leaked in ("/Users/synthetic-private-path", "NEBIUS_API_KEY=synthetic-control-secret"):
            p = self.root / "web/app.js"
            p.write_text(p.read_text() + "\n// " + leaked)
            with self.assertRaisesRegex(ValueError, "Possible local path or credential"):
                demo.build(self.root, self.out, replace=True)
            self.assertEqual((self.out / "data/manifest.json").read_bytes(), before)
            shutil.copyfile(PROJECT / "web/app.js", p)

    def test_development_data_cannot_become_formal_evaluation(self):
        (self.root / "evaluation").mkdir()
        (self.root / "evaluation/results.json").write_text('{"data_origin":"example"}')
        with self.assertRaisesRegex(ValueError, "Only formal evaluation"):
            demo.build(self.root, self.out)
        self.assertFalse(self.out.exists())

    def test_does_not_replace_unmarked_directory(self):
        self.out.mkdir()
        (self.out / "keep.txt").write_text("unrelated")
        with self.assertRaisesRegex(ValueError, "recognized"):
            demo.build(self.root, self.out, replace=True)
        self.assertEqual((self.out / "keep.txt").read_text(), "unrelated")

    def test_synthetic_calls_are_rejected_even_if_file_hash_updated(self):
        path = self.root / f"web/demo/recordings/runs/{LATEST}.json"
        r = json.loads(path.read_text())
        r["evidence"]["model_ledger"]["calls"][0]["data_origin"] = "engineering_test"
        path.write_text(json.dumps(r))
        self.rehash(path)
        with self.assertRaisesRegex(ValueError, "synthetic or inconsistent"):
            demo.build(self.root, self.out)

    def test_manual_patch_must_still_match_evidence_hash(self):
        path = next((self.root / "web/demo/recordings/patches").glob("*.diff"))
        path.write_text(path.read_text() + "\n")
        self.rehash(path)
        with self.assertRaisesRegex(ValueError, "patch differs"):
            demo.build(self.root, self.out)

    def rehash(self, path):
        root = self.root / "web/demo/recordings"
        manifest_path = root / "manifest.json"
        manifest = json.loads(manifest_path.read_text())
        manifest["files"][path.relative_to(root).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
        manifest_path.write_text(json.dumps(manifest))
