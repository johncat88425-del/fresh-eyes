# API spending limits

Updated 2026-10-22. Chris requires free/prepaid usage only, with no additional charges.

All real Nebius inference and Tavily transports require the persistent project guard in `src/fresh_eyes/spending.py`, in addition to the existing per-run/model budget. Default state is locked. Provider-side PAYG/automatic charging must be verified disabled; a visible positive balance alone does not unlock access.

| Provider | Current project policy | Observed usage in this integration |
|---|---|---|
| Nebius inference | Locked: provider overage/automatic charging settings not yet verified off; old four-call development authorisation exhausted | Zero new calls |
| Tavily | Free only; PAYG and auto upgrade off in owner screenshot; project lifetime ceiling 10 credits, basic search only | One standalone real search, reported 1 credit; 9 project credits remain |
| Sandboxes | Disabled, zero execution allowance | No paid operations |

The Tavily account's 1,000-unit free allowance is **credits, not model tokens**. Account-wide usage by another client may reduce that balance. A funding/settings check expires within one hour; stale or unknown funding stops requests. The verified initial free balance does not promise a current account balance.

The private policy is `.fresh-eyes/spending-policy.json`; the persistent ledger is `.fresh-eyes/spending-ledger.sqlite3`. Neither file is packaged or published. New tasks, new run ledgers and process restarts do not create fresh allowance. There is no daily reset. Never delete this ledger to recover budget.

Before HTTP dispatch the guard atomically reserves worst-case cost (or one Tavily basic credit). Only the reserved request may consume that token once. Known usage settles it; absent or inconsistent usage keeps a conservative hold and blocks later requests pending reconciliation. HTTP errors have no automatic retry. This application gate complements provider settings; it cannot prove that unrelated tools using the same account have no charges.

No code automatically renews funding verification or enables PAYG, auto top-up or subscriptions. A future explicit funding check must preserve cumulative ledger use. The formal US$0.36 batch remains a separate scope with human reviews and a fresh freeze; it cannot fund development calls. Budget proposals in B's planning documents are not spend authorisations.

Evidence: `evidence/tavily-check-20261022.json` (real component lookup only, no Nano/Ultra or repository execution). Unit tests use isolated synthetic policies and mocked responses; they never read owner keys or consume credits.

The optional development integration is bound when creating a new `model-trial-plan` with `--enable-web-research`. Planning and preview do not read credentials or make requests. The fixed plan records this boolean and a maximum of two basic searches; the execution factory supplies a new researcher for that run. A plan that did not request research cannot silently acquire it. This switch does not enable spending or renew an exhausted authorisation. Current formal evaluation protocols keep research disabled for all groups and reject injected research-enabled planners; enabling C/D later requires a new reviewed protocol and freeze.
