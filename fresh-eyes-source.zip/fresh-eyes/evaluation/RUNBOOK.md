# 10/23 凍結、10/24 評估的操作入口

沿用既定英國時間時程。A／B／C／D 的凍結、執行與匯出程式已接通：A＝原始 README；B＝Nano 分類、Ultra 診斷，最多一輪；C＝相同路由，最多兩輪；D＝分類與診斷都用 Ultra，最多兩輪。完整規則見 [兩輪修補說明](../api/MULTI_ROUND.md)。

預設模型上限為零，不讀 key、不呼叫模型。付費組別需要自己的明確授權、凍結配置與本機啟用參數。先前 US$0.02 的單輪試驗已結束，不能沿用；本輪新增真實推論與保留集執行都是零。未跑組別明列原因，不生成假 run。

10/20 的 [凍結前狀態](PRE_FREEZE.md)：四份固定 Git 來源及匯出已備妥，四案仍待真人覆核；尚未正式凍結。開發模型試跑另走 [獨立入口](../api/MODEL_TRIAL.md)，不使用保留集調整。

以下在 fresh-eyes 專案根目錄操作。這份文件不是已執行保留集的紀錄；目前沒有 evaluation/results.json 真實結果。

## 1. 凍結（10/23）

先確認四案是正式樣本，固定的原始碼 Git 來源已備妥，並取得 Docker image 的完整 sha256 ID。不要使用會變動的 python:3.12-slim tag 作為凍結值。正式評估使用受控 pypi_live；offline_snapshot 僅供另列的可重現對照，不能用來觀察上游漂移。真人覆核材料見 [四案覆核單](../cases/HOLDOUT_REVIEW.md)。

```sh
python3.12 scripts/fresh-eyes evaluation-freeze \
  --runner-id 'sha256:填入實際64位image雜湊' \
  --dependency-mode pypi_live \
  --output evaluation/freeze-20261023.json \
  --reviews-template evaluation/reviews-20261023.json
```

這只讀已固定的四個案例，保存 code/prompts、runner、案例及 dependency_mode；live 模式不凍結上游版本，產生 draft 覆核表，不執行 repo、不批准案例。freeze 格式為 fresh-eyes-evaluation-freeze-v2，固定各組路由／輪數、共同單案時間與模型額度；預設 time_limit_s=600，模型單案／整批額度都是零。舊 v1 不可直接用於新執行，應保留原檔並建立新 freeze。

真人逐案檢查兩組輸入／預期值後，才把 reviews 內對應項目的 status 改為 approved，填實際 reviewed_by 與帶時區的 approved_at；hash 和 freeze_sha256 不改。原本的 case 檔案保持 draft 與既有凍結 bytes，不為了啟動而直接改檔。

live 模式不帶 wheelhouse，執行前需通過同一實際環境的出站 gate，安裝結果依每次 pip 證據解讀。若另做 offline_snapshot 對照，用獨立 freeze／輸出版本，並在凍結和執行都帶同一份 --wheelhouse；每個 wheel 的 bytes 會被鎖定，不能與 live 結果混算。

若之後獲准跑模型組別，在凍結時另外帶入下列參數；以下是配置示意，本輪未執行：

```text
--model-config /已核對的公開模型配置.json
--case-budget-usd <獲准的每案每組上限>
--batch-budget-usd <獲准的整批上限>
--time-limit-s 600
```

model-config 只能有 nano、ultra 兩個物件，各自包含完整 model_id、context_window、max_completion_tokens、input_per_million、output_per_million、price_reference，及可選 cached_input_per_million。金額用十進位字串；ID、容量、費率和帶日期的來源需核對，檔案不能含金鑰。整批上限至少涵蓋「每案上限 × 案例數 × 本批模型組別數」；不足時在任何 repo 或模型執行前停止。配置變更要建立新的 freeze 和真人覆核表。

## 2. A 組正式試跑（10/24）

```sh
python3.12 scripts/fresh-eyes evaluation-run \
  --freeze evaluation/freeze-20261023.json \
  --reviews evaluation/reviews-20261023.json \
  --source-root /已備妥且commit相符的原始碼目錄 \
  --docker scripts/docker-local \
  --group A --execute \
  --output-root reports/evaluation-20261024-A
```

source-root 下的資料夾名稱是各 repo URL 的最後一段；HEAD 必須符合固定 SHA。每案使用獨立乾淨容器，固定功能驗收，沒有 patch。一般 API 仍不顯示 holdout；只有這個明確命令進入正式入口。

四案的真人確認必須全部符合，且 code/prompts、案例與模式不能與凍結不同。未通過就在任何 repo 執行前停止。基礎設施失敗會保留報告；中斷任務保留 running binding，不捏造結果。已有 output-root 不覆蓋、不自動重試；如需另一次正式評估，先記錄原因，建立新的版本及輸出目錄，兩次都保留。

## 3. B／C／D 明確付費啟用（本輪未執行）

需要新的明確批次授權，且使用已含模型／額度的 freeze。沿用上述 execution 參數，將組別及輸出目錄改為：

```text
--groups A B C D
--enable-paid-models
--env-file .env
--tokenizer-references /已審閱的本機tokenizer目錄
--execute
--output-root reports/evaluation-20261024-ABCD
```

這些是替換／追加參數，不是可單獨執行的命令。也可只選尚未跑的 B C D；同一 freeze 的不同輸出可在匯出時合併。不可把已跑的 A 重複計分。

只有明確付費旗號才會讀取指定本機 env 中的 key。啟用前先唯讀查官方 catalog，核對模型 ID、context、輸入／輸出／cached 費率及零 request fee；不符即停止，不送推論。tokenizer/template 必須符合程式核對的 reference hash；不能用任意目錄替代。正式評估走本 CLI；[單次開發 API](../api/MODEL_API.md)不能充當評估入口。

同一案例內按選定組別交錯執行；每個組別從原始 commit、獨立乾淨 runner 和新的持久帳本開始。B／C／D 共用相同單案金額與時間上限，C／D 的兩輪不重設額度。任一已發送請求費用未知，保存 ledger 與 batch-stop.json，停止整批後續案例／組別。相同 stage 不重送；不自動重試、續跑或覆蓋舊輸出。控制端 deadline 會限制每階段與 HTTP timeout，但清理及部分 runtime 準備可能超時，並非平台硬性終止保證。

## 4. 產生前端要讀的 results.json

```sh
python3.12 scripts/fresh-eyes evaluation-export \
  --freeze evaluation/freeze-20261023.json \
  --records reports/evaluation-20261024-A \
  --output evaluation/results.json
```

只接受同一 freeze 綁定的報告，檢查報告 SHA-256、case／run／驗收 identity、runner image、來源與狀態；example／engineering double 不能匯入。輸出符合 [B 的格式](README.md)，重複 case+group 直接拒絕。重新發布需 --replace，會先保留 results.previous-*.json。

若 A 與 B／C／D 分開執行，可重複帶 --records，例如同時指定 reports/evaluation-20261024-A 和另一個僅含 BCD 的目錄。它們必須使用同一 freeze；匯出還會核對輪數、路由、模型帳本與逐筆費用，不能重標人工候選或單輪結果來充當其他組。

前端 web/serve.py 已只讀提供 /evaluation.json，不需要把整個 evaluation 目錄暴露出去。本機 runner 未計價，所以總 cost_usd 是 null；A 組 model_usd 是 0，模型組則依已知 usage 記錄 model_usd／model_cost_status，未對帳不能稱為實際扣款。未跑配對列在 unrun，整批停止理由保留在 batch_stops；runs 裡沒有假資料。

## 5. 人工覆核宣稱成功的 patch／輸出

初次匯出時追加 `--review-template evaluation/result-reviews-20261024.json`，同時產生新的 draft 覆核表。不覆蓋既有表，也不自動填任何人的姓名或結論。每列綁定 freeze、case/group/run、驗收 hash 和 report 檔案 hash，只包含已完成的 `verified_fix`。

真人查看對應 diff 與兩次功能驗證後，在該列填 `verdict: accepted` 或 `rejected`、實際 `reviewer`、帶時區的 `reviewed_at` 和 `note`。未完成的列維持 `draft`，仍不算覆核。再匯出：

```sh
python3.12 scripts/fresh-eyes evaluation-export \
  --freeze evaluation/freeze-20261023.json \
  --records reports/evaluation-20261024-A \
  --human-reviews evaluation/result-reviews-20261024.json \
  --output evaluation/results.json --replace
```

`--records` 要與第一次匯出相同，可帶多次合併其餘組別。程式檢查所有 identity/hash、重複列、確認者與時間，整份不合法即拒絕，不會部分套用。結論只寫入 `human_review`；被真人否決的修補仍保留原始 engine `result_status`，由前端誤判指標另外呈現。這是團隊覆核，不是維護者認可。本輪只用合成紀錄測試，沒有建立真實 results 或代填確認。

容量試算可用 `python3.12 evaluation/budget_plan.py --ledger <歷史帳本> --models <公開配置>`。10/20 的 [試算](budget-scenario-20261020.json)不是授權；四案、三個模型組、每組每案 US$0.03 需要至少 US$0.36 配置容量。全 Ultra 的相同 token 重算不是實測。

## 6. 交給展示頁與隊友

結果覆核匯入後，重建摘要，並把實際使用的每個 records root 交給展示 builder：

```sh
node evaluation/summarize.mjs evaluation/results.json > evaluation/summary.md
python3.12 web/demo/build.py --replace --evaluation-records reports/evaluation-20261024-A
```

多個 records root 就重複 `--evaluation-records`。builder 重用正式 exporter 驗證原始證據，將完整可開啟報告、patch、結果與覆核保存到可版控的 `web/demo/evaluation-recordings/`；之後 clone 不需要 ignored reports/。報告頁用 `result_review` 呈現接受／否決／未覆核，原始引擎結果不改。結果變動需重新 capture；只有 results.json 而缺報告會拒絕。未產生任何真實正式結果前，正式展示保持無評估成績。完整 B 操作見 [B_RUNBOOK_1024.md](B_RUNBOOK_1024.md)。

## 後續仍需完成

仍需真人覆核四案、授權後的真實模型開發試跑及 10/24 執行。10/20 正式環境選定 arm64／Python 3.12 並通過實際平台關卡；freeze 前仍要核對當時 image/config。工程測試不代表四組實驗已完成。若只跑部分組別，公開實際分母及缺少的配對。三個 boundary 有[獨立原始流程入口](../cases/boundary/README.md)，不做模型推論、不可混入修復率。任意 repo、每晚排程與 Sandboxes 執行不納入 v1。
