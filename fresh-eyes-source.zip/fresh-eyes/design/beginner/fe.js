// Fresh Eyes beginner prototype (B27): language switch, Help, project choice, the progress demonstration.
// Nothing here runs a check or talks to a server.
(() => {
  const root = document.documentElement;
  const params = new URLSearchParams(location.search);
  let lang = 'zh';
  try { if (localStorage.getItem('fe-lang') === 'en') lang = 'en'; } catch { /* storage unavailable */ }
  // ?lang= in a shared link wins, and is kept for the next pages.
  if (['zh', 'en'].includes(params.get('lang'))) {
    lang = params.get('lang');
    try { localStorage.setItem('fe-lang', lang); } catch { /* storage unavailable */ }
  }
  const apply = () => {
    root.dataset.lang = lang;
    root.lang = lang === 'zh' ? 'zh-Hant' : 'en';
    const title = document.querySelector(`meta[name="title-${lang}"]`);
    if (title) document.title = title.content;
  };
  apply();

  document.addEventListener('DOMContentLoaded', () => {
    const langBtn = document.getElementById('lang');
    langBtn?.addEventListener('click', () => {
      lang = lang === 'zh' ? 'en' : 'zh';
      try { localStorage.setItem('fe-lang', lang); } catch { /* storage unavailable */ }
      apply();
    });

    const help = document.getElementById('help');
    document.querySelectorAll('[data-open-help]').forEach(b => b.addEventListener('click', () => help?.showModal()));
    help?.querySelector('[data-close]')?.addEventListener('click', () => help.close());
    help?.addEventListener('click', e => { if (e.target === help) help.close(); });

    // Step 1: Continue stays disabled until a project is chosen.
    const choose = document.getElementById('choose');
    if (choose) {
      const go = document.getElementById('continue');
      const hint = document.getElementById('choose-hint');
      const update = () => {
        const picked = choose.querySelector('input:checked');
        go.setAttribute('aria-disabled', picked ? 'false' : 'true');
        go.href = picked ? picked.value : '#';
        hint.hidden = Boolean(picked);
      };
      choose.addEventListener('change', update);
      go.addEventListener('click', e => { if (go.getAttribute('aria-disabled') === 'true') { e.preventDefault(); hint.hidden = false; hint.focus(); } });
      update();
    }

    // Step 3 progress: a demonstration of the three stages, then the real recorded answer.
    const stages = document.getElementById('stages');
    if (stages) {
      const items = [...stages.children];
      const bar = document.querySelector('.bar span');
      const done = document.getElementById('done');
      const live = document.getElementById('live');
      const answers = { md2html: '05b-fixed.html', mistletoe: '05a-works.html', json2yaml: '05a-works-json2yaml.html' };
      const next = answers[params.get('case')] || answers.md2html;
      const slow = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 400 : 2200;
      let i = 0;
      const tick = () => {
        items.forEach((li, k) => {
          li.className = k < i ? 'done' : k === i ? 'now' : '';
          li.querySelector('.m').textContent = k < i ? '✓' : String(k + 1);
        });
        bar.style.width = `${Math.round((i / items.length) * 100)}%`;
        if (i < items.length) {
          live.textContent = items[i].querySelector(`[lang="${root.lang}"]`)?.textContent || '';
          i += 1; setTimeout(tick, slow);
        } else {
          done.hidden = false; done.querySelector('a').href = next; done.querySelector('a').focus();
          live.textContent = done.querySelector(`[lang="${root.lang}"]`)?.textContent || '';
        }
      };
      tick();
    }
  });
})();
