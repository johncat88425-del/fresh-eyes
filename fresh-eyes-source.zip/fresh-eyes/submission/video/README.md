# 演示影片（只錄畫面，英文）

B，2026-10-24。依 `submission/DEMO_VIDEO_SCRIPT_V3.md` 自動產生（第 3 版；第 5–7 段是 10/24 一口氣完成的 AI 修補 5c225204）。**目前是初稿**，畫面全部來自唯讀展示頁的真實紀錄。

## 產出（`out/`）

- `fresh-eyes-demo.mp4`：1920×1080，2:52，8 段，先介紹 Fresh Eyes 再講案例，Mac 的高品質英文語音 Zoe (Premium)，每分鐘 165 字，英文字幕直接畫在畫面上。
- `fresh-eyes-demo.srt`：同一份字幕，上傳 YouTube 用。
- `scene-1.jpg`～`scene-8.jpg`：每段中間的一張畫面，方便檢查。

## 和稿子不一樣的地方（初稿）

- **第 4 段不是 LIVE。** 現在沒有開 runner，所以改用 10/19 那次的真實紀錄，左下角標 `RECORDED · 19 Oct 2026`，旁白說「Then Fresh Eyes runs the README exactly as written」，不說 live。A 開好 runner 後，用 `LIVE_URL=http://127.0.0.1:<port>` 重做這段，會真的按「Try the instructions」並顯示時間。
- **片尾字卡已有連結**（repo 和 Pages 網址，10/24 重拍）。網址若有變，用 `REPO=… DEMO=… bash submission/gallery/shoot.sh` 重拍再重做影片。
- **第 5–7 段：** 10/24 一口氣完成的 AI 修補 `5c225204`（Nano → Ultra → 兩次乾淨環境通過，沒有人工修改）。舊的「中斷後重新驗證」故事已拿掉。
- **第 7 段的「about half a cent」** 來自 5c225204 的帳本（Nano $0.00016674＋Ultra $0.00530200，依 usage 計算，帳單未對帳）。
- 目前片中已是真實不中斷 AI 成功；若再加入維護者說明或正式評估，先核對新證據、改稿後同步重做畫面／旁白／字幕。

## 重新產生

先照 `submission/gallery/README.md` 在 3003 啟動唯讀展示頁，再：

```bash
cd ~/Desktop/fresh-eyes && node submission/video/make_video.mjs
```

- 只做某幾段：`SCENES=1,2 node submission/video/make_video.mjs`
- 換聲音或語速：`VOICE="Ava (Premium)" RATE=140 node …`（RATE 是每分鐘字數；`RATE=` 留空就用聲音本身的速度）
- 用暫時的 Chrome 設定檔在背景錄，不會錄到你螢幕上其他東西。沒有模型呼叫，費用 $0。
