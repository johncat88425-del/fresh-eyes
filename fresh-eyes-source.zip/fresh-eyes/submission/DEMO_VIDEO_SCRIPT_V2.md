# Demo video script v2: screen-only product demo (draft for Chris's approval)

B, 2026-10-22. **Draft, nothing has been recorded or made yet.** Replaces the face/voice plan in `VIDEO_SCRIPT.md`: no one appears on camera, the whole video is the product on screen, narrated in English.

## Rules this follows (official rules, read 2026-10-22)

- **Under 3 minutes.** Target 2:45.
- Must show the project actually working.
- Must be public on YouTube; Chris uploads it.
- No third-party trademarks, and no music unless we have the rights. So: no background music and no GitHub or other third-party pages on screen; everything shown is our own app.
- English.

## Honesty rules for every scene

- Each scene carries a small corner label:
  - **LIVE**: run at recording time;
  - **RECORDED · 19 Oct 2026** (or the right date): a replay of a real earlier run.
- Nothing is staged or invented.
- The only verified fix was written by a person, and the video says so.
- No AI fix has passed yet, and the video says that too.
- If any of this changes before recording (for example the formal evaluation runs), the script is updated first.

## Script

Narration is 272 words: about 2 minutes of speech inside 2:45, so the screens get room to breathe. Every scene fits at a normal pace (the fastest needs 136 words a minute).

| # | Time | On screen | Label | Narration |
|---|---|---|---|---|
| 1 | 0:00–0:16 | Detailed view, md2html report: the README command `pip install -r requirements.txt`, exit 0; then both inputs fail with `No such file or directory: 'md2html'` | RECORDED · 19 Oct | "This project's README says: install the requirements, then run md2html. We followed it exactly on a clean machine. The install worked, and the command didn't exist. Newcomers hit this all the time. Maintainers rarely see it." |
| 2 | 0:16–0:30 | Welcome page: "Do these instructions really work?", Start button, the three steps | RECORDED site | "Fresh Eyes reads a README like a newcomer. It follows the instructions in a clean test environment, checks the real output, and tells you in plain words whether they work." |
| 3 | 0:30–0:52 | Press Start → choose md2html → Step 2: the note becomes the web page; "Checked by a person"; open Show details (README lines, reviewer, lock) | RECORDED site | "First, a person agrees what success means: the README lines, two inputs, and the exact expected output. Then it's locked by a hash, so the agent can never move the goalposts." |
| 4 | 0:52–1:22 | **Local app with the runner on**: press "Try the instructions" for md2html → the three stages tick → answer: "No – the instructions don't work as written" | **LIVE** (time shown) | "Now a live check. A fresh container, the README commands exactly as written, and the real output compared with the locked check. Exit code zero never counts as success. It takes about half a minute, and here's the answer: the instructions don't work." |
| 5 | 1:22–1:52 | The fixed answer: ✗ → ✓, the one-line change, "Fix written by a person"; then Detailed view: patch → candidate run passed → final clean re-run passed | RECORDED · 19 Oct | "The fix is one line: pip install, dot. Fresh Eyes only calls it fixed after it passes in a fresh environment, and again in an independent clean re-run. To be clear: this fix was written by a person." |
| 6 | 1:52–2:30 | Two-round model report: Nano classification, Ultra diagnosis, round 1 proposal "Rejected · matched 0 times", round 2 "no patch"; then the model-call table (model IDs, tokens, cost) | RECORDED · 20 Oct | "Then NVIDIA Nemotron on Nebius Token Factory. Nano classifies the failure. Ultra diagnoses it and may propose one small patch. Ultra found the right cause, but its edit didn't match the README, so the patch checker refused it. In round two it declined to guess. Every call is in a ledger: real model IDs, tokens, and cost from usage." |
| 7 | 2:30–2:45 | Real examples page, then the end card: viewer URL and repository URL | RECORDED site | "Five real model runs so far, and no AI fix has passed yet. We show that too, because Fresh Eyes stops instead of guessing. The recorded demo and the full source are linked below." |

Optional, only if real results exist before recording: replace 0:15 of scene 3 with the evaluation page and its real numbers. The script must not mention an evaluation that hasn't run.

## Before you approve: three choices for Chris

1. **Voice.**
   - (a, recommended) A computer voice: the Mac's built-in English voice, generated on this Mac, no account or cost. Plus burned-in English captions.
   - (b) Captions only, no voice.
   - (c) You or someone else reads the narration (voice only, no face).
2. **The LIVE scene (4).** It needs the real runner on (the VM and Docker on this Mac), with execution on for a locked case. It's README-only: no model calls, $0.
   - (a, recommended) A starts the runner and runs it, as on 10/21 (job `f59257ef…`); I record the screen.
   - (b) Skip LIVE and use the recording of that same real run, labelled RECORDED. This is weaker against the rule about showing the project working.
3. **Making the video.**
   - I drive a separate, invisible Chrome window automatically, so nothing else on your screen is captured.
   - I take frames, and, with option 1a, use the Mac's built-in voice.
   - To put frames and audio together into an MP4, I need **ffmpeg**. It isn't installed. Installing it means downloading it with Homebrew (`brew install ffmpeg`, roughly 100–200 MB with its dependencies). I'll ask before installing.
   - Without ffmpeg I could try the Mac's own video framework instead, but it's slower to build and less reliable.

After approval I produce:
- `fresh-eyes-demo.mp4` (1920×1080, under 3:00);
- `fresh-eyes-demo.srt` (English captions for YouTube);
- a still of each scene for checking.

You upload it to YouTube yourself; I don't use your accounts.
