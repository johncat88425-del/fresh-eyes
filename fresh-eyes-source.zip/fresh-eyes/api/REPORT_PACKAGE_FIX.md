# 報告包修正

先前程式包的說明連到未包含的 reports，且另給的報告 ZIP 在本輪檢查時不在交付目錄，造成報告打不開／缺檔。原始報告仍完整；已重新封裝。

## 直接閱讀

下載 dist/fresh-eyes-reports-fixed-2026-10-19.zip，解壓整個資料夾，雙擊 **OPEN_REPORTS.html**。

- 不需要 API、Docker、Python 或網路。
- 不要只把入口 HTML 單獨拖出資料夾；它需要旁邊的 reports 目錄。
- 入口列出離線與即時 PyPI 報告，以及出站／建置原始 JSON。
- 環境故障的早期紀錄另標為排除，不計成 README 修復成果。
- 這是已保存的真實紀錄，打開不會重新執行，也不會自動進另一台 API 的 SQLite 歷史。

更新後程式包也包含這些只讀報告、入口頁和相對連結需要的文件。請解壓到新目錄，避免覆蓋 B 正在修改的前端。沒有加入 SQLite、憑證、VM、wheelhouse 或第三方 checkout。

## 可重建與驗證

A 的完整工作區可執行：

```sh
python3.12 scripts/package-reports.py
python3.12 scripts/package-handoff.py
```

封裝會先檢查每份摘要、API record 與 engine report 的狀態一致，再核對 HTML 相對連結。程式包也檢查 Markdown 相對連結；缺少目的檔案就停止，不再產生一個表面完整的包。ZIP 寫完後核對每檔 SHA-256 與 CRC。

原先兩個報告 ZIP 檔名也已重建，避免舊連結失效；新交接請使用帶 fixed 的獨立報告包。
