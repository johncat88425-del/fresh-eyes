# B 在 10/24–10/25 的步驟

B 準備、A 於 2026-10-20 整合。A 的正式評估步驟見 [RUNBOOK.md](RUNBOOK.md)；這份只寫 A 交出結果之後 B 要做的事。B 已在暫時複本用合成資料演練兩次（B15；第二次用 A 10/20 build），正式資料夾沒有假結果。

**原則：** 只用 A 匯出的 `evaluation/results.json`（`data_origin: "evaluation"`），數字一律從工具產生，不手抄、不四捨五入成百分比。沒跑的組別照實寫沒跑。

## 1. 從 A 那邊拿到結果（約 5 分鐘）

A 跑完 `evaluation-export` 後，把這些複製到 B 的工作區（`~/Desktop/fresh-eyes`）的相同位置：

- `evaluation/results.json`
- `evaluation/freeze-20261023.json`
- 每個評估輸出資料夾，例如 `reports/evaluation-20261024-A/`（每案一個子資料夾，含 `binding.json`、`report.json`）

```bash
cd ~/Desktop/fresh-eyes && python3 -c "import json; d=json.load(open('evaluation/results.json')); print(d['data_origin'], len(d['runs']), 'runs,', len(d['unrun']), 'unrun')"
```

第一個字必須是 `evaluation`。

## 2. 產生摘要（1 分鐘）

```bash
cd ~/Desktop/fresh-eyes && node evaluation/summarize.mjs evaluation/results.json > evaluation/summary.md
```

`summary.md` 有兩段：Devpost 用的結果，以及每個 verified_fix 的人工覆核表。

## 3. 人工覆核（EVAL-11，真人做）

A 在第一次匯出時會加上 `--review-template`，產生 `evaluation/result-reviews-20261024.json`，每筆 verified_fix 一列，狀態都是 draft。見 [RUNBOOK.md](RUNBOOK.md) 第 5 節。

真人照 `summary.md` 的覆核表逐筆打開報告：
- 讀 patch；
- 兩組輸出是否等於預期；
- 是否只改了 README／依賴欄位。

然後在 result-reviews 檔該列填 `verdict`（accepted／rejected）、實際 `reviewer`、帶時區的 `reviewed_at`、`note`。沒看完的列維持 draft。交給 A 用 `--human-reviews` 重新匯出，再回到第 2 步重做摘要。被否決的修補仍保留原本的結果狀態，評估頁會另外算成「覆核否決」。

## 4. 重建唯讀展示頁（5 分鐘）

```bash
cd ~/Desktop/fresh-eyes && python3.12 web/demo/build.py --replace --evaluation-records reports/evaluation-20261024-A
```

有多個輸出資料夾就重複 `--evaluation-records`。build 先重用正式 exporter 驗證 freeze、契約、組別、帳本、結果及 report hash，再保存 web/demo/evaluation-recordings。後續 clone 不需 ignored reports 也可重建；結果變動時要重新 capture。錯誤或本機路徑／疑似金鑰會停止並保留上一版展示，請記回共用表，不手動繞過。

```bash
cd ~/Desktop/fresh-eyes && node --test web/tests/*.test.mjs 2>&1 | grep -E "^ℹ (pass|fail)"
```

接著照 [TESTING.md](../TESTING.md) 第 1 節再看一遍，另外看評估頁：
- 每個結果標記都能點進該次報告；
- 報告頁有「評估組別」；
- 沒跑的組別有寫原因。

## 5. 更新投稿材料（約 30 分鐘）

1. `submission/DEVPOST.md` 的「Evaluation」：用 `summary.md` 第一段取代 `[TBD after 10/24…]`。「How we built it」的呼叫數和費用也從這裡更新。
2. `submission/VIDEO_SCRIPT.md` 1:55 那句的 `[TBD numbers]`，以及 `submission/subtitles_draft.srt` 第 15 段。
3. `submission/RECORDING_GUIDE.md` 的 1:55 鏡頭改成「有結果」的版本。
4. 圖庫：照 `submission/gallery/README.md` 重新產生，會多一張 `6-evaluation.png`。

## 6. 記錄

在 TEAM_TASKS 的 B 工作日誌寫下：
- 用的是哪一份 results.json（看 `freeze_sha256` 前 12 碼）；
- 摘要的關鍵數字；
- 覆核結果；
- 展示頁重建結果。

完成後勾 EVAL-10（和 A 一起）、DEPLOY-10。

## 如果先有模型修好的案例（AI-11）

一般 build 只讀已保存的 `web/demo/recordings/`。A 明確 refresh 時，會驗證並收進已完成的 model-trial（含 binding、報告、ledger、diff），不收未完成目錄。
1. A 執行 `python3.12 web/demo/build.py --refresh-recordings --replace`；通過兩次乾淨驗證且有真實模型呼叫的開發修補，才可成為 model_fix 連結。
2. B 再重建展示頁並測試（第 4 步）。
3. 影片 0:45 換成模型版（RECORDING_GUIDE 的「之後要換掉的鏡頭」）。
4. Devpost 的「A real example」和 `[TBD: replace or add a model-generated fix…]` 改寫，照實寫模型名稱、輪數和費用。
