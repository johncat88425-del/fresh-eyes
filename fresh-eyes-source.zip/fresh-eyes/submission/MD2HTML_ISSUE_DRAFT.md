<!-- GitHub issue for https://github.com/neobuilding/md2html (B, 2026-10-24). Chris approved this exact text; posted from
     Chris's account on 24 Oct 2026 as https://github.com/neobuilding/md2html/issues/1 -->

**Title:** [Bug] README Quick Start: the standard install doesn't create the `md2html` command used in Basic Usage

## Describe the bug

Following the README from top to bottom on a clean machine, the Quick Start "standard install" is:

```bash
pip install -r requirements.txt
```

That installs the runtime dependencies, but not md2html itself, so the `md2html` console script (`[project.scripts]` in `pyproject.toml`) is never created. The next section, **Basic Usage**, then runs `md2html README.md`, which fails.

The "invocation styles" table further down does say the CLI entry point "Requires `pip install -e .`", but a newcomer who follows Quick Start → Basic Usage in order never reaches that note before the first command fails.

## To reproduce

1. In a fresh Python 3.12 virtual environment, at commit `e0175df` (current `main`):

   ```bash
   git clone https://github.com/neobuilding/md2html.git && cd md2html
   pip install -r requirements.txt
   ```

2. Create `test.md`:

   ```markdown
   # Hello

   Some **bold** text.
   ```

3. Run:

   ```bash
   md2html test.md -o test.html
   ```

4. The command isn't found (`md2html: command not found` in a shell; our runner reported `[Errno 2] No such file or directory: 'md2html'`). The install step itself exits 0.

## Expected behaviour

After the Quick Start install, the commands in Basic Usage work.

## Suggested fix

Make the standard install install the package, for example:

````diff
 ```bash
-pip install -r requirements.txt
+pip install .
 # or for editable development install
 pip install -e ".[dev]"
 ```

-> - `-r requirements.txt`: standard install, runtime dependencies only. Use this for everyday use.
+> - `.`: standard install, includes the `md2html` command. Use this for everyday use.
````

We checked this in clean containers: with `pip install .` (and, separately, with `pip install -e .`), both of our test inputs converted correctly, and again in an independent fresh re-run. Happy to open a PR if that's useful.

## Environment

- **OS**: Linux (arm64), clean `python:3.12-slim` container
- **Python version**: 3.12.15
- **md2html version**: commit `e0175df5d214`
- **Installation method**: pip, `-r requirements.txt` as in Quick Start

## Additional context

We found this with Fresh Eyes, a tool we're building for a hackathon that follows a README exactly as written in a clean environment and checks the real output. Of the two variants we verified, `pip install .` was written by us and `pip install -e .` was proposed by an AI model (NVIDIA Nemotron); a person reviewed this report before posting. Thanks for md2html!
