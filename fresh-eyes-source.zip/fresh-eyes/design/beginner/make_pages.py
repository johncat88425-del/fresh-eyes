"""Write the beginner front-door prototype, one HTML file per screen (B27).

python3 design/beginner/make_pages.py

Every page carries Chinese and English; the language switch shows one. figma/zh and figma/en get the same screens
for importing into Figma: one language each, styles inline, no script, light theme, and each interactive state
(selected card, progress, details open, Help open) drawn out as its own file. All results are the recorded real
development runs in web/demo/recordings (no new runs, no model calls). Change text here, not in the HTML.
"""
from html import escape
from pathlib import Path

HERE = Path(__file__).resolve().parent
DETAILED = "http://localhost:5173/"  # the full site (web/), started with python3 web/serve.py
LANG = None    # "zh" or "en" while writing the Figma copies; None writes both languages into each page
FIGMA = False
OUT = HERE


def L(zh, en, tag="span", cls=None):
    c = f' class="{cls}"' if cls else ""
    if LANG:
        text = zh if LANG == "zh" else en
        return f"<{tag}{c}>{text}</{tag}>" if tag != "span" or cls else text
    return f'<{tag} lang="zh-Hant"{c}>{zh}</{tag}><{tag} lang="en"{c}>{en}</{tag}>'


LOGO = ('<svg width="44" height="44" viewBox="0 0 44 44" aria-hidden="true"><circle cx="22" cy="22" r="22" fill="var(--accent)"/>'
        '<path d="M9 22c3.5-6 8-9 13-9s9.5 3 13 9c-3.5 6-8 9-13 9s-9.5-3-13-9z" fill="none" stroke="var(--accent-ink)" stroke-width="2.6"/>'
        '<circle cx="22" cy="22" r="4.6" fill="var(--accent-ink)"/></svg>')

ART = """<svg class="art" viewBox="0 0 320 260" role="img" aria-labelledby="art-t"><title id="art-t">A sheet of instructions next to a new laptop showing a green tick</title>
<rect x="18" y="26" width="120" height="160" rx="12" fill="var(--card)" stroke="var(--ink-2)" stroke-width="3"/>
<path d="M40 60h70M40 86h76M40 112h60M40 138h70" stroke="var(--ink-2)" stroke-width="5" stroke-linecap="round"/>
<path d="M118 150l10 10 18-22" fill="none" stroke="var(--ok)" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
<rect x="150" y="96" width="150" height="100" rx="10" fill="var(--card)" stroke="var(--ink)" stroke-width="3"/>
<path d="M136 212h178l-12-16H148z" fill="var(--line)" stroke="var(--ink)" stroke-width="3" stroke-linejoin="round"/>
<circle cx="225" cy="146" r="30" fill="var(--ok-bg)"/>
<path d="M210 146l11 11 20-22" fill="none" stroke="var(--ok)" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M150 40c20-14 44-14 64 0" fill="none" stroke="var(--accent)" stroke-width="3" stroke-dasharray="6 8"/>
<circle cx="236" cy="44" r="16" fill="var(--accent)"/><circle cx="236" cy="44" r="6" fill="var(--accent-ink)"/>
</svg>"""

def help_html():
    return f"""<dialog class="help" id="help" aria-labelledby="help-title"><div class="inner">
<h2 id="help-title">{L("這是什麼？", "What is this?")}</h2>
<p>{L("很多軟體都附有一份「使用說明」，告訴你怎麼安裝、怎麼用。可是說明常常漏了一步。",
      "Many programs come with written instructions that tell you how to install and use them. Often a step is missing.")}</p>
<p>{L("Fresh Eyes 會在<strong>乾淨的測試環境</strong>中，一步一步照著說明做，然後用白話告訴你：說明到底能不能用。",
      "Fresh Eyes follows those instructions step by step in a <strong>clean test environment</strong>, then tells you in plain words whether they work.")}</p>
<div class="picture" aria-hidden="true"><div><svg width="48" height="48" viewBox="0 0 48 48" fill="none" stroke="var(--accent)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5h17l8 8v30H12z"/><path d="M18 20h13M18 27h13M18 34h9"/></svg><br>{L("說明", "Instructions")}</div><span class="arrow">→</span>
<div><svg width="48" height="48" viewBox="0 0 48 48" fill="none" stroke="var(--accent)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="10" width="30" height="21" rx="2"/><path d="M4 38h40l-4-7H8z"/></svg><br>{L("乾淨的測試環境", "A clean test environment")}</div><span class="arrow">→</span><div><svg width="48" height="48" viewBox="0 0 48 48" fill="none" stroke="var(--accent)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><circle cx="24" cy="24" r="18"/><path d="M15 24l6 6 12-13"/></svg><br>{L("清楚的答案", "A clear answer")}</div></div>
<h2 style="font-size:24px">{L("符號的意思", "What the symbols mean")}</h2>
<ul class="legend">
<li><span class="status st-ok"><span class="sym" aria-hidden="true">✓</span>{L("能用", "Works")}</span> {L("照著說明做，得到正確的結果。", "Following the instructions gives the right result.")}</li>
<li><span class="status st-bad"><span class="sym" aria-hidden="true">✗</span>{L("不能用", "Doesn't work")}</span> {L("照著說明做，結果不對。", "Following the instructions gives the wrong result.")}</li>
<li><span class="status st-person"><span class="sym" aria-hidden="true">!</span>{L("需要人來決定", "Needs a person")}</span> {L("我們停下來，不亂猜。", "We stopped instead of guessing.")}</li>
</ul>
<p>{L("你在這裡按什麼都不會弄壞東西。這些頁面只顯示已經真的做過的檢查。",
      "Nothing you press here can break anything. These pages only show checks that really happened.")}</p>
<div class="actions"><button class="btn" type="button" data-close>{L("知道了", "Got it")}</button></div>
</div></dialog>"""


def page(name, title_zh, title_en, body, banner=None):
    banners = {
        "recorded": ("st-run", L("你看到的是一次真實檢查的紀錄。現在沒有在執行任何新的東西。",
                                 "You are looking at a recording of a real check. Nothing new is being run.")),
        "proto": ("proto", L("這是設計原型：下面的進度只是示範，沒有真的在跑。接著會顯示這個專案真實的檢查結果。",
                             "Design prototype: the progress below is a demonstration, nothing is running. Next you see this project's real recorded result.")),
    }
    if FIGMA and banner == "proto":
        banner = None  # the real page shows real progress; the demonstration note is prototype-only
    ban = f'<div class="banner {banners[banner][0] if banner == "proto" else ""}" role="note"><div class="wrap">{banners[banner][1]}</div></div>' if banner else ""
    html = f"""<!doctype html>
<html lang="{'en' if LANG == 'en' else 'zh-Hant'}" data-lang="{LANG or 'zh'}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{escape(title_en if LANG == 'en' else title_zh)} · Fresh Eyes</title>
<meta name="title-zh" content="{escape(title_zh)} · Fresh Eyes">
<meta name="title-en" content="{escape(title_en)} · Fresh Eyes">
<meta name="description" content="Fresh Eyes follows a project's instructions in a clean test environment and says, in plain words, whether they work.">
{figma_css() if FIGMA else '<link rel="stylesheet" href="style.css">' + chr(10) + '<script src="fe.js"></script>'}
</head>
<body>
<header class="top"><div class="wrap">
<a class="brand" href="01-welcome.html">{LOGO}<span class="word">Fresh Eyes</span><span class="sr-only">{L("回到首頁", "Back to the start page")}</span></a>
<div class="top-actions">
<button class="chip" type="button" data-open-help>? {L("說明", "Help")}</button>
<button class="chip" type="button" id="lang">{L("English", "中文")}</button>
</div></div></header>
{ban}
<main id="main"><div class="wrap">
{body}
</div></main>
<footer><div class="wrap">
<span>{L("為 Nebius × NVIDIA 黑客松製作，使用 Nebius Token Factory 上的 NVIDIA Nemotron。",
          "Made for the Nebius × NVIDIA hackathon. Built with NVIDIA Nemotron on Nebius Token Factory.")}</span>
<span><a href="{DETAILED}">{L("詳細版（給開發者和評審）", "Detailed view (for developers and judges)")}</a></span>
</div></footer>
{"" if FIGMA else help_html()}
</body>
</html>
"""
    (OUT / name).write_text(html, encoding="utf-8")


def steps(current):
    names = [("選專案", "Choose a project"), ("應該發生什麼", "What should happen"), ("答案", "The answer")]
    items = []
    for i, (zh, en) in enumerate(names, 1):
        attr = ' aria-current="step"' if i == current else (' class="done"' if i < current else "")
        items.append(f'<li{attr}><span class="n">{"✓" if i < current else i}</span><span class="t">{L(zh, en)}</span></li>')
    return (f'<p class="step-of">{L(f"第 {current} 步，共 3 步", f"Step {current} of 3")}</p>'
            f'<ol class="steps" aria-label="{escape("Progress")}">{"".join(items)}</ol>')


def nav(back_href, back_zh, back_en, restart=True):
    again = f'<a class="back" href="01-welcome.html">{L("重新開始", "Start again")}</a>' if restart else ""
    return f'<div class="nav-row"><a class="back" href="{back_href}">←&nbsp;{L(back_zh, back_en)}</a>{again}</div>'


def status(kind, zh, en, sym=None):
    sym = sym or {"ok": "✓", "bad": "✗", "person": "!", "run": "…", "plain": "✓"}[kind]
    return f'<span class="status st-{kind}"><span class="sym" aria-hidden="true">{sym}</span>{L(zh, en)}</span>'


# ---------------------------------------------------------------- projects (real registered cases)
PROJECTS = {
    "md2html": {
        "repo": "neobuilding/md2html", "file": "03-promise-md2html.html",
        "what": ("把筆記變成網頁", "turns notes into a web page"),
        "input": "# Hello\n\nA **bold** start.",
        "result": '<div class="h">Hello</div><p>A <strong>bold</strong> start.</p>',
        "result_label": ("網頁上會看到", "On the web page you see"),
        "input_label": ("筆記", "The note"),
        "readme": "README.md: L36–L45, L144–L153", "reviewed": "19 Oct 2026",
    },
    "mistletoe": {
        "repo": "miyuchina/mistletoe", "file": "03-promise-mistletoe.html",
        "what": ("也是把筆記變成網頁", "also turns notes into a web page"),
        "input": "# Hello\n\nA **bold** start.",
        "result": '<div class="h">Hello</div><p>A <strong>bold</strong> start.</p>',
        "result_label": ("網頁上會看到", "On the web page you see"),
        "input_label": ("筆記", "The note"),
        "readme": "README.md: L73–L77, L146–L155", "reviewed": "19 Oct 2026",
    },
    "json2yaml": {
        "repo": "drbild/json2yaml", "file": "03-promise-json2yaml.html",
        "what": ("把一種資料格式換成另一種", "changes one data format into another"),
        "input": "name: Ada\nlangs:\n  - en\n  - fr",
        "result": '<pre class="paper" style="border:0;padding:0">{\n  "langs": ["en", "fr"],\n  "name": "Ada"\n}</pre>',
        "result_label": ("換成的格式", "The same data, converted"),
        "input_label": ("原本的資料", "The original data"),
        "readme": "README.md: L11, L16, L32–L42", "reviewed": "20 Oct 2026",
    },
}


def welcome():
    body = f"""<section class="hero">
<div>
<h1>{L("這份使用說明，真的能用嗎？", "Do these instructions really work?")}</h1>
<p class="lead">{L("我們在全新的測試環境中照著軟體的使用說明做，再用白話告訴你能不能用。",
                   "We follow a project's instructions in a clean test environment and tell you, in plain words, if they work.")}</p>
<div class="actions"><a class="btn" href="02-choose.html">{L("開始", "Start")} →</a></div>
<a class="quiet" href="06-examples.html">{L("先看一個真實的例子", "See a real example first")}</a>
</div>
<div>{ART}</div>
</section>
<h2 class="sr-only">{L("怎麼運作", "How it works")}</h2>
<ol class="three">
<li><span class="n">1</span><strong>{L("選一個專案", "Choose a project")}</strong>{L("挑一個你想檢查的軟體。", "Pick the program you want to check.")}</li>
<li><span class="n">2</span><strong>{L("我們照說明做", "We try the instructions")}</strong>{L("在全新的測試環境中，一步都不跳。", "In a clean test environment, without skipping a step.")}</li>
<li><span class="n">3</span><strong>{L("你拿到清楚的答案", "You get a clear answer")}</strong>{L("能用、不能用，或需要人來決定。", "It works, it doesn't, or a person needs to decide.")}</li>
</ol>"""
    page("01-welcome.html", "首頁", "Welcome", body)


def choose():
    cards = []
    for key, p in PROJECTS.items():
        cards.append(f"""<label class="choice"><input type="radio" name="project" value="{p['file']}">
<span><span class="name">{key}</span><span class="what">{L(*p['what'])}</span>
<span style="display:block;margin-top:8px">{status("plain", "已由真人確認", "Checked by a person")}</span></span></label>""")
    body = f"""{nav("01-welcome.html", "返回", "Back", restart=False)}
{steps(1)}
<h1>{L("要檢查哪一個專案？", "Which project should we check?")}</h1>
<p class="lead">{L("點一下其中一張卡片。", "Tap one of the cards.")}</p>
<fieldset class="choices" id="choose"><legend class="sr-only">{L("專案", "Projects")}</legend>{"".join(cards)}</fieldset>
<div class="actions"><a class="btn" id="continue" href="#" aria-disabled="true" aria-describedby="choose-hint">{L("繼續", "Continue")} →</a></div>
<p class="hint" id="choose-hint" tabindex="-1">{L("請先選一個專案，才能繼續。", "Choose a project to continue.")}</p>"""
    page("02-choose.html", "第 1 步：選專案", "Step 1: Choose a project", body)


def promise(key):
    p = PROJECTS[key]
    body = f"""{nav("02-choose.html", "返回選專案", "Back to the projects")}
{steps(2)}
<h1>{L("說明裡答應會發生這件事", "This is what the instructions promise")}</h1>
<p class="lead">{L(f"專案：<strong>{key}</strong>，{p['what'][0]}。", f"Project: <strong>{key}</strong>, which {p['what'][1]}.")}</p>
<div class="io">
<div><div class="label">{L(*p['input_label'])}</div><pre class="paper">{escape(p['input'])}</pre></div>
<span class="arrow" aria-hidden="true">→</span>
<div><div class="label">{L(*p['result_label'])}</div><div class="rendered">{p['result']}</div></div>
</div>
<p>{status("plain", "已由真人確認", "Checked by a person")}</p>
<p>{L("有一位真人看過這個例子，同意這就是正確的結果。它已經鎖定，沒有人能偷偷改掉。",
      "A person checked this example and agreed it's the right result. It is locked so nobody can change it.")}</p>
<div class="actions"><a class="btn" href="04-trying.html?case={key}">{L("照說明試試看", "Try the instructions")} →</a></div>
<details class="more"><summary>{L("看細節", "Show details")}</summary><div class="body">
<p class="tech">{L("程式碼位置", "Code")}: <code>github.com/{p['repo']}</code><br>
{L("說明的出處", "Where the instructions come from")}: <code>{p['readme']}</code><br>
{L("確認的人", "Checked by")}: kevin · {p['reviewed']}<br>
{L("這個專案其實有兩個例子要通過；這裡只顯示第一個。", "The check has two examples to pass; this page shows the first.")}</p>
</div></details>"""
    page(p["file"], f"第 2 步：{key} 應該發生什麼", f"Step 2: What {key} should do", body)


def trying():
    stages = [("準備乾淨的測試環境", "Preparing a clean test environment"), ("照著說明一步一步做", "Following the instructions"),
              ("檢查結果對不對", "Checking the result")]
    lis = "".join(f'<li><span class="m" aria-hidden="true">{i}</span><span>{L(zh, en)}</span></li>' for i, (zh, en) in enumerate(stages, 1))
    body = f"""{nav("02-choose.html", "返回選專案", "Back to the projects")}
{steps(3)}
<h1>{L("我們正在全新的測試環境中照著說明做", "We're following the instructions in a clean test environment")}</h1>
<p class="lead">{L("通常不到一分鐘。這個頁面開著就好，不用做任何事。", "This usually takes less than a minute. You can leave this page open.")}</p>
<div class="bar" aria-hidden="true"><span></span></div>
<ol class="stages" id="stages">{lis}</ol>
<p class="sr-only" id="live" aria-live="polite"></p>
<div id="done" hidden><p>{L("好了，答案出來了。", "Done. Your answer is ready.")}</p>
<div class="actions"><a class="btn" href="05b-fixed.html">{L("看答案", "See the answer")} →</a></div></div>"""
    page("04-trying.html", "第 3 步：試試看", "Step 3: Trying", body, banner="proto")


def details(rows, tech, report_id):
    lis = "".join(f'<li><span class="m {k}" aria-hidden="true">{ {"ok": "✓", "bad": "✗", "person": "!", "plain": "•"}[k] }</span>'
                  f'<span>{L(zh, en, "strong")}<span class="s">{L(szh, sen)}</span></span></li>' for k, zh, en, szh, sen in rows)
    return (f'<details class="more"><summary>{L("看細節", "Show details")}</summary><div class="body"><ol class="timeline">{lis}</ol>'
            f'<p class="tech">{tech}<br><a href="{DETAILED}#/runs/{report_id}">{L("打開完整技術報告", "Open the full technical report")}</a></p></div></details>')


def answer(name, title, mark, h1, sentences, extra="", rows=(), tech="", run_id="", more_links=""):
    body = f"""{nav("02-choose.html", "返回選專案", "Back to the projects")}
{steps(3)}
<div class="answer-mark">{mark}</div>
<h1>{L(*h1)}</h1>
{"".join(f"<p class='lead'>{L(zh, en)}</p>" for zh, en in sentences)}
{extra}
<div class="actions"><a class="btn" href="02-choose.html">{L("檢查另一個專案", "Check another project")}</a>{more_links}</div>
{details(rows, tech, run_id)}"""
    page(name, title[0], title[1], body, banner="recorded")


def answers():
    sym = lambda k, s: f'<span class="big-sym {k}" aria-hidden="true">{s}</span>'
    answer("05a-works.html", ("答案：mistletoe 能用", "Answer: mistletoe works"),
           sym("ok", "✓") + status("ok", "能用", "Works"),
           ("是的，這份說明能用。", "Yes – the instructions work."),
           [("我們完全照著做，得到了正確的結果。兩個例子都通過。", "We followed them exactly and got the right result. Both examples passed.")],
           rows=[("ok", "照說明安裝", "Installed as the instructions say", "在全新的測試環境中，從網路下載需要的東西。", "In a clean test environment, downloading what it needs."),
                 ("ok", "兩個例子都得到正確的網頁", "Both examples gave the right web page", "標題和粗體、斜體都對。", "Headings, bold and italic all correct."),
                 ("plain", "不需要修改", "No fix needed", "花了約 8 秒。", "Took about 8 seconds.")],
           tech="mistletoe · 19 Oct 2026 · <code>already_passes</code> · run <code>a7bf8fc4…</code>", run_id="a7bf8fc4969e44ec9436ea79cc7cee00")
    answer("05a-works-json2yaml.html", ("答案：json2yaml 能用", "Answer: json2yaml works"),
           sym("ok", "✓") + status("ok", "能用", "Works"),
           ("是的，這份說明能用。", "Yes – the instructions work."),
           [("我們完全照著做，資料格式換得正確。兩個例子都通過。", "We followed them exactly and the data came out right. Both examples passed.")],
           rows=[("ok", "照說明安裝", "Installed as the instructions say", "用事先存好的一份零件，不連網路。", "Using a saved copy of the parts, with no internet."),
                 ("ok", "兩個例子都換成正確的格式", "Both examples converted correctly", "", ""),
                 ("plain", "不需要修改", "No fix needed", "花了約 4 秒。", "Took about 4 seconds.")],
           tech="json2yaml · 20 Oct 2026 · <code>already_passes</code> · offline snapshot · run <code>9a4e3a87…</code>", run_id="9a4e3a87ecfc4051a6c355d1c86b7b16")
    fix = f"""<div class="diff" role="group" aria-label="The fix"><div class="old"><span class="sign" aria-hidden="true">−</span><span class="sr-only">{L("原本：", "Before: ")}</span>pip install -r requirements.txt</div>
<div class="new"><span class="sign" aria-hidden="true">+</span><span class="sr-only">{L("改成：", "After: ")}</span>pip install .</div></div>
<p>{status("plain", "這個修正是人寫的", "Fix written by a person", "✎")}</p>
<p>{L("原本的說明只裝了 md2html 需要的零件，沒有裝 md2html 本身。改一行就兩個都裝好了。",
      "The original instructions install only the parts md2html needs, not md2html itself. Changing one line installs both.")}</p>"""
    answer("05b-fixed.html", ("答案：md2html 缺一步，已修好", "Answer: md2html was missing a step – fixed"),
           sym("bad", "✗") + '<span class="arrow" aria-hidden="true">→</span>' + sym("ok", "✓") + status("ok", "修好了", "Fixed"),
           ("說明漏了一步，這是修正方法。", "The instructions were missing one step – here is the fix."),
           [("我們在兩個獨立的乾淨測試環境上試了這個修正，兩次都成功。", "We tried the fix in two independently reset test environments and it worked both times.")],
           extra=fix,
           rows=[("bad", "照原本的說明做", "Followed the original instructions", "最後一步要用 md2html，但它根本沒被裝上。", "The last step uses md2html, but it was never installed."),
                 ("plain", "改了說明裡的一行", "Changed one line of the instructions", "這個修正是我們團隊的人寫的，不是 AI。", "Written by a person on our team, not by AI."),
                 ("ok", "在全新的測試環境中照新說明做", "Followed the new instructions in a clean test environment", "兩個例子都對。", "Both examples right."),
                 ("ok", "重新建立乾淨測試環境，再做一次", "Did it again in another clean test environment", "還是都對。總共約 39 秒。", "Still right. About 39 seconds in total.")],
           tech="md2html · 19 Oct 2026 · <code>verified_fix</code> · <code>manual_candidate</code> · run <code>563db906…</code>",
           run_id="563db9062b7b4e48a4490e41b6792ff6",
           more_links=f'<a class="btn secondary" href="{"../../" if FIGMA else ""}md2html-fix.patch" download>{L("下載修正", "Download the fix")}</a>')
    answer("05c-needs-person.html", ("答案：需要人來決定", "Answer: needs a person"),
           sym("person", "!") + status("person", "需要人來決定", "Needs a person"),
           ("我們停了下來，沒有亂猜。", "We stopped instead of guessing."),
           [("我們的 AI 看得出問題在哪裡，但沒辦法安全地修好，所以請一個人來決定。",
             "Our AI could see the problem but could not safely fix it, so it asks a person to decide.")],
           extra=f'<p>{L("AI 說得對：說明只裝了零件，沒有裝 md2html 本身。可是它提出的修改，對不上說明裡的原文，所以我們沒有套用。",
                        "The AI was right: the instructions install the parts but not md2html itself. But the change it suggested did not match the instructions word for word, so we did not apply it.")}</p>',
           rows=[("bad", "照原本的說明做", "Followed the original instructions", "md2html 沒被裝上。", "md2html was never installed."),
                 ("plain", "AI 讀了錯誤訊息", "The AI read the error", "NVIDIA Nemotron（Nano 分類、Ultra 解釋原因）。", "NVIDIA Nemotron (Nano sorts it, Ultra explains why)."),
                 ("person", "AI 的第一個修改被擋下", "The AI's first change was refused", "要改的文字對不上原文，所以不套用。", "The text it wanted to replace did not match, so it was not applied."),
                 ("person", "第二次沒有提出修改，停下", "Second try: no change suggested, so we stopped", "共 4 次 AI 呼叫，依用量算約 1.4 美分（帳單尚未確認），約 30 秒。",
                  "4 AI calls, about 1.4 US cents worked out from usage (bill not confirmed yet), about 30 seconds.")],
           tech="md2html · 20 Oct 2026 · <code>needs_review</code> · model, 2 rounds · run <code>e9a04f64…</code>. "
                + L("更早一次單輪的 AI 試跑（2 次呼叫）也是同樣停下。", "An earlier single-round AI try (2 calls) ended the same way."),
           run_id="e9a04f641acb4c71b7ff0932e58f87e8",
           more_links=f'<a class="btn secondary" href="05b-fixed.html">{L("看人寫的修正", "See the fix a person wrote")}</a>')
    answer("05d-doesnt-work.html", ("答案：md2html 照原文不能用", "Answer: md2html doesn't work as written"),
           sym("bad", "✗") + status("bad", "不能用", "Doesn't work"),
           ("不行，照原本的說明做不出來。", "No – the instructions don't work as written."),
           [("我們完全照著做。最後一步要用一個叫 md2html 的程式，可是說明從頭到尾都沒有把它裝上。",
             "We followed them exactly. The last step needs a program called md2html, but the instructions never install it.")],
           extra=f'<p>{L("這次檢查只是照原文做，沒有嘗試修改。", "This check only followed the instructions as written; it did not try a fix.")}</p>',
           rows=[("ok", "照說明安裝零件", "Installed the parts as instructed", "這一步成功。", "This step worked."),
                 ("bad", "照說明使用 md2html", "Used md2html as instructed", "電腦說找不到這個程式。兩個例子都失敗。", "The computer said the program doesn't exist. Both examples failed."),
                 ("plain", "沒有嘗試修改", "No fix was tried", "約 10 秒。", "About 10 seconds.")],
           tech="md2html · 19 Oct 2026 · <code>unresolved</code> · run <code>10175eee…</code>", run_id="10175eee750c464fa7ce86ad4c84f037",
           more_links=f'<a class="btn secondary" href="05b-fixed.html">{L("看修好的版本", "See the fixed version")}</a>')


def examples():
    rows = [("md2html", ("照原本的說明做不出來", "the instructions were missing a step"), ("bad", "不能用", "Doesn't work"), "05d-doesnt-work.html"),
            ("md2html", ("人寫的修正，在兩個獨立的乾淨測試環境上都成功", "fixed by a person and proven twice"), ("ok", "修好了", "Fixed"), "05b-fixed.html"),
            ("md2html", ("我們的 AI 停下來，沒有亂猜", "our AI stopped instead of guessing"), ("person", "需要人來決定", "Needs a person"), "05c-needs-person.html"),
            ("mistletoe", ("說明原本就能用", "the instructions already work"), ("ok", "能用", "Works"), "05a-works.html"),
            ("json2yaml", ("說明原本就能用", "the instructions already work"), ("ok", "能用", "Works"), "05a-works-json2yaml.html")]
    lis = "".join(f'<li><span><span class="name">{n}</span><span class="what">{L(*w)}</span>{status(*s)}</span>'
                  f'<a class="btn" href="{href}">{L("看看", "See it")} →</a></li>' for n, w, s, href in rows)
    body = f"""{nav("01-welcome.html", "返回首頁", "Back to the start", restart=False)}
<h1>{L("我們真的做過的檢查", "Real checks we have run")}</h1>
<p class="lead">{L("每一個都是在全新的測試環境中真的跑出來的。", "Each one really ran in a clean test environment.")}</p>
<ul class="rows">{lis}</ul>
<div class="actions"><a class="btn secondary" href="02-choose.html">{L("自己選一個專案", "Choose a project yourself")}</a></div>"""
    page("06-examples.html", "真實的例子", "Real examples", body, banner="recorded")


def help_page():
    inner = help_html().split('<div class="inner">', 1)[1].rsplit("</div></dialog>", 1)[0].replace(" data-close", "").replace('<h2 id="help-title">', '<h1 id="help-page-title">', 1).replace("</h2>", "</h1>", 1).replace(
        '<button class="btn" type="button">', '<a class="btn" href="01-welcome.html">').replace(L("知道了", "Got it") + "</button>", L("知道了", "Got it") + "</a>")
    page("07-help.html", "說明", "Help", f'<div class="card narrow">{inner}</div>')


def kit():
    body = f"""<h1>{L("元件一覽", "Components")}</h1>
<p class="lead">{L("所有頁面用到的元件，亮色和暗色都可以用系統設定切換。", "Every component the pages use; light and dark follow the system setting.")}</p>
<div class="kit">
<section><h2>{L("按鈕", "Buttons")}</h2><div class="actions" style="margin:0"><a class="btn" href="#">{L("主要按鈕", "Primary")}</a>
<a class="btn secondary" href="#">{L("次要按鈕", "Secondary")}</a><a class="btn" aria-disabled="true" href="#">{L("還不能按", "Disabled")}</a>
<a href="#">{L("文字連結", "Text link")}</a></div></section>
<section><h2>{L("狀態標籤（符號＋文字）", "Status labels (symbol + word)")}</h2><div class="swatches">
{status("ok", "能用", "Works")}{status("bad", "不能用", "Doesn't work")}{status("person", "需要人來決定", "Needs a person")}{status("run", "還在跑", "Still running")}{status("plain", "已由真人確認", "Checked by a person")}</div></section>
<section><h2>{L("步驟指示", "Step indicator")}</h2>{steps(2)}</section>
<section><h2>{L("可選的專案卡片", "Selectable project card")}</h2><div class="choices"><label class="choice"><input type="radio" name="k" checked>
<span><span class="name">md2html</span><span class="what">{L("把筆記變成網頁", "turns notes into a web page")}</span></span></label></div></section>
<section><h2>{L("一行修正", "One-line fix")}</h2><div class="diff"><div class="old"><span class="sign">−</span>pip install -r requirements.txt</div><div class="new"><span class="sign">+</span>pip install .</div></div></section>
<section><h2>{L("進度", "Progress stages")}</h2><ol class="stages" style="margin:0"><li class="done"><span class="m">✓</span><span>{L("做完的步驟", "A finished stage")}</span></li>
<li class="now"><span class="m">2</span><span>{L("正在做的步驟", "The current stage")}</span></li><li><span class="m">3</span><span>{L("還沒開始", "Not started")}</span></li></ol></section>
<section><h2>{L("看細節（預設收起來）", "Show details (closed by default)")}</h2><details class="more" style="margin:0"><summary>{L("看細節", "Show details")}</summary><div class="body"><p>{L("技術資料放在這裡。", "Technical facts live here.")}</p></div></details></section>
</div>"""
    page("08-components.html", "元件", "Components", body)


def screen_map():
    screens = [("01", "01-welcome.html", ("首頁", "Welcome"), ("一個問題、一個大按鈕。", "One question, one big button.")),
               ("02", "02-choose.html", ("第 1 步：選專案", "Step 1: Choose a project"), ("三張大卡片；沒選之前「繼續」不能按。", "Three big cards; Continue waits for a choice.")),
               ("03a", "03-promise-md2html.html", ("第 2 步：md2html 應該發生什麼", "Step 2: md2html promise"), ("筆記 → 網頁", "Note → web page")),
               ("03b", "03-promise-mistletoe.html", ("第 2 步：mistletoe 應該發生什麼", "Step 2: mistletoe promise"), ("筆記 → 網頁", "Note → web page")),
               ("03c", "03-promise-json2yaml.html", ("第 2 步：json2yaml 應該發生什麼", "Step 2: json2yaml promise"), ("YAML → JSON", "YAML → JSON")),
               ("04", "04-trying.html", ("第 3 步：試試看（進度）", "Step 3: Trying (progress)"), ("三個階段一個一個打勾（示範）。", "Three stages tick off (demonstration).")),
               ("05a", "05a-works.html", ("答案：能用（mistletoe）", "Answer: works (mistletoe)"), ("大大的 ✓", "A big ✓")),
               ("05a+", "05a-works-json2yaml.html", ("答案：能用（json2yaml）", "Answer: works (json2yaml)"), ("大大的 ✓", "A big ✓")),
               ("05b", "05b-fixed.html", ("答案：缺一步，已修好", "Answer: missing a step, fixed"), ("✗ → ✓、一行修正、下載", "✗ → ✓, one-line fix, download")),
               ("05c", "05c-needs-person.html", ("答案：需要人來決定", "Answer: needs a person"), ("AI 停下來沒有亂猜", "The AI stopped instead of guessing")),
               ("05d", "05d-doesnt-work.html", ("答案：照原文不能用", "Answer: doesn't work as written"), ("大大的 ✗", "A big ✗")),
               ("06", "06-examples.html", ("真實的例子", "Real examples"), ("5 個真實檢查", "5 real checks")),
               ("07", "07-help.html", ("說明（每頁右上角也能打開）", "Help (also opens from every page)"), ("一張圖＋符號說明", "One picture + what the symbols mean")),
               ("08", "08-components.html", ("元件一覽", "Components"), ("按鈕、標籤、卡片、修正、進度", "Buttons, labels, cards, fix, progress"))]
    lis = "".join(f'<li><a href="{f}"><span class="k">{k}</span><strong>{L(*t)}</strong><span class="s">{L(*s)}</span></a></li>' for k, f, t, s in screens)
    body = f"""<h1>{L("新手版：所有頁面", "Beginner version: every screen")}</h1>
<p class="lead">{L("依照 submission/FIGMA_PROMPT.md 做成的可點擊原型。手機寬度也能看，右上角可以切換中英文。",
                   "A clickable prototype built from submission/FIGMA_PROMPT.md. Works at phone width; switch languages at the top right.")}</p>
<ul class="map">{lis}</ul>
<p class="tech" style="margin-top:28px">{L("流程：01 → 02 → 03 → 04 → 05。所有結果都是 web/demo/recordings 裡真實的開發紀錄；04 的進度是示範。",
    "Flow: 01 → 02 → 03 → 04 → 05. Every result is a real recorded development run from web/demo/recordings; the progress on 04 is a demonstration.")}</p>"""
    page("index.html", "所有頁面", "Every screen", body)


def figma_css():
    """style.css, light theme only, inline, plus the static Help overlay."""
    css = (HERE / "style.css").read_text()
    css = css[:css.index("@media (prefers-color-scheme: dark)")] + css[css.index("* { box-sizing"):]
    css += """
/* Figma copies only: Help drawn open over a page */
body { position: relative; }
.overlay { position: absolute; inset: 0; background: rgba(20, 15, 10, .55); display: flex; justify-content: center; align-items: flex-start; padding: 40px 16px; }
.help-static { width: min(680px, 100%); background: var(--card); border-radius: 24px; padding: 32px; box-shadow: 0 20px 60px rgba(0,0,0,.3); }
"""
    return f"<style>\n{css}</style>"


def figma_states():
    """Each interactive state as its own static file, so Figma gets every frame."""
    def variant(src, dst, *swaps):
        s = (OUT / src).read_text()
        for a, b in swaps:
            assert a in s, f"{dst}: {a[:60]}"
            s = s.replace(a, b, 1)
        (OUT / dst).write_text(s)
    stage = lambda n: f'<li><span class="m" aria-hidden="true">{n}</span>'
    done = lambda n: f'<li class="done"><span class="m" aria-hidden="true">✓</span>'
    variant("02-choose.html", "02b-choose-selected.html",
            ('value="03-promise-md2html.html">', 'value="03-promise-md2html.html" checked>'),
            ('id="continue" href="#" aria-disabled="true"', 'id="continue" href="03-promise-md2html.html" aria-disabled="false"'),
            ('<p class="hint" id="choose-hint" tabindex="-1">', '<p class="hint" id="choose-hint" tabindex="-1" hidden>'))
    variant("04-trying.html", "04-trying.html", (stage(1), done(1)), (stage(2), '<li class="now"><span class="m" aria-hidden="true">2</span>'),
            ('<div class="bar" aria-hidden="true"><span></span>', '<div class="bar" aria-hidden="true"><span style="width:50%"></span>'))
    variant("04-trying.html", "04b-trying-done.html", ('<li class="now"><span class="m" aria-hidden="true">2</span>', done(2)), (stage(3), done(3)),
            ('style="width:50%"', 'style="width:100%"'), ('<div id="done" hidden>', '<div id="done">'))
    for name in ("03-promise-md2html", "05b-fixed", "05c-needs-person"):
        variant(f"{name}.html", f"{name}-details-open.html", ('<details class="more">', '<details class="more" open>'))
    inner = help_html().split('<div class="inner">', 1)[1].rsplit("</div></dialog>", 1)[0].replace(" data-close", "")
    variant("01-welcome.html", "01b-welcome-help-open.html", ("</body>", f'<div class="overlay"><div class="help-static">{inner}</div></div>\n</body>'))


def figma_board():
    """All Figma screens in one file: each screen twice, 1440 and 390 wide, side by side, Chinese then English.
    The phone layout comes from a container query on each frame, so it works inside one page."""
    import re
    css = figma_css()[len("<style>\n"):-len("</style>")]
    css = css.replace("@media (max-width: 760px) {", "@container screen (max-width: 760px) {")
    css = css.replace("body { position: relative; }", "")
    css += """
/* the board */
body { background: #E9E6E1; padding: 40px; font-size: 20px; }
.board-head { max-width: 1100px; margin: 0 0 40px; }
.board-head h1 { font-size: 40px; }
.lang-title { font-size: 34px; margin: 48px 0 24px; padding-top: 24px; border-top: 4px solid #1D1B18; }
.frame-row { display: flex; gap: 48px; align-items: flex-start; margin-bottom: 64px; }
.frame-label { font: 700 18px/1.4 Inter, sans-serif; color: #45403A; margin: 0 0 8px; }
.screen { container: screen / inline-size; position: relative; overflow: hidden; background: var(--bg); color: var(--ink);
  font: 20px/1.6 Inter, "Noto Sans TC", "PingFang TC", system-ui, sans-serif; font-variant-numeric: tabular-nums; box-shadow: 0 4px 24px rgba(0,0,0,.12); }
.screen.desktop { width: 1440px; } .screen.phone { width: 390px; }
.screen .hero { min-height: 560px; }
"""
    rows = []
    n = 0
    for lang, title in (("zh", "中文"), ("en", "English")):
        rows.append(f'<h2 class="lang-title">{title}</h2>')
        for f in sorted((HERE / "figma" / lang).glob("*.html")):
            html = f.read_text()
            name = re.search(r"<title>(.*?) · Fresh Eyes</title>", html).group(1)
            body = html.split("<body>", 1)[1].rsplit("</body>", 1)[0].replace('href="../../md2html-fix.patch"', 'href="md2html-fix.patch"')
            frames = []
            for size in ("desktop", "phone"):
                n += 1
                one = re.sub(r'name="(project|k)"', lambda m: f'name="{m.group(1)}-{n}"', body)  # radio groups must not span frames
                frames.append(f'<div><p class="frame-label">{f.stem} · {name} · {"1440" if size == "desktop" else "390"}</p>'
                              f'<div class="screen {size}" lang="{"en" if lang == "en" else "zh-Hant"}">{one}</div></div>')
            rows.append(f'<section class="frame-row">{"".join(frames)}</section>')
    board = f"""<!doctype html>
<html lang="zh-Hant">
<head>
<meta charset="utf-8">
<title>Fresh Eyes beginner screens (all)</title>
<style>
{css}</style>
</head>
<body>
<div class="board-head">
<h1>Fresh Eyes 新手版：所有畫面</h1>
<p>中文和英文各 20 個畫面，每個畫面都有電腦版（1440）和手機版（390）。整個檔案匯入 Figma 就好。</p>
<p>20 screens in Chinese and English, each at desktop (1440) and phone (390) width. Import this one file into Figma.</p>
</div>
{"".join(rows)}
</body>
</html>
"""
    (HERE / "figma-all-screens.html").write_text(board, encoding="utf-8")
    return n


def write_all():
    welcome(); choose()
    for k in PROJECTS: promise(k)
    trying(); answers(); examples(); help_page(); kit()


if __name__ == "__main__":
    write_all(); screen_map()
    # the real manual fix from the recorded run, for the Download button on 05b
    (HERE / "md2html-fix.patch").write_bytes((HERE.parents[1] / "web/demo/recordings/patches/563db9062b7b4e48a4490e41b6792ff6.diff").read_bytes())
    FIGMA = True
    for LANG in ("zh", "en"):
        OUT = HERE / "figma" / LANG
        OUT.mkdir(parents=True, exist_ok=True)
        write_all(); figma_states()
    frames = figma_board()
    print(frames, "frames in figma-all-screens.html;", len(list(HERE.glob("*.html"))) - 1, "prototype pages;", len(list((HERE / "figma/zh").glob("*.html"))), "Figma files per language")
