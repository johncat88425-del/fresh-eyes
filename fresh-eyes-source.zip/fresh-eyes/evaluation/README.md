# Evaluation results format

The evaluation page (`web/`, section "Evaluation") reads one file: `evaluation/results.json`. `web/serve.py` serves it read-only at `/evaluation.json`; nothing else in `evaluation/` is exposed. If the file doesn't exist, the page shows an empty state. The page computes every metric itself from the runs below, so the file holds facts only, never percentages.

A labelled example for UI work lives at `web/examples/evaluation-example.json` (`data_origin: "example"`, case ids `example-*`). It is not a result.

## Shape

```json
{
  "schema_version": 1,
  "data_origin": "evaluation",
  "frozen_at": "2026-10-23T18:00:00Z",
  "freeze": {
    "code_version": "<git sha or package hash>",
    "prompts_sha256": "<hash>",
    "runner": "<image digest or sandbox base id>",
    "dependency_mode": "offline_snapshot"
  },
  "cases": [
    {
      "case_id": "markdown2-cli",
      "set": "holdout",
      "repo_url": "https://github.com/trentm/python-markdown2",
      "commit_sha": "<40 hex>",
      "acceptance_sha256": "<must equal the frozen hash in cases/CASE_NOTES.md>",
      "expected_state": null
    }
  ],
  "runs": [
    {
      "case_id": "markdown2-cli",
      "group": "A",
      "run_id": "<API run id>",
      "run_state": "completed",
      "result_status": "already_passes",
      "acceptance_sha256": "<hash the run actually used>",
      "started_at": "2026-10-24T09:00:00Z",
      "duration_s": 74.2,
      "model_calls": 0,
      "cost_usd": null,
      "cost_status": "unknown",
      "model_usd": 0,
      "model_cost_status": "no_model_calls",
      "human_review": null
    }
  ]
}
```

| Field | Values / rule |
|---|---|
| `cases[].set` | `holdout`, `dev` or `boundary`. Only `holdout` and `boundary` feed the metrics; `dev` is listed for reference |
| `cases[].expected_state` | Boundary cases only: the state written down before running (`unsupported`, `needs_input`, …). `null` otherwise |
| `runs[].group` | `A` original README · `B` one fix · `C` Fresh Eyes (Nano + Ultra) · `D` same as C with every call on Ultra |
| `runs[].result_status` | The API's eight results, or `null` if the run never finished |
| `runs[].acceptance_sha256` | If it differs from the case's hash, the page flags the run and leaves it out of every metric |
| `runs[].duration_s` | Wall time including queue, install and final re-run. `null` = unknown |
| `runs[].cost_usd` | Model + search + runner cost computed from usage. `null` = unknown, never written as 0 to mean unknown |
| `runs[].cost_status` | `no_model_calls`, `usage_calculated_pending_reconciliation`, `reconciled`, or `unknown` |
| `runs[].model_usd` / `model_cost_status` | Optional separate model subtotal and its status. Usage-calculated cost is pending reconciliation; no calls means 0. Unknown runner cost still leaves total `cost_usd` as `null` |
| `runs[].human_review` | `null` until reviewed, then `{"verdict": "accepted" \| "rejected", "reviewer": "...", "reviewed_at": "<timestamp with timezone>", "note": "...", "report_sha256": "...", "scope": "team_patch_output_review"}`. Team review only |

One run per case per group. If a group wasn't run for a case (for example no budget for D), leave that run out; the page lists it as "not run" and keeps it out of that group's denominator, and shows how many cases were unpaired.

## Data checks (before anything is counted)

Implemented in `web/evaluation.js`, tested in `web/tests/evaluation.test.mjs` (`node --test web/tests/*.test.mjs`).

- `data_origin` must be `evaluation` or `example`; otherwise the whole file is rejected with the reason.
- Both the case's and the run's `acceptance_sha256` must be full 64-character lowercase hex. A missing or short hash is invalid data, never a match. A case with an invalid hash contributes no runs.
- One run per case per group. If a case+group appears more than once, **all** of those runs are excluded and reported; array order never decides.
- `run_state` must be `queued`, `running`, `completed` or `failed`. Queued and running runs are listed as in progress and counted nowhere. `completed` needs one of the eight results; `failed` may have a result or `null`, and stays in fix denominators as unverified.
- `duration_s`, `cost_usd` and `model_usd` must be finite and non-negative, or `null` for unknown.
- Every excluded run is listed on the page with its reason.

## Metric definitions (what the page computes)

All metrics use holdout cases unless stated. Runs whose acceptance hash doesn't match are excluded and listed.

| Metric | Numerator / denominator |
|---|---|
| Original pass | A runs with `already_passes` / holdout cases with a valid A result. A results of `infrastructure_error` or missing are excluded and listed with the reason |
| A-failed cases | Holdout cases whose A result is `unresolved`. Other A results (`needs_review`, `needs_input`, `unsupported`) are listed, not counted as README failures |
| Fix rate (B, C, D) | That group's `verified_fix` / A-failed cases that have a run in that group. Timeouts, budget stops and `infrastructure_error` in that group stay in the denominator as unverified. A-failed cases with no run in the group are listed as unpaired |
| Healthy kept | A-passed cases where C is `already_passes` (no patch proposed) / A-passed cases with a C run |
| Review misjudgement | `verified_fix` runs with `human_review.verdict == "rejected"` / all `verified_fix` runs, per group. Pending reviews are counted separately |
| Boundary judgement | Per boundary case: `expected_state` vs the actual state (C run if present, else A). Never part of any fix rate |
| Time and cost | Per group: sum of known `duration_s` and of known `cost_usd`, each with a count of unknowns (all unknown shows "unknown", never 0); median over known times |
| Model subtotal | Per group: sum of known `model_usd`, labelled "from usage, pending reconciliation", with a count of unknowns. Shown next to the total; it never replaces an unknown `cost_usd` |
| C vs D | Only on cases where both C and D ran: verified fixes, total time and total known cost for each |

Small purposive sample: the page prints counts as "n / N", not percentages, and states that the results don't generalise.

## Actual producer and frozen protocols

See [the runbook](RUNBOOK.md). The producer uses a v2 execution freeze; the frontend results file above remains `schema_version: 1`. A runs the original README, B permits one Nano/Ultra repair round, C permits at most two, and D permits at most two with Ultra for both classification and diagnosis. The core defaults to one round; C/D must be selected explicitly. Every successful candidate still requires an independent clean verification. No human patch may be relabelled as a model group.

The freeze records public model IDs/context/prices, protocols, a shared per-case time/model cap and a batch cap. `evaluation-run` keeps paid calls disabled unless explicitly activated by the owner with a reviewed configuration and a newly authorized scope. Any unresolved dispatched charge stops the whole batch. A control-process deadline bounds stages and inference timeouts, but cleanup/runtime preparation may overrun; it is not a platform hard-kill guarantee.

`evaluation-export --records` can be repeated to merge distinct case/group slots from the same freeze. It validates evidence hashes, protocol/route/rounds, model-ledger identities and usage calculations. Duplicate slots and engineering/example evidence are rejected. Optional producer fields include `freeze_sha256`, `protocols`, `limits`, `batch_stops`, `unrun`, and the separate model subtotal fields above; the UI need not count them as additional runs. The current UI's total-cost comparisons continue to use `cost_usd`, so an unknown total cannot become a claimed C-versus-D saving.

The page shows `unrun` as a "Groups that didn't run" list with the stated reason (and "Not run" in the case matrix), `batch_stops` as a red notice at the top, and `limits` in the frozen-setup card. A negative or non-numeric `model_usd` makes a run unusable, like `duration_s` and `cost_usd`. Checked on 2026-10-20 against a file produced by `evaluation.export_results` itself (synthetic fixture run, kept as `web/tests/fixtures/export-format.json`): it loads with no data issues.

The two files `web/examples/two-round-*.json` are engineering UI fixtures only. This implementation/test update executed no real holdout and no new paid model request. No actual `evaluation/results.json` has been published.

## Summary for the submission and the review checklist

```sh
node evaluation/summarize.mjs evaluation/results.json > evaluation/summary.md
```

`summary.md` has two sections, both computed with the same code as the evaluation page (`web/evaluation.js`):
- **Evaluation:** every measure as passed / total. Each group's time, model cost from usage, and total cost show unknowns as unknown. It also lists groups that didn't run (with the export's reason), a stopped batch, and every run left out of the counts in plain words. The Devpost "Evaluation" section is built from this.
- **Team review of claimed fixes:** one row per `verified_fix` run, to be marked accepted / rejected by a person (EVAL-11).

Example data is refused unless `--allow-example`, and is then labelled "EXAMPLE DATA, NOT A RESULT" on both sections.

The actual export now supports `--review-template NEW_FILE` and `--human-reviews REVIEWED_FILE`; see runbook section 5. Reviews bind the exact freeze, case/group/run, acceptance and report hashes. Draft rows stay pending; invalid or mismatched reviews abort the export. No real post-run review has been filled by the software.
