# WIN-5 development cases (draft)

B, 2026-10-22. **These are development cases chosen *because* they are expected to fail**, to show whether the AI can repair different kinds of real README breakage. They are not holdout cases and must never be counted in a success rate. The holdout set (`cases/holdout/`) follows a separate written selection rule. Its human reviews and current-code freeze are still pending; these development candidates are outside that set.

## How they were found

Static scans of public GitHub repositories:
- read README, `setup.py`, `pyproject.toml`, `requirements.txt` and the entry modules through the GitHub search API and `raw.githubusercontent.com`;
- nothing was downloaded, installed or run by B;
- B reports approximately 1,100 repository observations across six scans. The package contains scanner scripts, not complete scan outputs or a deduplicated inventory, so A has not independently verified that count.

Patterns looked for, each one fixable inside Fresh Eyes's patch scope (README, `requirements*.txt`, `pyproject.toml` dependencies):

| Pattern | Why it breaks today | Expected fix |
|---|---|---|
| Entry module imports `pkg_resources` with no setuptools dependency | Python 3.12 venvs no longer include setuptools; setuptools 82 removed `pkg_resources` | add `setuptools<82` to the documented install |
| `requirements.txt` pins a release with no CPython 3.12 wheel (for example `PyYAML==5.4.1`) | the documented `pip install -r requirements.txt` must build from source; a slim image has no compiler, and PyYAML 5.x also fails with Cython 3 | raise the pin in `requirements.txt` to the first release with a 3.12 wheel (checked on PyPI) |
| README installs only `requirements.txt`, then runs a console command (the md2html pattern) | the command is never installed | install the package itself |
| Jinja2 3.1 / MarkupSafe 2.1 removed names, `distutils` | upstream releases removed them | pin the dependency, or add setuptools |

B-reported totals: six scans and 52 pattern hits; not an independently verified unique-repository count. `scan/` holds five helper scripts. Their top-level code makes network requests if explicitly run; A only parsed their syntax and did not execute them.

Rejected on reading:
- tools that need a network service, an account, hardware, or a system package (Pandoc, compilers);
- tools without a file-in → file-out workflow our validators can check.

## Status of each draft

| File | Pattern | Status |
|---|---|---|
| `htmldiff.json` | `pkg_resources` | Draft, valid contract. **Limitation:** our fixtures have one input, so the diff compares a file with itself. That checks install and output, not the diff markup |

Checked statically for htmldiff:
- `insert_stylesheet` turns the byte output back into text, so writing `result.html` works on Python 3; Python 3 compatibility PRs #9–#12 are merged.
- Static dependency inspection suggests a Python 3.12 install may work. No successful install has been observed yet; available wheels and isolated build dependencies do not prove runtime success.
- setuptools 81.0.0 is the last release before 82 (PyPI, 2026-10-22).
- Open issue #8 ("Python 2-only") predates those fixes. **Only a real run can settle it.**

Why only one case:
- The `requirements.txt` stale-pin pattern was common (37 hits), but almost all were machine-learning projects (GPU, datasets).
- The rest were rejected as follows:
  - las_converter: a library with no CLI;
  - csv_to_parquet: binary output, and a pandas 0.25 → 2.x code change;
  - stasis: needs Pandoc;
  - mynt: needs a compiler for `hoep`;
  - the remaining ones: network, account or hardware.
- Together with md2html (install step omitted), htmldiff (platform drift on Python 3.12) would provide a second failure class if the unchanged README-only baseline reproduces the predicted error. htmldiff is not yet an observed failure or a repaired project.

Every draft has `review.status: draft`; a person must approve each acceptance check. **A then runs it README-only** (no model, $0) to confirm it really fails as expected, before any AI repair run. A draft whose README-only run passes is dropped, not edited to fail.

## A review (2026-10-22)

Contract syntax passes; review remains draft. The identical-input limitation is accurately disclosed. Do not change fixtures to manufacture a failure. The platform hypothesis is supported by [Python 3.12 release notes](https://docs.python.org/3.12/whatsnew/3.12.html) and [setuptools historical documentation](https://github.com/pypa/setuptools/blob/main/docs/deprecated/pkg_resources.rst), but the pinned project still needs an isolated baseline and human acceptance review. No model spending is authorised by this document.
