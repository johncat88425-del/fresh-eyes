"""WIN-5 static scan v3: CLIs that break on Python 3.12 or on newer dependency releases, where pinning or adding a
dependency is the fix (inside Fresh Eyes's README/requirements/pyproject scope). Reads public files only; never
downloads archives, installs or executes anything."""
import json, re, sys, time, tomllib, urllib.error, urllib.parse, urllib.request

API = "https://api.github.com"
H = {"Accept": "application/vnd.github+json", "User-Agent": "fresh-eyes-win5-static-scan"}
PATTERNS = {  # what the code does -> (why it breaks now, the fix a dependency change can make)
    "jinja2_markup": (r"from jinja2 import[^\n]*\b(Markup|contextfilter|environmentfilter|evalcontextfilter|escape)\b",
                      "Jinja2 3.1 removed these names", "pin jinja2<3.1"),
    "markupsafe_soft_unicode": (r"from markupsafe import[^\n]*\bsoft_unicode\b", "MarkupSafe 2.1 removed soft_unicode", "pin markupsafe<2.1"),
    "pkg_resources": (r"^\s*(import pkg_resources|from pkg_resources import)", "no setuptools in 3.12 venvs; setuptools 82 dropped pkg_resources", "add setuptools<82"),
    "distutils": (r"^\s*(import distutils|from distutils[ .])", "distutils removed in Python 3.12", "add setuptools"),
}
BLOCKERS = r"^\s*(import imp\b|from imp import|import asynchat|import asyncore|import smtpd)|collections\.(Mapping|MutableMapping|Iterable|Callable)\b|\bprint [\"'a-z]"


def search(q):
    for _ in range(4):
        try:
            url = f"{API}/search/repositories?q={urllib.parse.quote(q)}&sort=stars&order=desc&per_page=50"
            with urllib.request.urlopen(urllib.request.Request(url, headers=H), timeout=20) as r:
                return json.loads(r.read()).get("items", [])
        except urllib.error.HTTPError as e:
            if e.code in (403, 429):
                time.sleep(40); continue
            raise
    print(f"search gave up: {q}", file=sys.stderr)
    return []


def raw(repo, path):
    try:
        with urllib.request.urlopen(urllib.request.Request(f"https://raw.githubusercontent.com/{repo}/HEAD/{path}", headers=H), timeout=20) as r:
            return r.read(400000).decode("utf-8", "replace")
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError):
        return None


def project(repo):
    eps, deps = {}, ""
    py = raw(repo, "pyproject.toml")
    if py:
        try:
            d = tomllib.loads(py)
            eps.update(d.get("project", {}).get("scripts", {}))
            eps.update(d.get("tool", {}).get("poetry", {}).get("scripts", {}))
            deps += json.dumps(d.get("project", {}).get("dependencies", [])) + json.dumps(d.get("tool", {}).get("poetry", {}).get("dependencies", {}))
        except tomllib.TOMLDecodeError:
            pass
    st = raw(repo, "setup.py") or ""
    for m in re.finditer(r"['\"]([A-Za-z0-9_.-]+)\s*=\s*([A-Za-z0-9_.]+):([A-Za-z0-9_]+)['\"]", st):
        eps[m.group(1)] = f"{m.group(2)}:{m.group(3)}"
    m = re.search(r"install_requires\s*=\s*\[(.*?)\]", st, re.S)
    deps += m.group(1) if m else ""
    req = raw(repo, "requirements.txt")
    deps += req or ""
    return eps, deps, {"pyproject": bool(py), "setup_py": bool(st), "requirements_txt": req is not None}


def module_path(repo, module):
    parts = module.split(".")
    for base in ("", "src/"):
        for path in (f"{base}{'/'.join(parts)}.py", f"{base}{'/'.join(parts)}/__init__.py"):
            t = raw(repo, path)
            if t is not None:
                return path, t
    return None, None


def related(repo, entry_module, entry_text, limit=5):
    """The entry module, its package __init__, and same-package modules it imports directly."""
    top = entry_module.split(".")[0]
    seen, out = set(), []
    for mod in [entry_module, top] + re.findall(rf"^\s*from\s+(\.?{re.escape(top)}[\w.]*|\.[\w.]*)\s+import", entry_text, re.M):
        mod = top + mod if mod.startswith(".") and mod != "." else mod
        if mod in seen or len(out) >= limit:
            continue
        seen.add(mod)
        path, text = module_path(repo, mod.rstrip("."))
        if text is not None:
            out.append((path, text))
    return out


seen, hits = set(), []
for q in sys.argv[1:]:
    items = search(q)
    time.sleep(8)
    for item in items:
        repo = item["full_name"]
        if repo in seen or item.get("archived") or item.get("fork"):
            continue
        seen.add(repo)
        eps, deps, files = project(repo)
        if not eps:
            continue
        found, blockers = [], []
        for cmd, target in list(eps.items())[:3]:
            module = target.split(":")[0]
            path, text = module_path(repo, module)
            if not text:
                continue
            for p, t in related(repo, module, text):
                blockers += [f"{p}: {b if isinstance(b, str) else ''.join(b)}" for b in re.findall(BLOCKERS, t, re.M)]
                for key, (rx, why, fix) in PATTERNS.items():
                    for mt in re.finditer(rx, t, re.M):
                        line = t[:mt.start()].count("\n") + 1
                        found.append({"command": cmd, "file": p, "line": line, "pattern": key, "why": why, "fix": fix})
        if not found:
            continue
        # A pin or explicit setuptools dependency already in place means it doesn't break this way.
        already = [f for f in found if (f["pattern"] == "jinja2_markup" and re.search(r"jinja2\s*[<~=]", deps, re.I))
                   or (f["pattern"] == "markupsafe_soft_unicode" and re.search(r"markupsafe\s*[<~=]", deps, re.I))
                   or (f["pattern"] in ("pkg_resources", "distutils") and re.search(r"setuptools", deps, re.I))]
        live = [f for f in found if f not in already]
        if live:
            hit = {"repo": repo, "stars": item.get("stargazers_count"), "pushed": (item.get("pushed_at") or "")[:10],
                   "description": (item.get("description") or "")[:100], "files": files, "deps": deps[:300],
                   "findings": live[:6], "blockers": sorted(set(blockers))[:5]}
            hits.append(hit)
            print(json.dumps(hit), flush=True)
print(f"scanned {len(seen)}; {len(hits)} candidates", file=sys.stderr)
